#include "philosophers.h"

void	ft_initialize_data_phi(t_all *data, t_data_philosopher *d)
{
	d->active = -1;
	d->fork_right = -1;
	d->fork_left = -1;
	d->time = -1;
	d->s_time = -1;
	d->n_times = 0;
	d->using_fork_left = -1;
	d->using_fork_right = -1;
	d->a_alive = -1;
	d->total_n_times = -1;
	ft_get_active(data, &d->active);
	ft_identify_forks(data, d);
	ft_set_start_trhead(data, d->active);
}

void	*ft_philosopher(void *arg)
{
	t_all				*data;
	t_data_philosopher	d;

	data = (t_all *) arg;
	ft_initialize_data_phi(data, &d);
	if (data->phi[d.active].time_to_die > 0 && data->total_philosophers > 1)
	{
		ft_get_all_alive(data, &d.a_alive);
		while (d.a_alive == 1 && data->phi[d.active].number_exit == 0)
		{
			ft_eating(data, &d);
			d.total_n_times = data->phi[d.active].number_of_times;
			if (d.total_n_times != -1 && d.n_times >= d.total_n_times)
				data->phi[d.active].number_exit = 1;
			if (data->phi[d.active].number_exit == 0)
			{
				ft_sleeping_thinking(data, &d);
				d.s_time = 0;
			}
		}
	}
	ft_increment_total_exit(data);
	return (NULL);
}