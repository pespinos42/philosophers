#ifndef PHILOSOPHERS_H
# define PHILOSOPHERS_H
# include <unistd.h>
# include <limits.h>
# include <stdlib.h>
# include <stdio.h>
# include <pthread.h>
# include <sys/time.h>

typedef struct s_all
{
    int             number_philosophers;
    pthread_mutex_t mutex_number_philosophers;   
    long int        time_to_die;
    pthread_mutex_t mutex_time_to_die;
    long int        time_to_eat;
    pthread_mutex_t mutex_time_to_eat;
    long int        time_to_sleep;
    pthread_mutex_t mutex_time_to_sleep;
    int             number_of_times_eat;
    pthread_mutex_t mutex_number_of_times_eat;
}   t_all;

typedef struct s_atoi
{
	long int	result;
	int			s;
	int			sign;
}	t_atoi;

#endif
