#include "philosophers.h"

void    ft_destroy_forks(t_fork *forks, int n_forks)
{
    int n;

    n = 0;
    while (n < n_forks)
    {
        if (pthread_mutex_destroy(&forks[n].mutex_using_fork) != 0)
            return ;
        n++;
    }
}

t_fork  *ft_create_forks(int n_forks)
{
    t_fork  *forks;
    int     n;

    n = 0;
    forks = malloc (n_forks * sizeof (*forks));
    if (!forks)
        return (NULL);
    while (n < n_forks)
    {
        if (pthread_mutex_init(&forks[n].mutex_using_fork, NULL) != 0)
            return (NULL);
        n++;
    }
    return (forks);
}

void    ft_lock_fork(t_all *data, int fork)
{
    if (pthread_mutex_lock(&data->forks[fork].mutex_using_fork) != 0)
        return ;
    data->forks[fork].using_fork = 1;
    if (pthread_mutex_unlock(&data->forks[fork].mutex_using_fork) != 0)
        return ;
}

void    ft_unlock_fork(t_all *data, int fork)
{
    if (pthread_mutex_lock(&data->forks[fork].mutex_using_fork) != 0)
        return ;
    data->forks[fork].using_fork = 0;
    if (pthread_mutex_unlock(&data->forks[fork].mutex_using_fork) != 0)
        return ;
}