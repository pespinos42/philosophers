/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file13.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/30 18:12:01 by pespinos          #+#    #+#             */
/*   Updated: 2023/06/30 18:12:01 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_if_ok(t_all *data, t_temp *temp)
{
	ft_assign_forks(data, temp);
	while (ft_get_a_a(data) == 1 && ft_get_e_y(&data->d_p[temp->a]) == 0)
	{
		ft_get_forks(data, temp);
		ft_eating(data, temp);
		ft_release_forks(data, temp);
		ft_check_exit_yet(data, temp);
		ft_sleeping_thinking(data, temp);
	}
}

void	*ft_philosopher(void *arg)
{
	t_all		*data;
	t_temp		temp;

	ft_data_philosopher(&temp);
	data = (t_all *) arg;
	temp.a = ft_get_active(data);
	ft_set_i_p(&data->d_p[temp.a], temp.a);
	ft_set_s_th(&data->d_p[temp.a], ft_get_t());
	if (ft_get_n_p(data) > 1 && ft_get_t_to_die(data) > 0)
	{
		ft_if_ok(data, &temp);
	}
	else if (ft_get_n_p(data) == 1 || ft_get_t_to_die(data) == 0)
	{
		while (ft_get_a_a(data) == 1)
		{
			ft_wait(data, 1);
		}
	}
	ft_set_total_exit(data, ft_get_total_exit(data) + 1);
	return (NULL);
}

void	ft_initialize_data_all_alive(t_data_all_alive *d_a_a)
{
	d_a_a->n = 0;
	d_a_a->time = 0;
	d_a_a->time_start = -1;
	d_a_a->s_th = -1;
	d_a_a->l_e = -1;
	d_a_a->t_t_d = -1;
	d_a_a->t_e = -1;
	d_a_a->s_th = -1;
}

void	ft_start_thread_ok(t_all *data, t_data_all_alive *d_a_a)
{
	if (d_a_a->s_th != -1)
	{
		d_a_a->l_e = ft_get_l_e(&data->d_p[d_a_a->n]);
		if (d_a_a->l_e == -1)
		{
			d_a_a->time_start = ft_get_s_th(&data->d_p[d_a_a->n]);
		}
		else
		{
			d_a_a->time_start = ft_get_l_e(&data->d_p[d_a_a->n]);
		}
		d_a_a->time = ft_get_t();
		d_a_a->t_t_d = ft_get_t_to_die(data);
		if ((d_a_a->time - d_a_a->time_start) >= d_a_a->t_t_d)
		{
			if (ft_get_e_y(&data->d_p[d_a_a->n]) == 0)
			{
				ft_p_m(data, ft_get_t(), d_a_a->n + 1, " is died");
				ft_set_all_alive(data, 0);
			}
		}
		d_a_a->n = d_a_a->n + 1;
	}
}

void	*ft_all_alive(void *arg)
{
	t_all				*data;
	t_data_all_alive	data_all_alive;

	data = (t_all *) arg;
	ft_initialize_data_all_alive(&data_all_alive);
	while (ft_get_s_th(&data->d_p[ft_get_n_p(data) - 1]) <= 0)
		ft_wait(data, 100);
	while (ft_get_a_a(data) == 1 && ft_get_total_exit(data) < ft_get_n_p(data))
	{
		while (data_all_alive.n < ft_get_n_p(data) && ft_get_a_a(data) == 1)
		{
			data_all_alive.s_th = ft_get_s_th(&data->d_p[data_all_alive.n]);
			ft_start_thread_ok(data, &data_all_alive);
		}
		data_all_alive.n = 0;
	}
	return (NULL);
}
