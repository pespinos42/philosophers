#include "philosophers.h"

pthread_t	*ft_create_threads(t_all *data)
{
	pthread_t	*threads;

	threads = malloc (ft_get_n_p(data) * sizeof (*threads));
	if (!threads)
		return (NULL);
	return (threads);
}

void	ft_initialize_threads(t_all *data)
{
	int	n;

	n = 0;
	if (pthread_create(&data->t_a_a, NULL, ft_all_alive, data) != 0)
		return ;
	usleep(1000);
	while (n < ft_get_n_p(data))
	{
		ft_set_active(data, n);
		if (pthread_create(&data->threads[n], NULL, ft_philosopher, data) != 0)
			return ;
		usleep(100);
		n++;
	}
}

void	ft_s_ths(t_all *data)
{
	int	n;

	n = 0;
	if (pthread_join(data->t_a_a, NULL) != 0)
		return ;
	while (n < ft_get_n_p(data))
	{
		if (pthread_join(data->threads[n], NULL) != 0)
			return ;
		n++;
	}
}

void	ft_fill_data(t_all *data, long int *args, int argc)
{
	ft_init_mutex_data(data);
	ft_set_n_p(data, args[0]);
	ft_set_all_alive(data, 1);
	ft_set_time_to_die(data, args[1]);
	ft_set_time_to_eat(data, args[2]);
	ft_set_time_to_sleep(data, args[3]);
	if (argc == 6)
		ft_set_number_of_times_eat(data, args[4]);
	else
		ft_set_number_of_times_eat(data, -1);
	data->forks = ft_create_forks(args[0]);
	ft_init_mutex_forks(data->forks, args[0]);
	data->d_p = ft_create_data_philosophers(data);
	data->threads = ft_create_threads(data);
	ft_set_total_exit(data, 0);
}

void	ft_print_number(long int n)
{
	char	number;

	number = 0;
	if (n == INT_MIN)
		write(1, "-2147483648", 11);
	else if (n < 0)
	{
		write(1, "-", 1);
		ft_print_number(-n);
	}
	else
	{
		if (n > 9)
			ft_print_number(n / 10);
		number = (n % 10) + 48;
		write(1, &number, 1);
	}
}
