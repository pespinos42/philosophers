/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file15.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/30 18:12:05 by pespinos          #+#    #+#             */
/*   Updated: 2023/06/30 18:12:05 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

long int	ft_get_t(void)
{
	struct timeval	tv;

	gettimeofday(&tv, NULL);
	return ((tv.tv_sec * 1000) + (tv.tv_usec / 1000));
}

void	ft_clean_all(t_all *data, long int *args)
{
	ft_destroy_mutex_forks(data->forks, ft_get_n_p(data));
	ft_d_m_d_p(data->d_p, ft_get_n_p(data));
	ft_destroy_mutex_data(data);
	free(args);
	free(data->forks);
	free(data->d_p);
	free(data->threads);
}
