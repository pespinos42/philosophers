#include "philosophers.h"

void	ft_get_using_forks(t_all *data, int fork, int *u_fork)
{
	if (pthread_mutex_lock(&data->m_read_forks) != 0)
		return ;
	*u_fork = data->forks[fork].using;
	if (pthread_mutex_unlock(&data->m_read_forks) != 0)
		return ;
}