#include "philosophers.h"

t_philosopher	*ft_create_philosophers(int n_philosophers)
{
	t_philosopher	*philosophers;
	int				n;

	n = 0;
	philosophers = malloc (n_philosophers * sizeof(*philosophers));
	if (!philosophers)
		return (NULL);
	while (n < n_philosophers)
	{
		philosophers[n].index_philosopher = -1;
		philosophers[n].time_to_die = -1;
		philosophers[n].time_to_eat = -1;
		philosophers[n].time_to_sleep = -1;
		philosophers[n].number_of_times = -1;
		philosophers[n].last_eating = -1;
		philosophers[n].start_thread = -1;
		philosophers[n].number_exit = 0;
		n++;
	}
	return (philosophers);
}