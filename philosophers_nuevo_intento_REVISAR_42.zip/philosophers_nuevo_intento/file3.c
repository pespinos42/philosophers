#include "philosophers.h"

int	ft_get_n_e(t_data_philosopher *d_p)
{
	int	n_e;

	n_e = -1;
	if (pthread_mutex_lock(&d_p->m_n_e) != 0)
		return (-1);
	n_e = d_p->n_e;
	if (pthread_mutex_unlock(&d_p->m_n_e) != 0)
		return (-1);
	return (n_e);
}

void	ft_set_n_e(t_data_philosopher *d_p, int value)
{
	if (pthread_mutex_lock(&d_p->m_n_e) != 0)
		return ;
	d_p->n_e = value;
	if (pthread_mutex_unlock(&d_p->m_n_e) != 0)
		return ;
}

long int	ft_get_s_t(t_data_philosopher *d_p)
{
	long int	s_t;

	s_t = -1;
	if (pthread_mutex_lock(&d_p->m_s_t) != 0)
		return (-1);
	s_t = d_p->s_t;
	if (pthread_mutex_unlock(&d_p->m_s_t) != 0)
		return (-1);
	return (s_t);
}

void	ft_set_s_t(t_data_philosopher *d_p, long int value)
{
	if (pthread_mutex_lock(&d_p->m_s_t) != 0)
		return ;
	d_p->s_t = value;
	if (pthread_mutex_unlock(&d_p->m_s_t) != 0)
		return ;
}

long int	ft_get_s_th(t_data_philosopher *d_p)
{
	long int	s_th;

	s_th = -1;
	if (pthread_mutex_lock(&d_p->m_s_th) != 0)
		return (-1);
	s_th = d_p->s_th;
	if (pthread_mutex_unlock(&d_p->m_s_th) != 0)
		return (-1);
	return (s_th);
}
