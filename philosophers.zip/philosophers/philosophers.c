/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philosophers.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/13 20:35:45 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/21 19:56:55 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_initialize_data_all_alive(t_d_a_alive *d)
{
	d->n = 0;
	d->time = -1;
	d->time_start = -1;
	d->start_thread = -1;
	d->l_eating = -1;
	d->time_to_die = -1;
	d->total_exit = -1;
}

void	ft_g_s_thread(t_all *data, t_d_a_alive *d)
{
	if (pthread_mutex_lock(&data->phi[d->n].m_s_th) != 0)
		return ;
	d->start_thread = data->phi[d->n].start_thread;
	if (pthread_mutex_unlock(&data->phi[d->n].m_s_th) != 0)
		return ;
}

void	ft_g_l_eating(t_all *data, t_d_a_alive *d)
{
	if (pthread_mutex_lock(&data->phi[d->n].m_l_eat) != 0)
		return ;
	d->l_eating = data->phi[d->n].last_eating;
	if (pthread_mutex_unlock(&data->phi[d->n].m_l_eat) != 0)
		return ;
}

void	*ft_all_alive(void *arg)
{
	t_all				*data;
	t_d_a_alive	d;

	data = (t_all *) arg;
	ft_initialize_data_all_alive(&d);
	d.n = 0;
	d.time = 0;
	ft_get_total_exit(data, &d.total_exit);
	while (data->all_alive == 1 && d.total_exit < data->total_philosophers)
	{
		while (d.n < data->total_philosophers && data->all_alive == 1)
		{
			ft_g_s_thread(data, &d);
			if (d.start_thread != -1)
			{
				ft_g_l_eating(data, &d);
				if (d.l_eating == -1)
					d.time_start = data->phi[d.n].start_thread;
				else
				{
					if (pthread_mutex_lock(&data->phi[d.n].m_l_eat) != 0)
						return (NULL);
					d.time_start = data->phi[d.n].last_eating;
					if (pthread_mutex_unlock(&data->phi[d.n].m_l_eat) != 0)
						return (NULL);
				}
				d.time = ft_get_time();
				if (pthread_mutex_lock(&data->m_erase_all) != 0)
					return (NULL);
				d.time_to_die = data->phi[d.n].time_to_die;
				if (pthread_mutex_unlock(&data->m_erase_all) != 0)
					return (NULL);
				if ((d.time - d.time_start) >= d.time_to_die)
				{
					if (data->phi[d.n].number_exit == 0)
					{
						if (pthread_mutex_lock(&data->m_a_alive) != 0)
							return (NULL);
						data->all_alive = 0;
						if (pthread_mutex_unlock(&data->m_a_alive) != 0)
							return (NULL);
						if (pthread_mutex_lock(&data->m_message) != 0)
							return (NULL);
						ft_p_message(data, d.time, d.n, " died");
						if (pthread_mutex_unlock(&data->m_message) != 0)
							return (NULL);
					}
				}
			}
			d.n++;
		}
		d.n = 0;
		usleep(1000);
		ft_get_total_exit(data, &d.total_exit);
	}
	return (NULL);
}

int	main(int argc, char **argv)
{
	long int	*args;
	t_all		all_phi;

	if (argc == 5 || argc == 6)
	{
		if (ft_check_args(argc, argv) == 1)
		{
			args = ft_get_args(argc, argv);
			ft_fill_t_all(&all_phi, args, argc - 1);
			ft_destroy_forks(all_phi.total_philosophers, all_phi.forks);
			free(args);
			ft_destroy_local_mutex(&all_phi);
			ft_free_all(&all_phi);
			ft_destroy_mutexs(&all_phi);
		}
		else
			printf("ARGUMENTO INVALIDO\n");
	}
	return (0);
}
