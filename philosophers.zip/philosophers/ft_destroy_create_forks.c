#include "philosophers.h"

void	ft_destroy_forks(int n_philosophers, t_fork *forks)
{
	int	n;

	n = 0;
	while (n < n_philosophers)
	{
		if (pthread_mutex_destroy(&forks[n].fork_mutex) != 0)
			return ;
		n++;
	}
}

t_fork	*ft_create_forks(int n_philosophers)
{
	t_fork	*forks;
	int		n;

	n = 0;
	forks = malloc (n_philosophers * sizeof (*forks));
	if (!forks)
		return (NULL);
	while (n < n_philosophers)
	{
		forks[n].using = 0;
		if (pthread_mutex_init(&forks[n].fork_mutex, NULL) != 0)
			return (NULL);
		n++;
	}
	return (forks);
}