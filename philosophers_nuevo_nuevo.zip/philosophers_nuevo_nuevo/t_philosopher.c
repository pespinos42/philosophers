#include "philosophers.h"

int ft_get_index_philosopher(t_philosopher *philo)
{
    int index_philosopher;

    index_philosopher = -1;
    if (pthread_mutex_lock(&philo->mutex_index_philosopher) != 0)
        return (-1);
    index_philosopher = philo->index_philosopher;
    if (pthread_mutex_unlock(&philo->mutex_index_philosopher) != 0)
        return (-1);
    return (index_philosopher);
}

void    ft_set_index_philosopher(t_philosopher *philo, int value)
{
    if (pthread_mutex_lock(&philo->mutex_index_philosopher) != 0)
        return ;
    philo->index_philosopher = value;
    if (pthread_mutex_unlock(&philo->mutex_index_philosopher) != 0)
        return ;
}

long int    ft_get_time_to_die(t_philosopher *philo)
{
    long int    time_to_die;

    time_to_die = -1;
    if (pthread_mutex_lock(&philo->mutex_time_to_die) != 0)
        return (-1);
    time_to_die = philo->time_to_die;
    if (pthread_mutex_unlock(&philo->mutex_time_to_die) != 0)
        return (-1);
    return (time_to_die);
}

void    ft_set_time_to_die(t_philosopher *philo, long int value)
{
    if (pthread_mutex_lock(&philo->mutex_time_to_die) != 0)
        return ;
    philo->time_to_die = value;
    if (pthread_mutex_unlock(&philo->mutex_time_to_die) != 0)
        return ;
}

long int    ft_get_time_to_eat(t_philosopher *philo)
{
    long int    time_to_eat;

    time_to_eat = -1;
    if (pthread_mutex_lock(&philo->mutex_time_to_eat) != 0)
        return (-1);
    time_to_eat = philo->time_to_eat;
    if (pthread_mutex_unlock(&philo->mutex_time_to_eat) != 0)
        return (-1);
    return (time_to_eat);
}

void    ft_set_time_to_eat(t_philosopher *philo, long int value)
{
    if (pthread_mutex_lock(&philo->mutex_time_to_eat) != 0)
        return ;
    philo->time_to_eat = value;
    if (pthread_mutex_unlock(&philo->mutex_time_to_eat) != 0)
        return ;
}

long int    ft_get_time_to_sleep(t_philosopher *philo)
{
    long int    time_to_sleep;

    time_to_sleep = -1;
    if (pthread_mutex_lock(&philo->mutex_time_to_sleep) != 0)
        return (-1);
    time_to_sleep = philo->time_to_sleep;
    if (pthread_mutex_unlock(&philo->mutex_time_to_sleep) != 0)
        return (-1);
    return (time_to_sleep);
}

void    ft_set_time_to_sleep(t_philosopher *philo, long int value)
{
    if (pthread_mutex_lock(&philo->mutex_time_to_sleep) != 0)
        return ;
    philo->time_to_sleep = value;
    if (pthread_mutex_unlock(&philo->mutex_time_to_sleep) != 0)
        return ;
}

int ft_get_number_of_times(t_philosopher *philo)
{
    int number_of_times;

    number_of_times = -1;
    if (pthread_mutex_lock(&philo->mutex_number_of_times) != 0)
        return (-1);
    number_of_times = philo->number_of_times;
    if (pthread_mutex_unlock(&philo->mutex_number_of_times) != 0)
        return (-1);
    return (number_of_times);
}

void    ft_set_number_of_times(t_philosopher *philo, int value)
{
    if (pthread_mutex_lock(&philo->mutex_number_of_times) != 0)
        return ;
    philo->number_of_times = value;
    if (pthread_mutex_unlock(&philo->mutex_number_of_times) != 0)
        return ;
}

long int    ft_get_last_eating(t_philosopher *philo)
{
    long int    last_eating;

    last_eating = -1;
    if (pthread_mutex_lock(&philo->mutex_last_eating) != 0)
        return (-1);
    last_eating = philo->last_eating;
    if (pthread_mutex_unlock(&philo->mutex_last_eating) != 0)
        return (-1);
    return (last_eating);
}

void    ft_set_last_eating(t_philosopher *philo, long int value)
{
    if (pthread_mutex_lock(&philo->mutex_last_eating) != 0)
        return ;
    philo->last_eating = value;
    if (pthread_mutex_unlock(&philo->mutex_last_eating) != 0)
        return ;
}

int ft_get_number_exit(t_philosopher *philo)
{
    int number_exit;

    number_exit = -1;
    if (pthread_mutex_lock(&philo->mutex_number_exit) != 0)
        return (-1);
    number_exit = philo->number_exit;
    if (pthread_mutex_unlock(&philo->mutex_number_exit) != 0)
        return (-1);
    return (number_exit);
}

void    ft_set_number_exit(t_philosopher *philo, int value)
{
    if (pthread_mutex_lock(&philo->mutex_number_exit) != 0)
        return ;
    philo->number_exit = value;
    if (pthread_mutex_unlock(&philo->mutex_number_exit) != 0)
        return ;
}

long int    ft_get_start_thread(t_philosopher *philo)
{
    long int    start_thread;

    start_thread = -1;
    if (pthread_mutex_lock(&philo->mutex_start_thread) != 0)
        return (-1);
    start_thread = philo->start_thread;
    if (pthread_mutex_unlock(&philo->mutex_start_thread) != 0)
        return (-1);
    return (start_thread);
}

void    ft_set_start_thread(t_philosopher *philo, long int value)
{
    if (pthread_mutex_lock(&philo->mutex_start_thread) != 0)
        return ;
    philo->start_thread = value;
    if (pthread_mutex_unlock(&philo->mutex_start_thread) != 0)
        return ;
}
