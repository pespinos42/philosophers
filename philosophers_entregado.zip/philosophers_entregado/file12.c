/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file12.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/30 18:12:00 by pespinos          #+#    #+#             */
/*   Updated: 2023/06/30 18:12:00 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_get_forks(t_all *data, t_temp *temp)
{
	ft_lock_fork(data->forks, ft_get_f_r(&data->d_p[temp->a]));
	ft_p_m(data, ft_get_t(), temp->a + 1, " has taken a fork");
	ft_lock_fork(data->forks, ft_get_f_l(&data->d_p[temp->a]));
	ft_p_m(data, ft_get_t(), temp->a + 1, " has taken a fork");
}

void	ft_eating(t_all *d, t_temp *t)
{
	if (ft_get_a_a(d) == 1)
	{
		ft_p_m(d, ft_get_t(), ft_get_i_p(&d->d_p[t->a]) + 1, " is eating");
		ft_wait(d, ft_get_t_to_eat(d));
		ft_set_l_e(&d->d_p[t->a], ft_get_t());
	}
}

void	ft_release_forks(t_all *d, t_temp *t)
{
	ft_unlock_fork(d->forks, ft_get_f_l(&d->d_p[t->a]));
	ft_unlock_fork(d->forks, ft_get_f_r(&d->d_p[t->a]));
	t->n_e = t->n_e + 1;
	ft_set_n_e(&d->d_p[t->a], ft_get_n_e(&d->d_p[t->a]) + 1);
}

void	ft_check_exit_yet(t_all *d, t_temp *t)
{
	if (ft_get_n_o_t_e(d) != -1
		&& ft_get_n_e(&d->d_p[t->a]) >= ft_get_n_o_t_e(d))
		ft_set_e_y(&d->d_p[t->a], 1);
}

void	ft_sleeping_thinking(t_all *d, t_temp *t)
{
	if (ft_get_e_y(&d->d_p[t->a]) == 0 && ft_get_a_a(d) == 1)
	{
		ft_p_m(d, ft_get_t(), ft_get_i_p(&d->d_p[t->a]) + 1, " is sleeping");
		ft_wait(d, ft_get_t_to_sleep(d));
		t->t_t_d = ft_get_t_to_die(d);
		t->l_e = ft_get_l_e(&d->d_p[t->a]);
		t->t_t_e = ft_get_t_to_eat(d);
		t->s_t = (t->t_t_d - ((ft_get_t() - t->l_e) + t->t_t_e)) / 2;
		ft_set_s_t(&d->d_p[t->a], t->s_t);
		if (ft_get_a_a(d) == 1)
		{
			ft_p_m(d, ft_get_t(), ft_get_i_p(&d->d_p[t->a]) + 1,
				" is thinking");
			if (t->s_t > 100 && ft_get_a_a(d) == 1)
			{
				if (t->s_t > 500)
				{
					t->s_t = 500;
					ft_set_s_t(&d->d_p[t->a], t->s_t);
				}
				ft_wait(d, ft_get_s_t(&d->d_p[t->a]));
			}
		}
	}
}
