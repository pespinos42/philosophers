/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_total_exit.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:51:26 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:52:37 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_increment_total_exit(t_all *data)
{
	if (pthread_mutex_lock(&data->m_total_exit) != 0)
		return ;
	data->total_exit = data->total_exit + 1;
	if (pthread_mutex_unlock(&data->m_total_exit) != 0)
		return ;
}

void	ft_get_total_exit(t_all *data, int *total_exit)
{
	if (pthread_mutex_lock(&data->m_total_exit) != 0)
		return ;
	*total_exit = data->total_exit;
	if (pthread_mutex_unlock(&data->m_total_exit) != 0)
		return ;
}
