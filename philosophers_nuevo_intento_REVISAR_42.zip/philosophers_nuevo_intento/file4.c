#include "philosophers.h"

void	ft_set_s_th(t_data_philosopher *d_p, long int value)
{
	if (pthread_mutex_lock(&d_p->m_s_th) != 0)
		return ;
	d_p->s_th = value;
	if (pthread_mutex_unlock(&d_p->m_s_th) != 0)
		return ;
}

int	ft_get_e_y(t_data_philosopher *d_p)
{
	int	e_y;

	e_y = -1;
	if (pthread_mutex_lock(&d_p->m_e_y) != 0)
		return (-1);
	e_y = d_p->e_y;
	if (pthread_mutex_unlock(&d_p->m_e_y) != 0)
		return (-1);
	return (e_y);
}

void	ft_set_e_y(t_data_philosopher *d_p, int value)
{
	if (pthread_mutex_lock(&d_p->m_e_y) != 0)
		return ;
	d_p->e_y = value;
	if (pthread_mutex_unlock(&d_p->m_e_y) != 0)
		return ;
}

t_data_philosopher	*ft_create_data_philosophers(t_all *data)
{
	t_data_philosopher	*d_p;
	int					n;

	n = 0;
	d_p = malloc (ft_get_n_p(data) * sizeof (*d_p));
	if (!d_p)
		return (NULL);
	ft_i_m_d_p(d_p, ft_get_n_p(data));
	while (n < ft_get_n_p(data))
	{
		ft_set_l_e(&d_p[n], -1);
		ft_set_n_e(&d_p[n], 0);
		ft_set_f_l(&d_p[n], -1);
		ft_set_f_r(&d_p[n], -1);
		ft_set_s_t(&d_p[n], -1);
		ft_set_e_y(&d_p[n], 0);
		n++;
	}
	return (d_p);
}

//------------------------FIN DATA_FILOSOFOS.C----------------------------------

//-------------------------FORKS.C-----------------------
t_fork	*ft_create_forks(int n_forks)
{
	t_fork	*forks;

	forks = malloc (n_forks * sizeof (*forks));
	if (!forks)
		return (NULL);
	return (forks);
}
