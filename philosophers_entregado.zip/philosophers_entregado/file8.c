/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file8.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/30 18:11:52 by pespinos          #+#    #+#             */
/*   Updated: 2023/06/30 18:11:52 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_set_number_of_times_eat(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->m_n_o_t_e) != 0)
		return ;
	data->n_o_t_e = value;
	if (pthread_mutex_unlock(&data->m_n_o_t_e) != 0)
		return ;
}

void	ft_set_all_out(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->m_a_o) != 0)
		return ;
	data->a_o = value;
	if (pthread_mutex_unlock(&data->m_a_o) != 0)
		return ;
}

int	ft_get_all_out(t_all *data)
{
	int	all_out;

	all_out = -1;
	if (pthread_mutex_lock(&data->m_a_o) != 0)
		return (-1);
	all_out = data->a_o;
	if (pthread_mutex_unlock(&data->m_a_o) != 0)
		return (-1);
	return (all_out);
}

int	ft_get_a_a(t_all *data)
{
	int	all_alive;

	all_alive = -1;
	if (pthread_mutex_lock(&data->m_a_a) != 0)
		return (-1);
	all_alive = data->a_a;
	if (pthread_mutex_unlock(&data->m_a_a) != 0)
		return (-1);
	return (all_alive);
}

void	ft_set_all_alive(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->m_a_a) != 0)
		return ;
	data->a_a = value;
	if (pthread_mutex_unlock(&data->m_a_a) != 0)
		return ;
}
