/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_set_all_alive.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:51:18 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:52:26 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_set_all_alive(t_all *data)
{
	if (pthread_mutex_lock(&data->m_a_alive) != 0)
		return ;
	data->all_alive = 0;
	if (pthread_mutex_unlock(&data->m_a_alive) != 0)
		return ;
}
