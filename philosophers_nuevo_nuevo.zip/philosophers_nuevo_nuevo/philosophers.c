#include "philosophers.h"

int main(int argc, char **argv)
{
    long int    *args;
    t_all       data;

    if (argc == 5 || argc == 6)
    {
        if (ft_check_args(argc, argv) == 1)
        {
            args = ft_get_args(argc, argv);
            ft_initialize_data_all(&data, args, argc - 1);
            ft_destroy_forks(data.forks, data.total_philosophers);
            free(args);
            ft_destroy_mutex_philosophers(&data);
            ft_free_all(&data);
            ft_destroy_mutexs_data(&data);
        }
        else
            printf("SE HA PRODUCIDO UN ERROR CON LOS DATOS\n");
    }
}
