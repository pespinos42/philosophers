/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philosophers.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/13 20:35:43 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/21 19:55:55 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILOSOPHERS_H
# define PHILOSOPHERS_H
# include <unistd.h>
# include <limits.h>
# include <stdlib.h>
# include <stdio.h>
# include <pthread.h>
# include <sys/time.h>

typedef struct s_philosopher
{
	int				index_philosopher;
	long			time_to_die;
	long			time_to_eat;
	long			time_to_sleep;
	int				number_of_times;
	long int		last_eating;
	int				number_exit;
	long int		start_thread;
	pthread_mutex_t	m_s_th;
	pthread_mutex_t	m_l_eat;
}	t_philosopher;

typedef struct s_fork
{
	pthread_mutex_t	fork_mutex;
	int				using;
}	t_fork;

typedef struct s_all
{
	int				total_philosophers;
	t_philosopher	*phi;
	pthread_t		*threads;
	pthread_t		t_alive;
	t_fork			*forks;
	int				active;
	pthread_mutex_t	m_a_alive;
	int				all_alive;
	pthread_mutex_t	m_message;
	pthread_mutex_t	m_active;
	pthread_mutex_t	m_read_forks;
	pthread_mutex_t	m_erase_all;
	int				total_exit;
	pthread_mutex_t	m_total_exit;
}	t_all;

typedef struct s_atoi
{
	long int	result;
	int			s;
	int			sign;
}	t_atoi;

typedef struct s_data_philosopher
{
	int			active;
	int			fork_right;
	int			fork_left;
	long int	time;
	long int	s_time;
	int			n_times;
	int			using_fork_left;
	int			using_fork_right;
	int			a_alive;
	int			total_n_times;
}	t_data_philosopher;

typedef struct s_data_all_alive
{
	int			n;
	long int	time;
	long int	time_start;
	long int	start_thread;
	long int	l_eating;
	long int	time_to_die;
	int			total_exit;
}	t_data_all_alive;

int				ft_strlen(char *str);
void			ft_initialize_data_atoi(t_atoi *d);
long int		ft_atoi(char *str);
long int		*ft_get_args(int argc, char **argv);
void			ft_print_number(long int n);
long int		ft_get_time(void);
void			ft_destroy_local_mutex(t_all *data);
void			ft_get_active(t_all *data, int *active);
void			ft_set_start_trhead(t_all *data, int active);
void			ft_get_all_alive(t_all *data, int *all_alive);
void			ft_print_message(t_all *data, int active, char *msg);
void			ft_lock_forks(t_all *data, int f_right, int f_left);
void			ft_print_eating(t_all *data, int active);
void			ft_set_last_eating(t_all *data, int active);
void			ft_unlock_forks(t_all *data, int f_right, int f_left);
void			ft_get_using_forks(t_all *data, int fork, int *u_fork);
void			ft_get_stop_time(t_all *data, int active, long int *stop_time);
void			ft_increment_total_exit(t_all *data);
void			ft_get_total_exit(t_all *data, int *total_exit);
void			*philosopher(void *arg);
void			ft_fill_data(t_philosopher *phil, long int *data, int n_arg);
t_philosopher	*ft_create_philosophers(int n_philosophers);
pthread_t		*ft_create_threads(int n_philosophers);
void			ft_initialize_threads(t_all *data);
void			ft_destroy_forks(int n_philosophers, t_fork *forks);
t_fork			*ft_create_forks(int n_philosophers);
void			ft_p_message(t_all *data, long int time, int phil, char *m);
void			*ft_all_alive(void *arg);
void			ft_destroy_mutexs(t_all *data);
void			ft_fill_t_all(t_all *data, long int *args, int n_arg);
int				ft_check_only_numbers(int argc, char **argv);
int				ft_check_limits(long int *args, int n_args);
int				ft_check_args(int argc, char **argv);
void			ft_free_all(t_all *data);

#endif