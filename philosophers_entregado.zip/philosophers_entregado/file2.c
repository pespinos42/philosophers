/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file2.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/30 18:11:40 by pespinos          #+#    #+#             */
/*   Updated: 2023/06/30 18:11:40 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_set_l_e(t_data_philosopher *d_p, long int value)
{
	if (pthread_mutex_lock(&d_p->m_l_e) != 0)
		return ;
	d_p->l_e = value;
	if (pthread_mutex_unlock(&d_p->m_l_e) != 0)
		return ;
}

int	ft_get_f_l(t_data_philosopher *d_p)
{
	int	f_l;

	f_l = -1;
	if (pthread_mutex_lock(&d_p->m_f_l) != 0)
		return (-1);
	f_l = d_p->f_l;
	if (pthread_mutex_unlock(&d_p->m_f_l) != 0)
		return (-1);
	return (f_l);
}

void	ft_set_f_l(t_data_philosopher *d_p, int value)
{
	if (pthread_mutex_lock(&d_p->m_f_l) != 0)
		return ;
	d_p->f_l = value;
	if (pthread_mutex_unlock(&d_p->m_f_l) != 0)
		return ;
}

int	ft_get_f_r(t_data_philosopher *d_p)
{
	int	f_r;

	f_r = -1;
	if (pthread_mutex_lock(&d_p->m_f_r) != 0)
		return (-1);
	f_r = d_p->f_r;
	if (pthread_mutex_unlock(&d_p->m_f_r) != 0)
		return (-1);
	return (f_r);
}

void	ft_set_f_r(t_data_philosopher *d_p, int value)
{
	if (pthread_mutex_lock(&d_p->m_f_r) != 0)
		return ;
	d_p->f_r = value;
	if (pthread_mutex_unlock(&d_p->m_f_r) != 0)
		return ;
}
