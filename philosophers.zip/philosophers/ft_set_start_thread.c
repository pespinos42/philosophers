/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_set_start_thread.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:51:20 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:52:29 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_set_start_trhead(t_all *data, int active)
{
	if (pthread_mutex_lock(&data->phi[active].m_s_th) != 0)
		return ;
	data->phi[active].start_thread = ft_get_time();
	if (pthread_mutex_unlock(&data->phi[active].m_s_th) != 0)
		return ;
}
