#ifndef PHILOSOPHERS_H
# define PHILOSOPHERS_H
# include <unistd.h>
# include <limits.h>
# include <stdlib.h>
# include <stdio.h>
# include <pthread.h>
# include <sys/time.h>

typedef struct s_data_atoi
{
	long int	result;
	int			s;
	int			sign;
}	t_data_atoi;

typedef struct s_philosopher
{
	int				index_philosopher;
	pthread_mutex_t	m_index_philosopher; //SE ENVIA EL FILOSOFO CONCRETO data->phil[n]
	long int		time_to_die;
	pthread_mutex_t	m_time_to_die; //SE ENVIA EL FILOSOFO CONCRETO data->phil[n]
	long int		time_to_eat;
	pthread_mutex_t	m_time_to_eat; //SE ENVIA EL FILOSOFO CONCRETO data->phil[n]
	long int		time_to_sleep;
	pthread_mutex_t	m_time_to_sleep; //SE ENVIA EL FILOSOFO CONCRETO data->phil[n]
	int				number_of_times;
	pthread_mutex_t	m_number_of_times; //SE ENVIA EL FILOSOFO CONCRETO data->phil[n]
	long int		last_eating;
	pthread_mutex_t	m_last_eating; //SE ENVIA EL FILOSOFO CONCRETO data->phil[n]
	int				number_exit;
	pthread_mutex_t	m_number_exit; //SE ENVIA EL FILOSOFO CONCRETO data->phil[n]
	long int		start_thread;
	pthread_mutex_t	m_start_thread; //SE ENVIA EL FILOSOFO CONCRETO data->phil[n]
}	t_philosopher;

typedef struct s_fork
{
	pthread_mutex_t	fork_mutex;
	int				using_fork;
	pthread_mutex_t	m_using_fork;
}	t_fork;


typedef struct s_all
{
	int 			total_philos; 
	pthread_mutex_t	m_total_philos; //OK
	t_philosopher	*philos;
	pthread_t		*threads;
	pthread_t		t_alive;
	int				all_alive;
	pthread_mutex_t	m_all_alive;
	t_fork			*forks;
	pthread_mutex_t	read_forks;
	int				active;
	pthread_mutex_t	m_active;
	pthread_mutex_t	m_message;
	pthread_mutex_t	m_erase_all;
	int				total_exit;
	pthread_mutex_t	m_total_exit;
}	t_all;






#endif