/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_initialize_data_all_alive.c                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:50:56 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:52:09 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_initialize_data_all_alive(t_d_a_alive *d)
{
	d->n = 0;
	d->time = -1;
	d->time_start = -1;
	d->start_thread = -1;
	d->l_eating = -1;
	d->time_to_die = -1;
	d->total_exit = -1;
}
