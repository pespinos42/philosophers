/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_last_eating.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:50:42 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:52:00 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_g_l_eating(t_all *data, t_d_a_alive *d)
{
	if (pthread_mutex_lock(&data->phi[d->n].m_l_eat) != 0)
		return ;
	d->l_eating = data->phi[d->n].last_eating;
	if (pthread_mutex_unlock(&data->phi[d->n].m_l_eat) != 0)
		return ;
}
