/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lock_forks.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:50:59 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:52:14 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_lock_forks(t_all *data, int f_right, int f_left)
{
	if (pthread_mutex_lock(&data->m_read_forks) != 0)
		return ;
	data->forks[f_right].using = 1;
	data->forks[f_left].using = 1;
	if (pthread_mutex_unlock(&data->m_read_forks) != 0)
		return ;
	if (pthread_mutex_lock(&data->forks[f_right].fork_mutex) != 0)
		return ;
	if (pthread_mutex_lock(&data->forks[f_left].fork_mutex) != 0)
		return ;
}

void	ft_unlock_forks(t_all *data, int f_right, int f_left)
{
	if (pthread_mutex_unlock(&data->forks[f_left].fork_mutex) != 0)
		return ;
	if (pthread_mutex_unlock(&data->forks[f_right].fork_mutex) != 0)
		return ;
	if (pthread_mutex_lock(&data->m_read_forks) != 0)
		return ;
	data->forks[f_left].using = 0;
	data->forks[f_right].using = 0;
	if (pthread_mutex_unlock(&data->m_read_forks) != 0)
		return ;
}
