#include "philosophers.h"

int		ft_get_number_philosophers(t_all *data)
{
	int	number_philosophers;

	number_philosophers = -1;
	if (pthread_mutex_lock(&data->mutex_number_philosophers) != 0)
		return (-1);
	number_philosophers = data->number_philosophers;
	if (pthread_mutex_unlock(&data->mutex_number_philosophers) != 0)
		return (-1);
	return (number_philosophers);
}

void	ft_set_number_philosophers(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->mutex_number_philosophers) != 0)
		return ;
	data->number_philosophers = value;
	if (pthread_mutex_unlock(&data->mutex_number_philosophers) != 0)
		return ;
}

long int	ft_get_time_to_die(t_all *data)
{
	long int	time_to_die;

	time_to_die = -1;
	if (pthread_mutex_lock(&data->mutex_time_to_die) != 0)
		return (-1);
	time_to_die = data->time_to_die;
	if (pthread_mutex_unlock(&data->mutex_time_to_die) != 0)
		return (-1);
	return (time_to_die);
}

void	ft_set_time_to_die(t_all *data, long int value)
{
	if (pthread_mutex_lock(&data->mutex_time_to_die) != 0)
		return ;
	data->time_to_die = value;
	if (pthread_mutex_unlock(&data->mutex_time_to_die) != 0)
		return ;
}

long int	ft_get_time_to_eat(t_all *data)
{
	long int	time_to_eat;

	time_to_eat = -1;
	if (pthread_mutex_lock(&data->mutex_time_to_eat) != 0)
		return (-1);
	time_to_eat = data->time_to_eat;
	if (pthread_mutex_unlock(&data->mutex_time_to_eat) != 0)
		return (-1);
	return (time_to_eat);
}

void	ft_set_time_to_eat(t_all *data, long int value)
{
	if (pthread_mutex_lock(&data->mutex_time_to_eat) != 0)
		return ;
	data->time_to_eat = value;
	if (pthread_mutex_unlock(&data->mutex_time_to_eat) != 0)
		return ;
}

long int	ft_get_time_to_sleep(t_all *data)
{
	long int	time_to_sleep;

	time_to_sleep = -1;
	if (pthread_mutex_lock(&data->mutex_time_to_sleep) != 0)
		return (-1);
	time_to_sleep = data->time_to_sleep;
	if (pthread_mutex_unlock(&data->mutex_time_to_sleep) != 0)
		return (-1);
	return (time_to_sleep);
}

void	ft_set_time_to_sleep(t_all *data, long int value)
{
	if (pthread_mutex_lock(&data->mutex_time_to_sleep) != 0)
		return ;
	data->time_to_sleep = value;
	if (pthread_mutex_unlock(&data->mutex_time_to_sleep) != 0)
		return ;
}

int	ft_get_number_of_times_eat(t_all *data)
{
	int	number_of_times;

	number_of_times = -1;
	if (pthread_mutex_lock(&data->mutex_number_of_times_eat) != 0)
		return (-1);
	number_of_times = data->number_of_times_eat;
	if (pthread_mutex_unlock(&data->mutex_number_of_times_eat) != 0)
		return (-1);
	return (number_of_times);
}

void	ft_set_number_of_times_eat(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->mutex_number_of_times_eat) != 0)
		return ;
	data->number_of_times_eat = value;
	if (pthread_mutex_unlock(&data->mutex_number_of_times_eat) != 0)
		return ;
}

void	ft_initialize_data_atoi(t_atoi *d)
{
	d->result = 0;
	d->s = 0;
	d->sign = 1;
}

long int	ft_atoi(char *str)
{
	t_atoi	d;

	ft_initialize_data_atoi(&d);
	while ((*str >= 9 && *str <= 13) || *str == 32)
		str++;
	if (*str == '+')
	{
		d.s++;
		str++;
	}
	if (*str == '-' && d.s == 0)
	{
		d.sign = -1;
		str++;
	}
	if (*str == '-' && d.s == 1)
		d.sign = 0;
	while (*str >= '0' && *str <= '9')
	{
		d.result = d.result * 10 + (*str - 48);
		str++;
	}
	return (d.sign * d.result);
}

int	ft_strlen(char *str)
{
	int len;

	len = 0;
	while (str[len])
		len++;
	return (len);
}

long int	*ft_get_args(int argc, char **argv)
{
	long int	*args;
	int			n;

	n = 1;
	args = malloc ((argc - 1) * sizeof (*args));
	if (!args)
		return (NULL);
	while (n < argc)
	{
		args[n - 1] = ft_atoi(argv[n]);
		n++;
	}
	return (args);
}

int	ft_check_only_numbers(int argc, char **argv)
{
	int	arg;
	int	letter;
	int	check;

	arg = 1;
	letter = 0;
	check = 1;
	while (arg < argc && check == 1)
	{
		while (letter < ft_strlen(argv[arg]) && check == 1)
		{
			if (argv[arg][letter] < 48 || argv[arg][letter] > 57)
				check = 0;
			letter++;
		}
		letter = 0;
		arg++;
	}
	return (check);
}

int	ft_check_limits(long int *args, int n_args)
{
	int	n;
	int	check;

	n = 0;
	check = 1;
	while (n < n_args && check == 1)
	{
		if (args[n] > 2147483647)
			check = 0;
		n++;
	}
	return (check);
}

int	ft_check_args(int argc, char **argv)
{
	long int	*args;

	if (ft_check_only_numbers(argc, argv) != 1)
		return (-1);
	args = ft_get_args(argc, argv);
	if (ft_check_limits(args, argc - 1) != 1)
		return (free (args), -1);
	if (args[0] <= 0)
		return (free (args), -1);
	if (argc == 6 && args[4] <= 0)
		return (free (args), -1);
	free (args);
	return (1);
}

//------------------------------------PARA BORRAR

void ft_print_args(long int *args, int argc)
{
	printf("ARGS[0] = %li\n", args[0]);
	printf("ARGS[1] = %li\n", args[1]);
	printf("ARGS[2] = %li\n", args[2]);
	printf("ARGS[3] = %li\n", args[3]);
	if (argc == 6)
		printf("ARGS[4] = %li\n", args[4]);
}

//------------------------------------

void	ft_init_mutex_data(t_all *data)
{
	if (pthread_mutex_init(&data->mutex_number_philosophers, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->mutex_time_to_die, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->mutex_time_to_eat, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->mutex_time_to_sleep, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->mutex_number_of_times_eat, NULL) != 0)
		return ;
}

void	ft_fill_data(t_all *data, long int *args, int argc)
{
	ft_init_mutex_data(data);
	ft_set_number_philosophers(data, args[0]);
	ft_set_time_to_die(data, args[1]);
	ft_set_time_to_eat(data, args[2]);
	ft_set_time_to_sleep(data, args[3]);
	if (argc == 6)
		ft_set_number_of_times_eat(data, args[4]);
}

int main(int argc, char **argv)
{
	long int    *args;
	t_all       data;

	if (argc == 5 || argc == 6)
	{
		if (ft_check_args(argc, argv) == 1)
		{
			args = ft_get_args(argc, argv);
			//ft_print_args(args, argc);
			ft_fill_data(&data, args, argc);
		}
		else
			printf("PARAMETROS ERRONEOS\n");
	}
}