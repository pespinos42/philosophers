#include "philosophers.h"

void	ft_increment_total_exit(t_all *data)
{
	if (pthread_mutex_lock(&data->m_total_exit) != 0)
		return ;
	data->total_exit = data->total_exit + 1;
	if (pthread_mutex_unlock(&data->m_total_exit) != 0)
		return ;
}

void	ft_get_total_exit(t_all *data, int *total_exit)
{
	if (pthread_mutex_lock(&data->m_total_exit) != 0)
		return ;
	*total_exit = data->total_exit;
	if (pthread_mutex_unlock(&data->m_total_exit) != 0)
		return ;
}