#include "philosophers.h"

int	ft_check_args(int argc, char **argv)
{
	long int	*args;

	if (ft_check_only_numbers(argc, argv) != 1)
		return (-1);
	args = ft_get_args(argc, argv);
	if (ft_check_limits(args, argc - 1) != 1)
		return (free (args), -1);
	if (args[0] <= 0 || args[0] > 200)
		return (free (args), -1);
	if (argc == 6 && args[4] <= 0)
		return (free (args), -1);
	free (args);
	return (1);
}
//-------------------------------------FIN ARGS.C------------------------------

//------------------------------------
void	ft_p_m(t_all *data, long int time, int p, char *message)
{
	if (pthread_mutex_lock(&data->m_m) != 0)
		return ;
	ft_print_number(time);
	write(1, " ", 1);
	ft_print_number(p);
	write(1, message, ft_strlen(message));
	write(1, "\n", 1);
	if (pthread_mutex_unlock(&data->m_m) != 0)
		return ;
}

void	ft_wait(t_all *data, long int time_to_wait)
{
	long int	s_t;

	s_t = ft_get_t() + time_to_wait;
	while (s_t > ft_get_t() && ft_get_a_a(data) == 1)
		usleep(100);
}

void	ft_data_philosopher(t_temp *temp)
{
	temp->t_t_d = -1;
	temp->t_t_e = -1;
	temp->l_e = -1;
	temp->s_t = -1;
	temp->n_e = -1;
	temp->a = -1;
}

void	ft_assign_forks(t_all *d, t_temp *t)
{
	ft_set_f_r(&d->d_p[t->a], ft_get_i_p(&d->d_p[t->a]));
	if (ft_get_i_p(&d->d_p[t->a]) == ft_get_n_p(d) - 1)
		ft_set_f_l(&d->d_p[t->a], 0);
	else
		ft_set_f_l(&d->d_p[t->a], ft_get_i_p(&d->d_p[t->a]) + 1);
}
