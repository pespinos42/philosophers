#include "philosophers.h"

void	ft_free_all(t_all *data)
{
	if (pthread_mutex_lock(&data->m_erase_all) != 0)
		return ;
	free (data->phi);
	free (data->forks);
	free (data->threads);
	if (pthread_mutex_unlock(&data->m_erase_all) != 0)
		return ;
}