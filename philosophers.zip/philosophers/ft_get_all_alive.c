#include "philosophers.h"

void	ft_get_all_alive(t_all *data, int *all_alive)
{
	if (pthread_mutex_lock(&data->m_a_alive) != 0)
		return ;
	*all_alive = data->all_alive;
	if (pthread_mutex_unlock(&data->m_a_alive) != 0)
		return ;
}