#include "philosophers.h"

int ft_get_total_philosophers(t_all *data)
{
    int total_philosophers;

    total_philosophers = -1;
    if (pthread_mutex_lock(&data->mutex_total_philosophers) != 0)
        return (-1);
    total_philosophers = data->total_philosophers;
    if (pthread_mutex_unlock(&data->mutex_total_philosophers) != 0)
        return (-1);
    return (total_philosophers);
}

void    ft_set_total_philosophers(t_all *data, int value)
{
    if (pthread_mutex_lock(&data->mutex_total_philosophers) != 0)
        return ;
    data->total_philosophers = value;
    if (pthread_mutex_unlock(&data->mutex_total_philosophers) != 0)
        return ;
}

int ft_get_active(t_all *data)
{
    int active;

    active = -1;
    if (pthread_mutex_lock(&data->mutex_active) != 0)
        return (-1);
    active = data->active;
    if (pthread_mutex_unlock(&data->mutex_active) != 0)
        return (-1);
    return (active);
}

void    ft_set_active(t_all *data, int value)
{
    if (pthread_mutex_lock(&data->mutex_active) != 0)
        return ;
    data->active = value;
    if (pthread_mutex_unlock(&data->mutex_active) != 0)
        return ;
}

int ft_get_all_alive(t_all *data)
{
    int all_alive;

    all_alive = -1;
    if (pthread_mutex_lock(&data->mutex_all_alive) != 0)
        return (-1);
    all_alive = data->all_alive;
    if (pthread_mutex_unlock(&data->mutex_all_alive) != 0)
        return (-1);
    return (all_alive);
}

void    ft_set_all_alive(t_all *data, int value)
{
    if (pthread_mutex_lock(&data->mutex_all_alive) != 0)
        return ;
    data->all_alive = value;
    if (pthread_mutex_unlock(&data->mutex_all_alive) != 0)
        return ;
}

int ft_get_total_exit(t_all *data)
{
    int total_exit;

    total_exit = -1;
    if (pthread_mutex_lock(&data->mutex_total_exit) != 0)
        return (-1);
    total_exit = data->total_exit;
    if (pthread_mutex_unlock(&data->mutex_total_exit) != 0)
        return (-1);
    return (total_exit);
}

void    ft_set_total_exit(t_all *data, int value)
{
    if (pthread_mutex_lock(&data->mutex_total_exit) != 0)
        return ;
    data->total_exit = value;
    if (pthread_mutex_unlock(&data->mutex_total_exit) != 0)
        return ;
}

void    ft_init_mutexs_data(t_all *data)
{
    if (pthread_mutex_init(&data->mutex_total_philosophers, NULL) != 0)
        return ;
    if (pthread_mutex_init(&data->mutex_active, NULL) != 0)
        return ;
    if (pthread_mutex_init(&data->mutex_all_alive, NULL) != 0)
        return ;
    if (pthread_mutex_init(&data->mutex_message, NULL) != 0)
        return ;
    if (pthread_mutex_init(&data->mutex_read_forks, NULL) != 0)
        return ;
    if (pthread_mutex_init(&data->mutex_total_exit, NULL) != 0)
        return ;
}

pthread_t   *ft_create_threads(int n_philosophers)
{
    pthread_t   *threads;

    threads = malloc (n_philosophers * sizeof(*threads));
    if (!threads)
        return (NULL);
    
}

void    ft_initialize_data_all(t_all *data, long int *args, int n_args)
{
    ft_init_mutexs_data(data);
    ft_set_total_philosophers(data, args[0]);
    data->phi = ft_create_philosophers(args[0]);
    ft_init_mutexs_philosophers(data);
    ft_initialize_data_philosophers(data, args, n_args);
    data->forks = ft_create_forks(args[0]);
    ft_set_all_alive(data, 1);
    data->threads = ft_create_threads(args[0]);
    ft_set_total_exit(data, 0);
    if (pthread_create(&data->t_alive, NULL, ft_thread_all_alive, data) != 0)
        return ;
}
