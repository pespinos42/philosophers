#include "philosophers.h"

//------------------- ATOI.c -------------------------

int	ft_strlen(char *str)
{
	int	len;

	len = 0;
	while (str[len])
		len++;
	return (len);
}

void	ft_initialize_data_atoi(t_data_atoi *d)
{
	d->result = 0;
	d->s = 0;
	d->sign = 1;
}

long int	ft_atoi(char *str)
{
	t_data_atoi	d;

	ft_initialize_data_atoi(&d);
	while ((*str >= 9 && *str <= 13) || *str == 32)
		str++;
	if (*str == '+')
	{
		d.s++;
		str++;
	}
	if (*str == '-' && d.s == 0)
	{
		d.sign = -1;
		str++;
	}
	if (*str == '-' && d.s == 1)
		d.sign = 0;
	while (*str >= '0' && *str <= '9')
	{
		d.result = d.result * 10 + (*str - 48);
		str++;
	}
	return (d.sign * d.result);
}
//-------------------FIN ATOI.C-------------------

//------------------- ARGS.c -------------------------
long int    *ft_get_args(int argc, char **argv)
{
	long int	*args;
	int			n;

	n = 1;
	args = malloc ((argc - 1) * sizeof (*args));
	if (!args)
		return (NULL);
	while (n < argc)
	{
		args[n - 1] = ft_atoi(argv[n]);
		n++;
	}
	return (args);
}

int ft_check_only_numbers(int argc, char **argv)
{
	int	arg;
	int	letter;
	int	check;

	arg = 1;
	letter = 0;
	check = 1;
	while (arg < argc && check == 1)
	{
		while (letter < ft_strlen(argv[arg]) && check == 1)
		{
			if (argv[arg][letter] < 48 || argv[arg][letter] > 57)
				check = 0;
			letter++;
		}
		letter = 0;
		arg++;
	}
	return (check);
}

int ft_check_limits(long int *args, int n_args)
{
	int	n;
	int	check;

	n = 0;
	check = 1;
	while (n < n_args && check == 1)
	{
		if (args[n] > 2147483647)
			check = 0;
		n++;
	}
	return (check); 
}

long int *ft_check_args(int argc, char **argv)
{
	long int    *args;

	if (ft_check_only_numbers(argc, argv) != 1)
		return (NULL);
	args = ft_get_args(argc, argv);
	if (ft_check_limits(args, argc - 1) != 1)
		return (free (args), NULL);
	if (args[0] <= 0)
		return (free (args), NULL);
	if (argc == 6 && args[4] <= 0)
		return (free (args), NULL);
	return (args);
}
//----------------FIN ARGS.c-------------------------

//-----------------INICIO TOTAL_PHILOS.c-----------
int	ft_get_total_philos(t_all *data)
{
	int	total_philos;

	total_philos = -1;
	if (pthread_mutex_lock(&data->m_total_philos) != 0)
		return (-1);
	total_philos = data->total_philos;
	if (pthread_mutex_unlock(&data->m_total_philos) != 0)
		return (-1);
	return (total_philos);
}

void	ft_set_total_philos(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->m_total_philos) != 0)
		return ;
	data->total_philos = value;
	if (pthread_mutex_unlock(&data->m_total_philos) != 0)
		return ;
}
//---------------------FIN TOTAL_PHILOS-------------------

//---------------------INICIO ALL_ALIVE-------------------
int	ft_get_all_alive(t_all *data)
{
	int	all_alive;

	all_alive = -1;
	if (pthread_mutex_lock(&data->m_all_alive) != 0)
		return (-1);
	all_alive = data->all_alive;
	if (pthread_mutex_unlock(&data->m_all_alive) != 0)
		return (-1);
	return (all_alive);
}

void	ft_set_all_alive(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->m_all_alive) != 0)
		return ;
	data->all_alive = value;
	if (pthread_mutex_unlock(&data->m_all_alive) != 0)
		return ;
}
//-------------------FIN ALL_ALIVE--------------------

//--------------INICIO FT_INIT_GENERAL_MUTEX-----------------
void	ft_init_general_mutex(t_all *data)
{
	if (pthread_mutex_init(&data->m_total_philos, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_all_alive, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->read_forks, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_active, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_message, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_erase_all, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_total_exit, NULL) != 0)
		return ;
}
//-------------FIN FT_INIT_GENERAL_MUTEX-------------------


//-------------INICIO FT_CREATE_PHILOSOPHERS----------
t_philosopher	*ft_create_philosophers(int	n_philosophers)
{
	t_philosopher	*philosophers;
	int				n;

	n = 0;
	philosophers = malloc (n_philosophers * sizeof (*philosophers));
	if (!philosophers)
		return (NULL);
	return (philosophers);
}
//-----------------FIN FT_CREATE_PHILOSOPHERS---------

//------------------INICIO FT_INIT_LOCAL_MUTEX--------------
void	ft_init_local_mutex(t_philosopher *phil, int total_philosophers)
{
	int	n;

	n = 0;
	while (n < total_philosophers)
	{
		if (pthread_mutex_init(&phil[n].m_index_philosopher, NULL) != 0)
			return ;
		if (pthread_mutex_init(&phil[n].m_time_to_die, NULL) != 0)
			return ;
		if (pthread_mutex_init(&phil[n].m_time_to_eat, NULL) != 0)
			return ;
		if (pthread_mutex_init(&phil[n].m_time_to_sleep, NULL) != 0)
			return ;
		if (pthread_mutex_init(&phil[n].m_number_of_times, NULL) != 0)
			return ;
		if (pthread_mutex_init(&phil[n].m_last_eating, NULL) != 0)
			return ;
		if (pthread_mutex_init(&phil[n].m_number_exit, NULL) != 0)
			return ;
		if (pthread_mutex_init(&phil[n].m_start_thread, NULL) != 0)
			return ;
		n++;
	}
}
//------------------FIN FIT_INIT_LOCAL_MUTEX--------------

//---------------------INICIO INDEX_PHILOSOPHER--------------------
int	ft_get_index_philosopher(t_philosopher *phil)
{
	int	index_philosopher;

	index_philosopher = -1;
	if (pthread_mutex_lock(&phil->m_index_philosopher) != 0)
		return (-1);
	index_philosopher = phil->index_philosopher;
	if (pthread_mutex_unlock(&phil->m_index_philosopher) != 0)
		return (-1);
	return (index_philosopher);
}

void	ft_set_index_philosopher(t_philosopher *phil, int value)
{
	if (pthread_mutex_lock(&phil->m_index_philosopher) != 0)
		return ;
	phil->index_philosopher = value;
	if (pthread_mutex_unlock(&phil->m_index_philosopher) != 0)
		return ;
}
//--------------------FIN INDEX_PHILOSOPHER------------------------

//---------------------INICIO TIME_TO_DIE-------------------
long int	ft_get_time_to_die(t_philosopher *phil)
{
	long int	time_to_die;

	time_to_die = -1;
	if (pthread_mutex_lock(&phil->m_time_to_die) != 0)
		return (-1);
	time_to_die = phil->time_to_die;
	if (pthread_mutex_unlock(&phil->m_time_to_die) != 0)
		return (-1);
	return (time_to_die);
}

void	ft_set_time_to_die(t_philosopher *phil, long int time_to_die)
{
	if (pthread_mutex_lock(&phil->m_time_to_die) != 0)
		return ;
	phil->time_to_die = time_to_die;
	if (pthread_mutex_unlock(&phil->m_time_to_die) != 0)
		return ;
}
//---------------------FIN TIME_TO_DIE------------------

//---------------------INICIO TIME_TO_EAT-------------------
long int	ft_get_time_to_eat(t_philosopher *phil)
{
	long int	time_to_eat;

	time_to_eat = -1;
	if (pthread_mutex_lock(&phil->m_time_to_eat) != 0)
		return (-1);
	time_to_eat = phil->time_to_eat;
	if (pthread_mutex_unlock(&phil->m_time_to_eat) != 0)
		return (-1);
	return (time_to_eat);
}

void	ft_set_time_to_eat(t_philosopher *phil, long int time_to_eat)
{
	if (pthread_mutex_lock(&phil->m_time_to_eat) != 0)
		return ;
	phil->time_to_eat = time_to_eat;
	if (pthread_mutex_unlock(&phil->m_time_to_eat) != 0)
		return ;
}
//---------------------FIN TIME_TO_EAT------------------

//---------------------INICIO TIME_TO_SLEEP-------------------
long int	ft_get_time_to_sleep(t_philosopher *phil)
{
	long int	time_to_sleep;

	time_to_sleep = -1;
	if (pthread_mutex_lock(&phil->m_time_to_sleep) != 0)
		return (-1);
	time_to_sleep = phil->time_to_sleep;
	if (pthread_mutex_unlock(&phil->m_time_to_sleep) != 0)
		return (-1);
	return (time_to_sleep);
}

void	ft_set_time_to_sleep(t_philosopher *phil, long int time_to_sleep)
{
	if (pthread_mutex_lock(&phil->m_time_to_sleep) != 0)
		return ;
	phil->time_to_sleep = time_to_sleep;
	if (pthread_mutex_unlock(&phil->m_time_to_sleep) != 0)
		return ;
}
//---------------------FIN TIME_TO_SLEEP------------------

//----------------INICIO NUMBER_OF_TIMES-----------------
int	ft_get_number_of_times(t_philosopher *phil)
{
	int	number_of_times;

	number_of_times = -1;
	if (pthread_mutex_lock(&phil->m_number_of_times) != 0)
		return (-1);
	number_of_times = phil->number_of_times;
	if (pthread_mutex_unlock(&phil->m_number_of_times) != 0)
		return (-1);
	return (number_of_times);
}

void	ft_set_number_of_times(t_philosopher *phil, int value)
{
	if (pthread_mutex_lock(&phil->m_number_of_times) != 0)
		return ;
	phil->number_of_times = value;
	if (pthread_mutex_unlock(&phil->m_number_of_times) != 0)
		return ;
}
//-------------------FIN NUMBER_OF_TIMES-----------------

//---------------------INICIO LAST_EATING-----------------
long int	ft_get_last_eating(t_philosopher *phil)
{
	long int	last_eating;

	last_eating = -1;
	if (pthread_mutex_lock(&phil->m_last_eating) != 0)
		return (-1);
	last_eating = phil->last_eating;
	if (pthread_mutex_unlock(&phil->m_last_eating) != 0)
		return (-1);
	return (last_eating);
}

void	ft_set_last_eating(t_philosopher *phil, long int value)
{
	if (pthread_mutex_lock(&phil->m_last_eating) != 0)
		return ;
	phil->last_eating = value;
	if (pthread_mutex_unlock(&phil->m_last_eating) != 0)
		return ;
}
//-----------------------FIN LAST_EATING-----------------

//-------------------------INICIO NUMBER_EXIT----------------
int	ft_get_number_exit(t_philosopher *phil)
{
	int	number_exit;

	number_exit = -1;
	if (pthread_mutex_lock(&phil->m_number_exit) != 0)
		return (-1);
	number_exit = phil->number_exit;
	if (pthread_mutex_unlock(&phil->m_number_exit) != 0)
		return (-1);
	return (number_exit);
}

void	ft_set_number_exit(t_philosopher *phil, int value)
{
	if (pthread_mutex_lock(&phil->m_number_exit) != 0)
		return ;
	phil->number_exit = value;
	if (pthread_mutex_lock(&phil->m_number_exit) != 0)
		return ;
}
//---------------------------FIN NUMBER_EXIT-------------------

//-----------------------INICIO START_THREAD----------------
long int	ft_get_start_thread(t_philosopher *phil)
{
	long int	start_thread;

	start_thread = -1;
	if (pthread_mutex_lock(&phil->m_start_thread) != 0)
		return (-1);
	start_thread = phil->start_thread;
	if (pthread_mutex_unlock(&phil->m_start_thread) != 0)
		return (-1);
	return (start_thread);
}

void	ft_set_start_thread(t_philosopher *phil, long int value)
{
	if (pthread_mutex_lock(&phil->m_start_thread) != 0)
		return ;
	phil->start_thread = value;
	if (pthread_mutex_unlock(&phil->m_start_thread) != 0)
		return ;
}
//----------------------------FIN START_THREAD-----------------

//----------------INICIO FT_FILL_DATA-----------
void	ft_fill_data(t_philosopher *phil, long int *args, int n_args)
{
	int	n;

	n = 0;
	ft_init_local_mutex(phil, args[0]);
	while (n < args[0])
	{
		ft_set_index_philosopher(&phil[n], n + 1);
		printf("n -> %i INDEX PHILOSOPHER -> %i\n", n, ft_get_index_philosopher(&phil[n]));
		ft_set_time_to_die(&phil[n], args[1]);
		printf("n -> %i TIME_TO_DIE -> %li\n", n, ft_get_time_to_die(&phil[n]));
		ft_set_time_to_eat(&phil[n], args[2]);
		printf("n -> %i TIME_TO_EAT -> %li\n", n, ft_get_time_to_eat(&phil[n]));
		ft_set_time_to_sleep(&phil[n], args[3]);
		printf("n -> %i TIME_TO_SLEEP -> %li\n", n, ft_get_time_to_sleep(&phil[n]));
		if (n_args == 5)
			ft_set_number_of_times(&phil[n], args[4]);
		else
			ft_set_number_of_times(&phil[n], -1);
		n++;
	}
}
//--------------FIN FT_FILL_DATA--------------

//---------------------INICIO FORKS-------------------------
int	ft_get_using_fork(t_fork *fork)
{
	int	using_fork;

	using_fork = -1;
	if (pthread_mutex_lock(&fork->m_using_fork) != 0)
		return (-1);
	using_fork = fork->using_fork;
	if (pthread_mutex_unlock(&fork->m_using_fork) != 0)
		return (-1);
	return (using_fork);
}

void	ft_set_using_fork(t_fork *fork, int value)
{
	if (pthread_mutex_lock(&fork->m_using_fork) != 0)
		return ;
	fork->using_fork = value;
	if (pthread_mutex_unlock(&fork->m_using_fork) != 0)
		return ;
}

t_fork	*ft_create_forks(int total_philosophers)
{
	t_fork	*forks;
	int		n;

	n = 0;
	forks = malloc (total_philosophers * sizeof (*forks));
	if (!forks)
		return (NULL);
	while (n < total_philosophers)
	{
		if (pthread_mutex_init(&forks[n].fork_mutex, NULL) != 0)
			return (NULL);
		if (pthread_mutex_init(&forks[n].m_using_fork, NULL) != 0)
			return (NULL);
		ft_set_using_fork(&forks[n], 0);
		n++;
	}
	return (forks);
}

void	ft_destroy_forks(t_fork *forks, int total_forks)
{
	int	n;

	n = 0;
	while (n < total_forks)
	{
		if (pthread_mutex_destroy(&forks[n].fork_mutex) != 0)
			return ;
		if (pthread_mutex_destroy(&forks[n].m_using_fork) != 0)
			return ;
		n++;
	}
}
//-----------------------FIN FORKS------------------------

//------------------INICIO FT_FILL_T_ALL---------------
void	ft_fill_t_all(t_all *data, long int *args, int n_args)
{
	ft_init_general_mutex(data);
	ft_set_total_philos(data, args[0]);
	data->philos = ft_create_philosophers(args[0]);
	ft_fill_data(data->philos, args, n_args);
	data->forks = ft_create_forks(args[0]);
	ft_set_all_alive(data, 1);
	printf("FORKS FILOSOFO %i USING %i\n", ft_get_index_philosopher(&data->philos[2]), ft_get_using_fork(&data->forks[2]));
	printf("ALL ALIVE %i\n", ft_get_all_alive(data));
	printf("OK\n");
}
//----------------FIN FT_FILL_T_ALL------------------

int main(int argc, char **argv)
{
	long int    *args;
	t_all       all_philosophers;

	args = NULL;
	if (argc == 5 || argc == 6)
	{
		args = ft_check_args(argc, argv);
		if (args != NULL)
		{
			ft_fill_t_all(&all_philosophers, args, argc - 1);
			free(args);
		}
		else
			write(1, "ARGUMENTO INVALIDO\n", 19);
	}
	return (0);
}