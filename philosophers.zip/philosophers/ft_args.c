#include "philosophers.h"

long int	*ft_get_args(int argc, char **argv)
{
	long int	*args;
	int			n;

	n = 1;
	args = malloc ((argc - 1) * sizeof (*args));
	if (!args)
		return (NULL);
	while (n < argc)
	{
		args[n - 1] = ft_atoi(argv[n]);
		n++;
	}
	return (args);
}

int	ft_check_only_numbers(int argc, char **argv)
{
	int	arg;
	int	letter;
	int	check;

	arg = 1;
	letter = 0;
	check = 1;
	while (arg < argc && check == 1)
	{
		while (letter < ft_strlen(argv[arg]) && check == 1)
		{
			if (argv[arg][letter] < 48 || argv[arg][letter] > 57)
				check = 0;
			letter++;
		}
		letter = 0;
		arg++;
	}
	return (check);
}

int	ft_check_limits(long int *args, int n_args)
{
	int	n;
	int	check;

	n = 0;
	check = 1;
	while (n < n_args && check == 1)
	{
		if (args[n] > 2147483647)
			check = 0;
		n++;
	}
	return (check);
}

int	ft_check_args(int argc, char **argv)
{
	long int	*args;

	if (ft_check_only_numbers(argc, argv) != 1)
		return (-1);
	args = ft_get_args(argc, argv);
	if (ft_check_limits(args, argc - 1) != 1)
		return (free (args), -1);
	if (args[0] <= 0)
		return (free (args), -1);
	if (argc == 6 && args[4] <= 0)
		return (free (args), -1);
	free (args);
	return (1);
}