#include "philosophers.h"

long int	ft_get_time(void)
{
	struct timeval	tv;

	gettimeofday(&tv, NULL);
	return ((tv.tv_sec * 1000) + (tv.tv_usec / 1000));
}

void    ft_initialize_data_all_alive(t_all *data, t_data_all_alive *d)
{
    d->local_n = 0;
    d->local_time = -1;
    d->local_time_start = -1;
    d->local_start_thread = -1;
    d->local_l_eating = -1;
    d->local_time_to_die = -1;
    d->local_total_exit = ft_get_total_exit(data);
    d->global_all_alive = -1;
    d->global_total_philosophers = ft_get_total_philosophers(data);
}

void	ft_print_number(long int n)
{
	char	number;

	number = 0;
	if (n == INT_MIN)
		write(1, "-2147483648", 11);
	else if (n < 0)
	{
		write(1, "-", 1);
		ft_print_number(-n);
	}
	else
	{
		if (n > 9)
			ft_print_number(n / 10);
		number = (n % 10) + 48;
		write(1, &number, 1);
	}
}

void	ft_p_message(t_all *data, long int time, int phil, char *m)
{
    if (pthread_mutex_lock(&data->mutex_message) != 0)
        return ;
	ft_print_number(time);
	write(1, " ", 1);
	ft_print_number(data->phi[phil].index_philosopher);
	write(1, " ", 1);
	write(1, m, ft_strlen(m));
	write(1, "\n", 1);
    if (pthread_mutex_unlock(&data->mutex_message) != 0)
        return ;
}

void    *ft_thread_all_alive(void *arg)
{
    t_all               *data;
    t_data_all_alive    d;

    data = (t_all *) arg;
    d.global_all_alive = ft_get_all_alive(data);
    while (d.global_all_alive == 1 && d.local_total_exit < d.global_total_philosophers)
    {
        d.global_all_alive = ft_get_all_alive(data);
        while (d.local_n < d.global_total_philosophers && d.global_all_alive == 1)
        {
            d.local_start_thread = ft_get_start_thread(&data->phi[d.local_n]);
            if (d.local_start_thread != -1)
            {
                d.local_l_eating = ft_get_last_eating(&data->phi[d.local_n]);
                if (d.local_l_eating == -1)
                    d.local_time_start = ft_get_start_thread(&data->phi[d.local_n]);
                else
                    d.local_time_start = ft_get_last_eating(&data->phi[d.local_n]);
                d.local_time = ft_get_time();
                d.local_time_to_die = ft_get_time_to_die(&data->phi[d.local_n]);
                if ((d.local_time - d.local_time_start) >= d.local_time_to_die)
                {
                    if (ft_get_number_exit(&data->phi[d.local_n]) == 0)
                    {
                        ft_set_all_alive(data, 0);
                        ft_p_message(data, d.local_time, d.local_n, " died");
                    }
                }
            }
            d.local_n++;
        }
        d.local_n = 0;
        usleep(1000);
        d.local_total_exit = ft_get_total_exit(data);
        d.global_all_alive = ft_get_all_alive(data);
    }
}