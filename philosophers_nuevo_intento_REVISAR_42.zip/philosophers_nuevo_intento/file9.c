#include "philosophers.h"

int	ft_get_total_exit(t_all *data)
{
	int	total_exit;

	total_exit = -1;
	if (pthread_mutex_lock(&data->m_t_e) != 0)
		return (-1);
	total_exit = data->t_e;
	if (pthread_mutex_unlock(&data->m_t_e) != 0)
		return (-1);
	return (total_exit);
}

void	ft_set_total_exit(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->m_t_e) != 0)
		return ;
	data->t_e = value;
	if (pthread_mutex_unlock(&data->m_t_e) != 0)
		return ;
}

void	ft_init_mutex_data(t_all *data)
{
	if (pthread_mutex_init(&data->m_n_p, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_a_a, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_t_t_d, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_t_t_e, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_t_t_s, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_n_o_t_e, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->mutex_active, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_m, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_a_o, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_t_e, NULL) != 0)
		return ;
}

void	ft_destroy_mutex_data(t_all *data)
{
	if (pthread_mutex_destroy(&data->m_n_p) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_a_a) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_t_t_d) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_t_t_e) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_t_t_s) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_n_o_t_e) != 0)
		return ;
	if (pthread_mutex_destroy(&data->mutex_active) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_m) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_a_o) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_t_e) != 0)
		return ;
}
//------------------------------------------FIN ALL.C----------------------
//-----------------------------------ATOI.C---------------------------------

void	ft_initialize_data_atoi(t_atoi *d)
{
	d->result = 0;
	d->s = 0;
	d->sign = 1;
}
