/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_all_alive.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:50:40 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:51:59 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_get_all_alive(t_all *data, int *all_alive)
{
	if (pthread_mutex_lock(&data->m_a_alive) != 0)
		return ;
	*all_alive = data->all_alive;
	if (pthread_mutex_unlock(&data->m_a_alive) != 0)
		return ;
}
