/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_states.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:51:21 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 17:59:44 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_eating(t_all *data, t_data_philosopher *d)
{
	ft_get_using_forks(data, d->fork_right, &d->using_fork_right);
	ft_get_using_forks(data, d->fork_left, &d->using_fork_left);
	while (d->using_fork_right == 1 || d->using_fork_left == 1)
	{
		usleep(100);
		ft_get_using_forks(data, d->fork_right, &d->using_fork_right);
		ft_get_using_forks(data, d->fork_left, &d->using_fork_left);
	}
	ft_get_all_alive(data, &d->a_alive);
	if (d->a_alive == 1)
	{
		ft_lock_forks(data, d->fork_right, d->fork_left);
		ft_print_eating(data, d->active);
		ft_set_last_eating(data, d->active);
		ft_unlock_forks(data, d->fork_right, d->fork_left);
		d->n_times++;
	}
}

void	ft_thinking(t_all *data, t_data_philosopher *d)
{
	ft_get_all_alive(data, &d->a_alive);
	if (d->a_alive == 1)
	{
		ft_get_stop_time(data, d->active, &d->s_time);
		if (d->s_time > 0)
		{
			ft_get_all_alive(data, &d->a_alive);
			if (d->a_alive == 1)
				ft_print_message(data, d->active, " is thinking");
			if (d->s_time > 100)
			{
				d->s_time += d->time;
				while (ft_get_time() < d->s_time && d->a_alive == 1)
					usleep(1000);
			}
		}
	}
}

void	ft_sleeping_thinking(t_all *data, t_data_philosopher *d)
{
	ft_get_all_alive(data, &d->a_alive);
	if (d->a_alive == 1)
	{
		ft_print_message(data, d->active, " is sleeping");
		d->time = ft_get_time();
		d->s_time = d->time + data->phi[d->active].time_to_sleep;
		ft_get_all_alive(data, &d->a_alive);
		while (ft_get_time() < d->s_time && d->a_alive == 1)
		{
			usleep(1000);
			ft_get_all_alive(data, &d->a_alive);			
		}
	}
	ft_thinking(data, d);
}
