/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_eating.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:51:14 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 17:08:11 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_print_eating(t_all *data, int active)
{
	long int	stop_time;

	if (pthread_mutex_lock(&data->m_message) != 0)
		return ;
	ft_p_message(data, ft_get_time(), active, " has taken a fork");
	ft_p_message(data, ft_get_time(), active, " has taken a fork");
	ft_p_message(data, ft_get_time(), active, " is eating");
	if (pthread_mutex_unlock(&data->m_message) != 0)
		return ;
	stop_time = ft_get_time() + data->phi[active].time_to_eat;
	while (ft_get_time() < stop_time && data->all_alive == 1)
		usleep(1000);
}
