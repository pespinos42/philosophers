#include "philosophers.h"

pthread_t	*ft_create_threads(int n_philosophers)
{
	pthread_t	*threads;

	threads = malloc (n_philosophers * sizeof (*threads));
	if (!threads)
		return (NULL);
	return (threads);
}

void	ft_initialize_threads(t_all *data)
{
	int	n;

	n = 0;
	while (n < data->total_philosophers)
	{
		if (pthread_mutex_lock(&data->m_active) != 0)
			return ;
		data->active = n;
		if (pthread_mutex_unlock(&data->m_active) != 0)
			return ;
		if (pthread_create(&data->threads[n], NULL, ft_philosopher, data) != 0)
			return ;
		usleep(1000);
		n++;
	}
	n = 0;
	if (pthread_join(data->t_alive, NULL) != 0)
		return ;
	while (n < data->total_philosophers)
	{
		if (pthread_join(data->threads[n], NULL) != 0)
			return ;
		n++;
	}
}