#include "philosophers.h"

void	ft_set_active(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->mutex_active) != 0)
		return ;
	data->active = value;
	if (pthread_mutex_unlock(&data->mutex_active) != 0)
		return ;
}

int	ft_get_n_p(t_all *data)
{
	int	n_p;

	n_p = -1;
	if (pthread_mutex_lock(&data->m_n_p) != 0)
		return (-1);
	n_p = data->n_p;
	if (pthread_mutex_unlock(&data->m_n_p) != 0)
		return (-1);
	return (n_p);
}

void	ft_set_n_p(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->m_n_p) != 0)
		return ;
	data->n_p = value;
	if (pthread_mutex_unlock(&data->m_n_p) != 0)
		return ;
}

long int	ft_get_t_to_die(t_all *data)
{
	long int	time_to_die;

	time_to_die = -1;
	if (pthread_mutex_lock(&data->m_t_t_d) != 0)
		return (-1);
	time_to_die = data->t_t_d;
	if (pthread_mutex_unlock(&data->m_t_t_d) != 0)
		return (-1);
	return (time_to_die);
}

void	ft_set_time_to_die(t_all *data, long int value)
{
	if (pthread_mutex_lock(&data->m_t_t_d) != 0)
		return ;
	data->t_t_d = value;
	if (pthread_mutex_unlock(&data->m_t_t_d) != 0)
		return ;
}
