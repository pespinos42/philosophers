#include "philosophers.h"

int main(int argc, char **argv)
{
    long int    *args;
    t_all       data;

    if (argc == 5 || argc == 6)
    {
        if (ft_check_args(argc, argv) == 1)
        {
            args = ft_get_args(argc, argv);
            printf("DATOS DENTRO DE LOS PARAMETROS NORMALES\n");
            ft_initialize_data_all(&data, args, argc - 1);
        }
        else
            printf("SE HA PRODUCIDO UN ERROR CON LOS DATOS\n");
    }
}
