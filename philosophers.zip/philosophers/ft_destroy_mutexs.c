#include "philosophers.h"

void	ft_destroy_local_mutex(t_all *data)
{
	int	n;

	n = 0;
	while (n < data->total_philosophers)
	{
		if (pthread_mutex_destroy(&data->phi[n].m_l_eat) != 0)
			return ;
		if (pthread_mutex_destroy(&data->phi[n].m_s_th) != 0)
			return ;
		n++;
	}
}

void	ft_destroy_mutexs(t_all *data)
{
	if (pthread_mutex_destroy(&data->m_a_alive) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_active) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_message) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_read_forks) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_total_exit) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_erase_all) != 0)
		return ;
}