/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philosophers.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/13 20:35:43 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:47:52 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILOSOPHERS_H
# define PHILOSOPHERS_H
# include <unistd.h>
# include <limits.h>
# include <stdlib.h>
# include <stdio.h>
# include <pthread.h>
# include <sys/time.h>

typedef struct s_fork
{
	int				using_fork;
	pthread_mutex_t	mutex_using_fork;
}	t_fork;

typedef struct s_philosopher
{
	int				index_philosopher;
    pthread_mutex_t mutex_index_philosopher;
	long int		time_to_die;
    pthread_mutex_t mutex_time_to_die;
	long int		time_to_eat;
    pthread_mutex_t mutex_time_to_eat;
	long int		time_to_sleep;
    pthread_mutex_t mutex_time_to_sleep;
	int				number_of_times;
    pthread_mutex_t mutex_number_of_times;
	long int		last_eating;
	pthread_mutex_t	mutex_last_eating;
	int				number_exit;
    pthread_mutex_t mutex_number_exit;
	long int		start_thread;
	pthread_mutex_t	mutex_start_thread;
}	t_philosopher;

typedef struct s_all
{
	int				total_philosophers;
	pthread_mutex_t	mutex_total_philosophers;
	t_philosopher	*phi;
	pthread_t		*threads;
	pthread_t		t_alive;
	t_fork			*forks;
	int				active;
	pthread_mutex_t	mutex_active;
	int				all_alive;
	pthread_mutex_t	mutex_all_alive;
	pthread_mutex_t	mutex_message;
	pthread_mutex_t	mutex_read_forks;
	// pthread_mutex_t	m_erase_all; COMPROBAR SI HACE FALTA REALMENTE
	int				total_exit;
	pthread_mutex_t	mutex_total_exit;
}	t_all;

typedef struct s_atoi
{
	long int	result;
	int			s;
	int			sign;
}	t_atoi;

typedef struct s_data_all_alive
{
	int			local_n;
	long int	local_time;
	long int	local_time_start;
	long int	local_start_thread;
	long int	local_l_eating;
	long int	local_time_to_die;
	int			local_total_exit;
	int			global_all_alive;
	int			global_total_philosophers;
}	t_data_all_alive;

typedef struct s_data_philosopher
{
	int			active;
	int			fork_right;
	int			fork_left;
	long int	time;
	long int	s_time;
	int			n_times;
	int			using_fork_left;
	int			using_fork_right;
	int			a_alive;
	int			total_n_times;
}	t_data_philosopher;

//t_philosopher.c
int 			ft_get_index_philosopher(t_philosopher *philo);
void    		ft_set_index_philosopher(t_philosopher *philo, int value);
long int    	ft_get_time_to_die(t_philosopher *philo);
void    		ft_set_time_to_die(t_philosopher *philo, long int value);
long int    	ft_get_time_to_eat(t_philosopher *philo);
void    		ft_set_time_to_eat(t_philosopher *philo, long int value);
long int    	ft_get_time_to_sleep(t_philosopher *philo);
void    		ft_set_time_to_sleep(t_philosopher *philo, long int value);
int 			ft_get_number_of_times(t_philosopher *philo);
void    		ft_set_number_of_times(t_philosopher *philo, int value);
long int    	ft_get_last_eating(t_philosopher *philo);
void    		ft_set_last_eating(t_philosopher *philo, long int value);
int 			ft_get_number_exit(t_philosopher *philo);
void			ft_set_number_exit(t_philosopher *philo, int value);
long int    	ft_get_start_thread(t_philosopher *philo);
void    		ft_set_start_thread(t_philosopher *philo, long int value);
void    		ft_init_mutexs_philosophers(t_all *data);
void    		ft_initialize_data_philosophers(t_all *data, long int *args, int n_args);
t_philosopher   *ft_create_philosophers(int n_philosophers);

//t_all.c
int 		ft_get_total_philosophers(t_all *data);
void    	ft_set_total_philosophers(t_all *data, int value);
int 		ft_get_active(t_all *data);
void    	ft_set_active(t_all *data, int value);
int 		ft_get_all_alive(t_all *data);
void    	ft_set_all_alive(t_all *data, int value);
int 		ft_get_total_exit(t_all *data);
void    	ft_set_total_exit(t_all *data, int value);
void    	ft_init_mutexs_data(t_all *data);
pthread_t   *ft_create_threads(int n_philosophers);
void    	ft_initialize_data_all(t_all *data, long int *args, int n_args);

//args.c
int			ft_strlen(char *str);
int			ft_check_args(int argc, char **argv);
long int	*ft_get_args(int argc, char **argv);
int			ft_check_only_numbers(int argc, char **argv);
int			ft_check_limits(long int *args, int n_args);

//atoi.c
void		ft_initialize_data_atoi(t_atoi *d);
long int	ft_atoi(char *str);

//t_fork
void    ft_destroy_forks(t_fork *forks, int n_forks);
t_fork  *ft_create_forks(int n_forks);
void    ft_lock_fork(t_all *data, int fork);
void    ft_unlock_fork(t_all *data, int fork);

//thread_all_alive
long int	ft_get_time(void);
void    	ft_initialize_data_all_alive(t_all *data, t_data_all_alive *d);
void		ft_print_number(long int n);
void		ft_p_message(t_all *data, long int time, int phil, char *m);
void    	*ft_thread_all_alive(void *arg);


#endif
