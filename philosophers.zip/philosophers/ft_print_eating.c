#include "philosophers.h"

void	ft_print_eating(t_all *data, int active)
{
	int	stop_time;

	if (pthread_mutex_lock(&data->m_message) != 0)
		return ;
	ft_p_message(data, ft_get_time(), active, " has taken a fork");
	ft_p_message(data, ft_get_time(), active, " has taken a fork");
	ft_p_message(data, ft_get_time(), active, " is eating");
	if (pthread_mutex_unlock(&data->m_message) != 0)
		return ;
	stop_time = ft_get_time() + data->phi[active].time_to_eat;
	while (ft_get_time() < stop_time && data->all_alive == 1)
		usleep(1000);
}