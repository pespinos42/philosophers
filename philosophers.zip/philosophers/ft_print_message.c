#include "philosophers.h"

void	ft_print_message(t_all *data, int active, char *msg)
{
	if (pthread_mutex_lock(&data->m_message) != 0)
		return ;
	ft_p_message(data, ft_get_time(), active, msg);
	if (pthread_mutex_unlock(&data->m_message) != 0)
		return ;
}