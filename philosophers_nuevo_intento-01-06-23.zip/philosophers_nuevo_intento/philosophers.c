#include "philosophers.h"

//----------------------------DATA_FILOSOFOS.C----------------------------------
void	ft_init_mutex_data_philosopher(t_data_philosopher *data_philosopher)
{
	if (pthread_mutex_init(&data_philosopher->mutex_index_philosopher, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data_philosopher->mutex_last_eating, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data_philosopher->mutex_number_eated, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data_philosopher->mutex_fork_left, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data_philosopher->mutex_fork_right, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data_philosopher->mutex_stop_time, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data_philosopher->mutex_start_thread, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data_philosopher->mutex_exit_yet, NULL) != 0)
		return ;
}

void	ft_destroy_mutex_data_philosopher(t_data_philosopher *data_philosopher, int n_philosophers)
{
	int	n;

	n = 0;
	while (n < n_philosophers)
	{
		if (pthread_mutex_destroy(&data_philosopher[n].mutex_index_philosopher) != 0)
			return ;
		if (pthread_mutex_destroy(&data_philosopher[n].mutex_last_eating) != 0)
			return ;
		if (pthread_mutex_destroy(&data_philosopher[n].mutex_number_eated) != 0)
			return ;
		if (pthread_mutex_destroy(&data_philosopher[n].mutex_fork_left) != 0)
			return ;
		if (pthread_mutex_destroy(&data_philosopher[n].mutex_fork_right) != 0)
			return ;
		if (pthread_mutex_destroy(&data_philosopher[n].mutex_stop_time) != 0)
			return ;
		if (pthread_mutex_destroy(&data_philosopher[n].mutex_start_thread) != 0)
			return ;
		if (pthread_mutex_destroy(&data_philosopher[n].mutex_exit_yet) != 0)
			return ;
		n++;
	}
}

int	ft_get_index_philosopher(t_data_philosopher *data_philosopher)
{
	int	index_philosopher;

	index_philosopher = -1;
	if (pthread_mutex_lock(&data_philosopher->mutex_index_philosopher) != 0)
		return (-1);
	index_philosopher = data_philosopher->index_philosopher;
	if (pthread_mutex_unlock(&data_philosopher->mutex_index_philosopher) != 0)
		return (-1);
	return (index_philosopher);
}

void	ft_set_index_philosopher(t_data_philosopher *data_philosopher, int value)
{
	if (pthread_mutex_lock(&data_philosopher->mutex_index_philosopher) != 0)
		return ;
	data_philosopher->index_philosopher = value;
	if (pthread_mutex_unlock(&data_philosopher->mutex_index_philosopher) != 0)
		return ;
}

long int	ft_get_last_eating(t_data_philosopher *data_philosopher)
{
	long int	last_eating;

	last_eating = -1;
	if (pthread_mutex_lock(&data_philosopher->mutex_last_eating) != 0)
		return (-1);
	last_eating = data_philosopher->last_eating;
	if (pthread_mutex_unlock(&data_philosopher->mutex_last_eating) != 0)
		return (-1);
	return (last_eating);
}

void	ft_set_last_eating(t_data_philosopher *data_philosopher, long int value)
{
	if (pthread_mutex_lock(&data_philosopher->mutex_last_eating) != 0)
		return ;
	data_philosopher->last_eating = value;
	if (pthread_mutex_unlock(&data_philosopher->mutex_last_eating) != 0)
		return ;
}

int		ft_get_fork_left(t_data_philosopher *data_philosopher)
{
	int	fork_left;

	fork_left = -1;
	if (pthread_mutex_lock(&data_philosopher->mutex_fork_left) != 0)
		return (-1);
	fork_left = data_philosopher->fork_left;
	if (pthread_mutex_unlock(&data_philosopher->mutex_fork_left) != 0)
		return (-1);
	return (fork_left);
}

void	ft_set_fork_left(t_data_philosopher *data_philosopher, int value)
{
	if (pthread_mutex_lock(&data_philosopher->mutex_fork_left) != 0)
		return ;
	data_philosopher->fork_left = value;
	if (pthread_mutex_unlock(&data_philosopher->mutex_fork_left) != 0)
		return ;
}

int	ft_get_fork_right(t_data_philosopher *data_philosopher)
{
	int	fork_right;

	fork_right = -1;
	if (pthread_mutex_lock(&data_philosopher->mutex_fork_right) != 0)
		return (-1);
	fork_right = data_philosopher->fork_right;
	if (pthread_mutex_unlock(&data_philosopher->mutex_fork_right) != 0)
		return (-1);
	return (fork_right);
}

void	ft_set_fork_right(t_data_philosopher *data_philosopher, int value)
{
	if (pthread_mutex_lock(&data_philosopher->mutex_fork_right) != 0)
		return ;
	data_philosopher->fork_right = value;
	if (pthread_mutex_unlock(&data_philosopher->mutex_fork_right) != 0)
		return ;
}

int	ft_get_number_eated(t_data_philosopher *data_philosopher)
{
	int	number_eated;

	number_eated = -1;
	if (pthread_mutex_lock(&data_philosopher->mutex_number_eated) != 0)
		return (-1);
	number_eated = data_philosopher->number_eated;
	if (pthread_mutex_unlock(&data_philosopher->mutex_number_eated) != 0)
		return (-1);
	return (number_eated);
}

void	ft_set_number_eated(t_data_philosopher *data_philosopher, int value)
{
	if (pthread_mutex_lock(&data_philosopher->mutex_number_eated) != 0)
		return ;
	data_philosopher->number_eated = value;
	if (pthread_mutex_unlock(&data_philosopher->mutex_number_eated) != 0)
		return ;
}

long int	ft_get_stop_time(t_data_philosopher *data_philosopher)
{
	long int	stop_time;

	stop_time = -1;
	if (pthread_mutex_lock(&data_philosopher->mutex_stop_time) != 0)
		return (-1);
	stop_time = data_philosopher->stop_time;
	if (pthread_mutex_unlock(&data_philosopher->mutex_stop_time) != 0)
		return (-1);
	return (stop_time);
}

void	ft_set_stop_time(t_data_philosopher *data_philosopher, long int value)
{
	if (pthread_mutex_lock(&data_philosopher->mutex_stop_time) != 0)
		return ;
	data_philosopher->stop_time = value;
	if (pthread_mutex_unlock(&data_philosopher->mutex_stop_time) != 0)
		return ;
}

long int ft_get_start_thread(t_data_philosopher *data_philosopher)
{
	long int	start_thread;

	start_thread = -1;
	if (pthread_mutex_lock(&data_philosopher->mutex_start_thread) != 0)
		return (-1);
	start_thread = data_philosopher->start_thread;
	if (pthread_mutex_unlock(&data_philosopher->mutex_start_thread) != 0)
		return (-1);
	return (start_thread);
}

void	ft_set_start_thread(t_data_philosopher *data_philosopher, long int value)
{
	if (pthread_mutex_lock(&data_philosopher->mutex_start_thread) != 0)
		return ;
	data_philosopher->start_thread = value;
	if (pthread_mutex_unlock(&data_philosopher->mutex_start_thread) != 0)
		return ;
}

int	ft_get_exit_yet(t_data_philosopher *data_philosopher)
{
	int	exit_yet;

	exit_yet = -1;
	if (pthread_mutex_lock(&data_philosopher->mutex_exit_yet) != 0)
		return (-1);
	exit_yet = data_philosopher->exit_yet;
	if (pthread_mutex_unlock(&data_philosopher->mutex_exit_yet) != 0)
		return (-1);
	return (exit_yet);
}

void	ft_set_exit_yet(t_data_philosopher *data_philosopher, int value)
{
	if (pthread_mutex_lock(&data_philosopher->mutex_exit_yet) != 0)
		return ;
	data_philosopher->exit_yet = value;
	if (pthread_mutex_unlock(&data_philosopher->mutex_exit_yet) != 0)
		return ;
}

t_data_philosopher	*ft_create_data_philosophers(t_all *data)
{
	t_data_philosopher	*data_philosophers;
	int					n;

	n = 0;
	data_philosophers = malloc (ft_get_number_philosophers(data) * sizeof (*data_philosophers));
	if (!data_philosophers)
		return (NULL);
	while (n < ft_get_number_philosophers(data))
	{
		//ft_set_index_philosopher(&data_philosophers[n], ft_get_active(data));
		ft_set_last_eating(&data_philosophers[n], -1);
		ft_set_number_eated(&data_philosophers[n], 0);
		ft_set_fork_left(&data_philosophers[n], -1);
		ft_set_fork_right(&data_philosophers[n], -1);
		ft_set_stop_time(&data_philosophers[n], -1);
		//ft_set_start_thread(&data_philosophers[n], ft_get_time());
		ft_set_exit_yet(&data_philosophers[n], 0);
		n++;
	}
	return (data_philosophers);
}

//------------------------FIN DATA_FILOSOFOS.C----------------------------------

//-------------------------FORKS.C-----------------------
t_fork	*ft_create_forks(int n_forks)
{
	t_fork	*forks;
	// int		n;

	// n = 0;
	forks = malloc (n_forks * sizeof (*forks));
	if (!forks)
		return (NULL);
	// while (n < n_forks)
	// {
	// 	forks[n].using_fork = 0;
	// 	n++;
	// }
	return (forks);
}

void	ft_lock_fork(t_fork *forks, int n_fork)
{
	if (pthread_mutex_lock(&forks[n_fork].mutex_using_fork) != 0)
		return ;
}

void	ft_unlock_fork(t_fork *forks, int n_fork)
{
	if (pthread_mutex_unlock(&forks[n_fork].mutex_using_fork) != 0)
		return ;
}

void	ft_init_mutex_forks(t_fork *forks, int n_forks)
{
	int	n;

	n = 0;
	while (n < n_forks)
	{
		if (pthread_mutex_init(&forks[n].mutex_using_fork, NULL) != 0)
			return ;
		n++;
	}
}

void	ft_destroy_mutex_forks(t_fork *forks, int n_forks)
{
	int	n;

	n = 0;
	while (n < n_forks)
	{
		if (pthread_mutex_destroy(&forks[n].mutex_using_fork) != 0)
			return ;
		n++;
	}
}

// int	ft_get_using_fork(t_all *data, int fork)
// {
// 	int	using_fork;

// 	using_fork = -1;
// 	if (pthread_mutex_lock(&data->forks[fork].mutex_using_fork) != 0)
// 		return (-1);
// 	using_fork = data->forks[fork].using_fork;
// 	if (pthread_mutex_unlock(&data->forks[fork].mutex_using_fork) != 0)
// 		return (-1);
// 	return (using_fork);
// }

// void	ft_set_using_fork(t_all *data, int fork, int value)
// {
// 	if (pthread_mutex_lock(&data->forks[fork].mutex_using_fork) != 0)
// 		return ;
// 	data->forks[fork].using_fork = value;
// 	if (pthread_mutex_unlock(&data->forks[fork].mutex_using_fork) != 0)
// 		return ;
// }

//---------------------FIN FORKS.C------------------------

//-------------------------------FILOSOFOS.C------------------------------------------


// t_philosopher *ft_create_philosophers(t_all *data)
// {
// 	t_philosopher	*philosophers;

// 	philosophers = malloc (ft_get_number_philosophers(data) * sizeof (*philosophers));
// 	if (!philosophers)
// 		return (NULL);
// 	return (philosophers);
// }

// void	ft_init_mutex_philosophers(t_all *data)
// {
// 	int	n;

// 	n = 0;
// 	while (n < ft_get_number_philosophers(data))
// 	{
// 		if (pthread_mutex_init(&data->philosophers[n].mutex_fork_left, NULL) != 0)
// 			return ;
// 		if (pthread_mutex_init(&data->philosophers[n].mutex_fork_right, NULL) != 0)
// 			return ;
// 		n++;	
// 	}
// }

// void	ft_destroy_mutex_philosophers(t_all *data)
// {
// 	int	n;

// 	n = 0;
// 	while (n < ft_get_number_philosophers(data))
// 	{
// 		if (pthread_mutex_destroy(&data->philosophers[n].mutex_fork_left) != 0)
// 			return ;
// 		if (pthread_mutex_destroy(&data->philosophers[n].mutex_fork_right) != 0)
// 			return ;
// 		n++;
// 	}
// }


//---------------------------FIN FILOSOFOS.C----------------------------------
//----------------------------------ALL.C----------------------------------------
int	ft_get_active(t_all *data)
{
	int	active;

	active = -1;
	if (pthread_mutex_lock(&data->mutex_active) != 0)
		return (-1);
	active = data->active;
	if (pthread_mutex_unlock(&data->mutex_active) != 0)
		return (-1);
	return (active);
}

void	ft_set_active(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->mutex_active) != 0)
		return ;
	data->active = value;
	if (pthread_mutex_unlock(&data->mutex_active) != 0)
		return ;
}

int		ft_get_number_philosophers(t_all *data)
{
	int	number_philosophers;

	number_philosophers = -1;
	if (pthread_mutex_lock(&data->mutex_number_philosophers) != 0)
		return (-1);
	number_philosophers = data->number_philosophers;
	if (pthread_mutex_unlock(&data->mutex_number_philosophers) != 0)
		return (-1);
	return (number_philosophers);
}

void	ft_set_number_philosophers(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->mutex_number_philosophers) != 0)
		return ;
	data->number_philosophers = value;
	if (pthread_mutex_unlock(&data->mutex_number_philosophers) != 0)
		return ;
}

long int	ft_get_time_to_die(t_all *data)
{
	long int	time_to_die;

	time_to_die = -1;
	if (pthread_mutex_lock(&data->mutex_time_to_die) != 0)
		return (-1);
	time_to_die = data->time_to_die;
	if (pthread_mutex_unlock(&data->mutex_time_to_die) != 0)
		return (-1);
	return (time_to_die);
}

void	ft_set_time_to_die(t_all *data, long int value)
{
	if (pthread_mutex_lock(&data->mutex_time_to_die) != 0)
		return ;
	data->time_to_die = value;
	if (pthread_mutex_unlock(&data->mutex_time_to_die) != 0)
		return ;
}

long int	ft_get_time_to_eat(t_all *data)
{
	long int	time_to_eat;

	time_to_eat = -1;
	if (pthread_mutex_lock(&data->mutex_time_to_eat) != 0)
		return (-1);
	time_to_eat = data->time_to_eat;
	if (pthread_mutex_unlock(&data->mutex_time_to_eat) != 0)
		return (-1);
	return (time_to_eat);
}

void	ft_set_time_to_eat(t_all *data, long int value)
{
	if (pthread_mutex_lock(&data->mutex_time_to_eat) != 0)
		return ;
	data->time_to_eat = value;
	if (pthread_mutex_unlock(&data->mutex_time_to_eat) != 0)
		return ;
}

long int	ft_get_time_to_sleep(t_all *data)
{
	long int	time_to_sleep;

	time_to_sleep = -1;
	if (pthread_mutex_lock(&data->mutex_time_to_sleep) != 0)
		return (-1);
	time_to_sleep = data->time_to_sleep;
	if (pthread_mutex_unlock(&data->mutex_time_to_sleep) != 0)
		return (-1);
	return (time_to_sleep);
}

void	ft_set_time_to_sleep(t_all *data, long int value)
{
	if (pthread_mutex_lock(&data->mutex_time_to_sleep) != 0)
		return ;
	data->time_to_sleep = value;
	if (pthread_mutex_unlock(&data->mutex_time_to_sleep) != 0)
		return ;
}

int	ft_get_number_of_times_eat(t_all *data)
{
	int	number_of_times;

	number_of_times = -1;
	if (pthread_mutex_lock(&data->mutex_number_of_times_eat) != 0)
		return (-1);
	number_of_times = data->number_of_times_eat;
	if (pthread_mutex_unlock(&data->mutex_number_of_times_eat) != 0)
		return (-1);
	return (number_of_times);
}

void	ft_set_number_of_times_eat(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->mutex_number_of_times_eat) != 0)
		return ;
	data->number_of_times_eat = value;
	if (pthread_mutex_unlock(&data->mutex_number_of_times_eat) != 0)
		return ;
}

// void	ft_set_philosophers_eating(t_all *data, int position, int value)
// {
// 	if (pthread_mutex_lock(&data->mutex_philosophers_eating) != 0)
// 		return ;
// 	data->philosophers_eating[position] = value;
// 	if (pthread_mutex_unlock(&data->mutex_philosophers_eating) != 0)
// 		return ;
// }

// int	ft_get_philosophers_eating(t_all *data, int position)
// {
// 	int	philosophers_eating;

// 	philosophers_eating = -1;
// 	if (pthread_mutex_lock(&data->mutex_philosophers_eating) != 0)
// 		return (-1);
// 	philosophers_eating = data->philosophers_eating[position];
// 	if (pthread_mutex_unlock(&data->mutex_philosophers_eating) != 0)
// 		return (-1);
// 	return (philosophers_eating);
// }

void	ft_set_all_out(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->mutex_all_out) != 0)
		return ;
	data->all_out = value;
	if (pthread_mutex_unlock(&data->mutex_all_out) != 0)
		return ;
}

int	ft_get_all_out(t_all *data)
{
	int	all_out;

	all_out = -1;
	if (pthread_mutex_lock(&data->mutex_all_out) != 0)
		return (-1);
	all_out = data->all_out;
	if (pthread_mutex_unlock(&data->mutex_all_out) != 0)
		return (-1);
	return (all_out);
}

int	ft_get_all_alive(t_all *data)
{
	int	all_alive;

	all_alive = -1;
	if (pthread_mutex_lock(&data->mutex_all_alive) != 0)
		return (-1);
	all_alive = data->all_alive;
	if (pthread_mutex_unlock(&data->mutex_all_alive) != 0)
		return (-1);
	return (all_alive);
}

void	ft_set_all_alive(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->mutex_all_alive) != 0)
		return ;
	data->all_alive = value;
	if (pthread_mutex_unlock(&data->mutex_all_alive) != 0)
		return ;
}

int	ft_get_total_exit(t_all *data)
{
	int	total_exit;

	total_exit = -1;
	if (pthread_mutex_lock(&data->mutex_total_exit) != 0)
		return (-1);
	total_exit = data->total_exit;
	if (pthread_mutex_unlock(&data->mutex_total_exit) != 0)
		return (-1);
	return (total_exit);
}

void	ft_set_total_exit(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->mutex_total_exit) != 0)
		return ;
	data->total_exit = value;
	if (pthread_mutex_unlock(&data->mutex_total_exit) != 0)
		return ;
}

void	ft_init_mutex_data(t_all *data)
{
	if (pthread_mutex_init(&data->mutex_number_philosophers, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->mutex_all_alive, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->mutex_time_to_die, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->mutex_time_to_eat, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->mutex_time_to_sleep, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->mutex_number_of_times_eat, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->mutex_active, NULL) != 0)
		return ;
	// if (pthread_mutex_init(&data->mutex_philosophers_eating, NULL) != 0)
	// 	return ;
	if (pthread_mutex_init(&data->mutex_message, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->mutex_all_out, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->mutex_total_exit, NULL) != 0)
		return ;
}

void	ft_destroy_mutex_data(t_all *data)
{
	if (pthread_mutex_destroy(&data->mutex_number_philosophers) != 0)
		return ;
	if (pthread_mutex_destroy(&data->mutex_all_alive) != 0)
		return ;
	if (pthread_mutex_destroy(&data->mutex_time_to_die) != 0)
		return ;
	if (pthread_mutex_destroy(&data->mutex_time_to_eat) != 0)
		return ;
	if (pthread_mutex_destroy(&data->mutex_time_to_sleep) != 0)
		return ;
	if (pthread_mutex_destroy(&data->mutex_number_of_times_eat) != 0)
		return ;
	if (pthread_mutex_destroy(&data->mutex_active) != 0)
		return ;
	// if (pthread_mutex_destroy(&data->mutex_philosophers_eating) != 0)
	// 	return ;
	if (pthread_mutex_destroy(&data->mutex_message) != 0)
		return ;
	if (pthread_mutex_destroy(&data->mutex_all_out) != 0)
		return ;
	if (pthread_mutex_destroy(&data->mutex_total_exit) != 0)
		return ;
}
//------------------------------------------FIN ALL.C-----------------------------------
//-----------------------------------ATOI.C--------------------------------------------
void	ft_initialize_data_atoi(t_atoi *d)
{
	d->result = 0;
	d->s = 0;
	d->sign = 1;
}

long int	ft_atoi(char *str)
{
	t_atoi	d;

	ft_initialize_data_atoi(&d);
	while ((*str >= 9 && *str <= 13) || *str == 32)
		str++;
	if (*str == '+')
	{
		d.s++;
		str++;
	}
	if (*str == '-' && d.s == 0)
	{
		d.sign = -1;
		str++;
	}
	if (*str == '-' && d.s == 1)
		d.sign = 0;
	while (*str >= '0' && *str <= '9')
	{
		d.result = d.result * 10 + (*str - 48);
		str++;
	}
	return (d.sign * d.result);
}
//---------------------------------------FIN ATOI.C----------------------------
//----------------------------------ARGS.C----------------------------------------
int	ft_strlen(char *str)
{
	int len;

	len = 0;
	while (str[len])
		len++;
	return (len);
}

long int	*ft_get_args(int argc, char **argv)
{
	long int	*args;
	int			n;

	n = 1;
	args = malloc ((argc - 1) * sizeof (*args));
	if (!args)
		return (NULL);
	while (n < argc)
	{
		args[n - 1] = ft_atoi(argv[n]);
		n++;
	}
	return (args);
}

int	ft_check_only_numbers(int argc, char **argv)
{
	int	arg;
	int	letter;
	int	check;

	arg = 1;
	letter = 0;
	check = 1;
	while (arg < argc && check == 1)
	{
		while (letter < ft_strlen(argv[arg]) && check == 1)
		{
			if (argv[arg][letter] < 48 || argv[arg][letter] > 57)
				check = 0;
			letter++;
		}
		letter = 0;
		arg++;
	}
	return (check);
}

int	ft_check_limits(long int *args, int n_args)
{
	int	n;
	int	check;

	n = 0;
	check = 1;
	while (n < n_args && check == 1)
	{
		if (args[n] > 2147483647)
			check = 0;
		n++;
	}
	return (check);
}

int	ft_check_args(int argc, char **argv)
{
	long int	*args;

	if (ft_check_only_numbers(argc, argv) != 1)
		return (-1);
	args = ft_get_args(argc, argv);
	if (ft_check_limits(args, argc - 1) != 1)
		return (free (args), -1);
	if (args[0] <= 0)
		return (free (args), -1);
	if (argc == 6 && args[4] <= 0)
		return (free (args), -1);
	free (args);
	return (1);
}
//-------------------------------------FIN ARGS.C------------------------------

//------------------------------------PARA BORRAR

void	ft_print_args(long int *args, int argc)
{
	printf("ARGS[0] = %li\n", args[0]);
	printf("ARGS[1] = %li\n", args[1]);
	printf("ARGS[2] = %li\n", args[2]);
	printf("ARGS[3] = %li\n", args[3]);
	if (argc == 6)
		printf("ARGS[4] = %li\n", args[4]);
}

void	ft_print_data(t_all *data)
{
	printf("NUMBER OF PHILOSOPHERS -> %i\n", ft_get_number_philosophers(data));
	printf("TIME TO DIE -> %li\n", ft_get_time_to_die(data));
	printf("TIME TO EAT -> %li\n", ft_get_time_to_eat(data));
	printf("TIME TO SLEEP -> %li\n", ft_get_time_to_sleep(data));
	printf("NUMBER OF TIMES TO EAT -> %i\n", ft_get_number_of_times_eat(data));
}

// void	ft_print_philosophers_eating(int *philosophers_eating, int n_philosophers)
// {
// 	int n;

// 	n = 0;
// 	printf("\n\nIMPRIMIENDO PHILOSOPHERS ALIVE\n");
// 	while (n < n_philosophers)
// 	{
// 		printf("P%i -> %i\n", n + 1, philosophers_eating[n]);
// 		n++;
// 	}
// 	printf("\n");
// }

//------------------------------------
void	ft_print_message(t_all *data, long int time, int philosopher, char *message)
{
	if (pthread_mutex_lock(&data->mutex_message) != 0)
		return ;
	ft_print_number(time);
	write(1, " ", 1);
	ft_print_number(philosopher);
	write(1, message, ft_strlen(message));
	write(1, "\n", 1);
	if (pthread_mutex_unlock(&data->mutex_message) != 0)
		return ;
}

void	ft_initialize_data_philosopher(t_data_philosopher *data_philosopher, t_all *data)
{
	ft_set_index_philosopher(data_philosopher, ft_get_active(data));
	//printf("ACTIVO -> %i\n", ft_get_index_philosopher(data_philosopher));
	ft_set_last_eating(data_philosopher, -1);
	ft_set_number_eated(data_philosopher, 0);
	ft_set_fork_left(data_philosopher, -1);
	ft_set_fork_right(data_philosopher, -1);
	ft_set_stop_time(data_philosopher, -1);
	ft_set_start_thread(data_philosopher, ft_get_time());
	ft_set_exit_yet(data_philosopher, 0);
}

void	ft_wait(t_all *data, long int time_to_wait)
{
	long int	stop_time;
	
	stop_time = ft_get_time() + time_to_wait;
	while (stop_time > ft_get_time() && ft_get_all_alive(data) == 1)
		usleep(1000);
}

void	*ft_philosopher(void *arg)
{
	t_all 				*data;
	t_data_philosopher	data_philosopher;
	long int			time_to_die;
	long int			time_to_eat;
	long int			last_eating;
	long int			stop_time;
	int					n_times;
	int					all_alive;
	int					number_eated;
	int					active;

	time_to_die = -1;
	time_to_eat = -1;
	last_eating = -1;
	stop_time = -1;
	number_eated = 0;
	data = (t_all *) arg;
	//ft_set_index_philosopher(&data_philosopher, ft_get_active(data));
	//printf("FILOSOFO %i ACTIVO\n", ft_get_index_philosopher(&data_philosopher));
	active = ft_get_active(data);
	ft_set_index_philosopher(&data->data_philosophers[active], active);
	//printf("GET_TIME -> %li\n", ft_get_time());
	ft_set_start_thread(&data->data_philosophers[active], ft_get_time());
	//ft_initialize_data_philosopher(&data->data_philosophers[active], data);
	//printf("NUMBER EATED INICIALIZADO A -> %i\n", ft_get_number_eated(&data->data_philosophers[active]));

	//printf("FILOSOFO %i TENEDOR DERECHO -> %i TENEDOR IZQUIERDO -> %i\n", ft_get_index_philosopher(&data->data_philosophers[active]), ft_get_fork_right(&data->data_philosophers[active]), ft_get_fork_left(&data->data_philosophers[active]));

	if (ft_get_number_philosophers(data) > 1 && ft_get_time_to_die(data) > 0)
	{
		//ASIGNACION DE TENEDORES**********************************************
		ft_set_fork_right(&data->data_philosophers[active], ft_get_index_philosopher(&data->data_philosophers[active]));
		if (ft_get_index_philosopher(&data->data_philosophers[active]) == ft_get_number_philosophers(data) - 1)
			ft_set_fork_left(&data->data_philosophers[active], 0);
		else
			ft_set_fork_left(&data->data_philosophers[active], ft_get_index_philosopher(&data->data_philosophers[active]) + 1);

		while (ft_get_all_alive(data) == 1 && ft_get_exit_yet(&data->data_philosophers[active]) == 0)
		{
			//COMER
			ft_lock_fork(data->forks, ft_get_fork_right(&data->data_philosophers[active]));
			ft_lock_fork(data->forks, ft_get_fork_left(&data->data_philosophers[active]));
			//printf("%li FILOSOFO %i TIENE LOS TENEDORES %i y %i DURANTE 1 SEGUNDO\n", ft_get_time(), ft_get_index_philosopher(&data->data_philosophers[active]), ft_get_fork_right(&data->data_philosophers[active]), ft_get_fork_left(&data->data_philosophers[active]));
			ft_print_message(data, ft_get_time(), ft_get_index_philosopher(&data->data_philosophers[active]) + 1, " is eating");
			//usleep(ft_get_time_to_eat(data) * 1000);
			ft_wait(data, ft_get_time_to_eat(data));
			ft_set_last_eating(&data->data_philosophers[active], ft_get_time()); // &&&&& ESTA LINEA DEBERIA IR DEBAJO DEL USLEEP DE LA SIGUIENTE LINEA
			//ft_print_message(data, ft_get_last_eating(&data->data_philosophers[active]), ft_get_index_philosopher(&data->data_philosophers[active]), " LAST EATING");
			//printf("LAST EATING FILOSOFO %i -> %li\n", ft_get_index_philosopher(&data->data_philosophers[active]), ft_get_last_eating(&data->data_philosophers[active]));
			ft_unlock_fork(data->forks, ft_get_fork_left(&data->data_philosophers[active]));
			ft_unlock_fork(data->forks, ft_get_fork_right(&data->data_philosophers[active]));
			number_eated++;
			ft_set_number_eated(&data->data_philosophers[active], ft_get_number_eated(&data->data_philosophers[active]) + 1);

			//printf("VALOR -> %i\n", ft_get_number_eated(&data->data_philosophers[active]));
			//printf("NUMERO DE VECES QUE HA COMIDO EL FILOSOFO %i -> %i\n", ft_get_index_philosopher(&data->data_philosophers[active]) + 1, );

			if (ft_get_number_of_times_eat(data) != -1 && ft_get_number_eated(&data->data_philosophers[active]) >= ft_get_number_of_times_eat(data))
			{
				ft_set_exit_yet(&data->data_philosophers[active], 1);
				//ft_set_philosophers_eating(data, ft_get_index_philosopher(&data->data_philosophers[active]), 0);
				//ft_print_philosophers_eating(data->philosophers_eating, ft_get_number_philosophers(data));
			}
			if (ft_get_exit_yet(&data->data_philosophers[active]) == 0 && ft_get_all_alive(data) == 1)
			{
				//DORMIR
				ft_print_message(data, ft_get_time(), ft_get_index_philosopher(&data->data_philosophers[active]) + 1, " is sleeping");
				ft_wait(data, ft_get_time_to_sleep(data));
				
				//usleep(ft_get_time_to_sleep(data) * 1000);
				//ft_print_message(data, ft_get_time(), ft_get_index_philosopher(&data->data_philosophers[active]) + 1, " is awake");

				//PENSAR
				time_to_die = ft_get_time_to_die(data);
				last_eating = ft_get_last_eating(&data->data_philosophers[active]);
				time_to_eat = ft_get_time_to_eat(data);
				stop_time = (time_to_die - ((ft_get_time() - last_eating) + time_to_eat)) / 2;
				ft_set_stop_time(&data->data_philosophers[active], stop_time);
				if (ft_get_all_alive(data) == 1)
				{
					ft_print_message(data, ft_get_time(), ft_get_index_philosopher(&data->data_philosophers[active]) + 1, " is thinking");
					if (stop_time > 100 && ft_get_all_alive(data) == 1)
						//usleep(ft_get_stop_time(&data->data_philosophers[active]));
						ft_wait(data, ft_get_stop_time(&data->data_philosophers[active]));
				}
			}

		}
	}
	ft_set_total_exit(data, ft_get_total_exit(data) + 1);
	//printf("TOTAL EXIT --------> %i\n", ft_get_total_exit(data));
	return (NULL);
}

void	ft_initialize_data_all_alive(t_data_all_alive *data_all_alive)
{
	data_all_alive->n = 0;
	data_all_alive->time = 0;
	data_all_alive->time_start = -1;
	data_all_alive->start_thread = -1;
	data_all_alive->last_eating = -1;
	data_all_alive->time_to_die = -1;
	data_all_alive->total_exit = -1;
	data_all_alive->start_thread = -1;
}

void	*ft_all_alive(void *arg)
{
	t_all				*data;
	t_data_all_alive	data_all_alive;

	data = (t_all *) arg;
	ft_initialize_data_all_alive(&data_all_alive);
	while(ft_get_start_thread(&data->data_philosophers[ft_get_number_philosophers(data) - 1]) <= 0)
		ft_wait(data, 100);
	while (ft_get_all_alive(data) == 1 && ft_get_total_exit(data) < ft_get_number_philosophers(data))
	{
		while (data_all_alive.n < ft_get_number_philosophers(data) && ft_get_all_alive(data) == 1)
		{
			data_all_alive.start_thread = ft_get_start_thread(&data->data_philosophers[data_all_alive.n]);
			//printf("FILOSOFO %i START_THREAD -> %li\n", data_all_alive.n + 1, data_all_alive.start_thread);
			if (data_all_alive.start_thread != -1)
			{
				data_all_alive.last_eating = ft_get_last_eating(&data->data_philosophers[data_all_alive.n]);
				if (data_all_alive.last_eating == -1)
				{
					data_all_alive.time_start = ft_get_start_thread(&data->data_philosophers[data_all_alive.n]);
					//printf("FILOSOFO %i LAST_EATING = -1\n", data_all_alive.n + 1);
				}
				else
				{
					data_all_alive.time_start = ft_get_last_eating(&data->data_philosophers[data_all_alive.n]);
					//printf("FILOSOFO %i LAST_EATING = %li\n", data_all_alive.n + 1,data_all_alive.time_start);
				}
				data_all_alive.time = ft_get_time();
				//printf("FILOSOFO %i TIME_START -> %li\n", data_all_alive.n + 1, data_all_alive.time_start);
				data_all_alive.time_to_die = ft_get_time_to_die(data);
				if ((data_all_alive.time - data_all_alive.time_start) >= data_all_alive.time_to_die)
				{
					if (ft_get_exit_yet(&data->data_philosophers[data_all_alive.n]) == 0)
					{
						ft_print_message(data, ft_get_time(), data_all_alive.n + 1, " is died");
						ft_set_all_alive(data, 0);
						//printf("DATOS DE LA MUERTE:\n");
						//printf("START_THREAD -> %li\n", ft_get_start_thread(&data->data_philosophers[data_all_alive.n]));
					}
				}
				data_all_alive.n = data_all_alive.n + 1;
			}
		}
		data_all_alive.n = 0;
		ft_wait(data, 100);
	}
	return (NULL);
}

pthread_t	*ft_create_threads(t_all *data)
{
	pthread_t	*threads;

	threads = malloc (ft_get_number_philosophers(data) * sizeof (*threads));
	if (!threads)
		return (NULL);
	return (threads);
}

void	ft_initialize_threads(t_all *data)
{
	int	n;

	n = 0;
	if (pthread_create(&data->thread_all_alive, NULL, ft_all_alive, data) != 0)
		return ;
	usleep(1000);
	while (n < ft_get_number_philosophers(data))
	{
		ft_set_active(data, n);
		if (pthread_create(&data->threads[n], NULL, ft_philosopher, data) != 0)
			return ;
		usleep(100);
		n++;
	}
}

void	ft_start_threads(t_all *data)
{
	int	n;

	n = 0;
	if (pthread_join(data->thread_all_alive, NULL) != 0)
		return ;
	while (n < ft_get_number_philosophers(data))
	{
		if (pthread_join(data->threads[n], NULL) != 0)
			return ;
		n++;
	}
}

// int	*ft_create_philosophers_eating(int n_philosophers)
// {
// 	int	*philosophers_eating;
// 	int	n;

// 	n = 0;
// 	philosophers_eating = malloc (n_philosophers * sizeof (*philosophers_eating));
// 	if (!philosophers_eating)
// 		return (NULL);
// 	while (n < n_philosophers)
// 	{
// 		philosophers_eating[n] = 1;
// 		n++;
// 	}
// 	return (philosophers_eating);
// }

void	ft_fill_data(t_all *data, long int *args, int argc)
{
	ft_init_mutex_data(data);
	ft_set_number_philosophers(data, args[0]);
	ft_set_all_alive(data, 1);
	ft_set_time_to_die(data, args[1]);
	ft_set_time_to_eat(data, args[2]);
	ft_set_time_to_sleep(data, args[3]);
	if (argc == 6)
		ft_set_number_of_times_eat(data, args[4]);
	else
		ft_set_number_of_times_eat(data, -1);
	data->forks = ft_create_forks(args[0]);
	ft_init_mutex_forks(data->forks, args[0]);
	//data->philosophers_eating = ft_create_philosophers_eating(args[0]);
	data->data_philosophers = ft_create_data_philosophers(data);
	data->threads = ft_create_threads(data);
	ft_set_total_exit(data, 0);
}

void	ft_print_number(long int n)
{
	char	number;

	number = 0;
	if (n == INT_MIN)
		write(1, "-2147483648", 11);
	else if (n < 0)
	{
		write(1, "-", 1);
		ft_print_number(-n);
	}
	else
	{
		if (n > 9)
			ft_print_number(n / 10);
		number = (n % 10) + 48;
		write(1, &number, 1);
	}
}

long int	ft_get_time(void)
{
	struct timeval	tv;

	gettimeofday(&tv, NULL);
	return ((tv.tv_sec * 1000) + (tv.tv_usec / 1000));
}

int main(int argc, char **argv)
{
	long int    *args;
	t_all       data;

	if (argc == 5 || argc == 6)
	{
		if (ft_check_args(argc, argv) == 1)
		{
			args = ft_get_args(argc, argv);
			//ft_print_args(args, argc);
			ft_fill_data(&data, args, argc);
			ft_print_data(&data);
			ft_initialize_threads(&data);
			ft_start_threads(&data);
			//ft_print_philosophers_eating(data.philosophers_eating, data.number_philosophers);
			ft_destroy_mutex_forks(data.forks, ft_get_number_philosophers(&data));
			ft_destroy_mutex_data_philosopher(data.data_philosophers, ft_get_number_philosophers(&data));
			ft_destroy_mutex_data(&data);
		}
		else
			printf("PARAMETROS ERRONEOS\n");
	}
}