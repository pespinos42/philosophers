/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philosophers.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/13 20:35:45 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:49:25 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

int	main(int argc, char **argv)
{
	long int	*args;
	t_all		all_phi;

	if (argc == 5 || argc == 6)
	{
		if (ft_check_args(argc, argv) == 1)
		{
			args = ft_get_args(argc, argv);
			ft_fill_t_all(&all_phi, args, argc - 1);
			ft_destroy_forks(all_phi.total_philosophers, all_phi.forks);
			free(args);
			ft_destroy_local_mutex(&all_phi);
			ft_free_all(&all_phi);
			ft_destroy_mutexs(&all_phi);
		}
		else
			printf("ARGUMENTO INVALIDO\n");
	}
	return (0);
}
