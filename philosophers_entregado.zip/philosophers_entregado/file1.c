/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file1.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/30 18:11:35 by pespinos          #+#    #+#             */
/*   Updated: 2023/06/30 18:11:35 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

//----------------------------DATA_FILOSOFOS.C----------------------------------
void	ft_i_m_d_p(t_data_philosopher *d_p, int n_p)
{
	int	n;

	n = 0;
	while (n < n_p)
	{
		if (pthread_mutex_init(&d_p[n].m_i_p, NULL) != 0)
			return ;
		if (pthread_mutex_init(&d_p[n].m_l_e, NULL) != 0)
			return ;
		if (pthread_mutex_init(&d_p[n].m_n_e, NULL) != 0)
			return ;
		if (pthread_mutex_init(&d_p[n].m_f_l, NULL) != 0)
			return ;
		if (pthread_mutex_init(&d_p[n].m_f_r, NULL) != 0)
			return ;
		if (pthread_mutex_init(&d_p[n].m_s_t, NULL) != 0)
			return ;
		if (pthread_mutex_init(&d_p[n].m_s_th, NULL) != 0)
			return ;
		if (pthread_mutex_init(&d_p[n].m_e_y, NULL) != 0)
			return ;
		n++;
	}
}

void	ft_d_m_d_p(t_data_philosopher *d_p, int n_p)
{
	int	n;

	n = 0;
	while (n < n_p)
	{
		if (pthread_mutex_destroy(&d_p[n].m_i_p) != 0)
			return ;
		if (pthread_mutex_destroy(&d_p[n].m_l_e) != 0)
			return ;
		if (pthread_mutex_destroy(&d_p[n].m_n_e) != 0)
			return ;
		if (pthread_mutex_destroy(&d_p[n].m_f_l) != 0)
			return ;
		if (pthread_mutex_destroy(&d_p[n].m_f_r) != 0)
			return ;
		if (pthread_mutex_destroy(&d_p[n].m_s_t) != 0)
			return ;
		if (pthread_mutex_destroy(&d_p[n].m_s_th) != 0)
			return ;
		if (pthread_mutex_destroy(&d_p[n].m_e_y) != 0)
			return ;
		n++;
	}
}

int	ft_get_i_p(t_data_philosopher *d_p)
{
	int	i_p;

	i_p = -1;
	if (pthread_mutex_lock(&d_p->m_i_p) != 0)
		return (-1);
	i_p = d_p->i_p;
	if (pthread_mutex_unlock(&d_p->m_i_p) != 0)
		return (-1);
	return (i_p);
}

void	ft_set_i_p(t_data_philosopher *d_p, int value)
{
	if (pthread_mutex_lock(&d_p->m_i_p) != 0)
		return ;
	d_p->i_p = value;
	if (pthread_mutex_unlock(&d_p->m_i_p) != 0)
		return ;
}

long int	ft_get_l_e(t_data_philosopher *d_p)
{
	long int	l_e;

	l_e = -1;
	if (pthread_mutex_lock(&d_p->m_l_e) != 0)
		return (-1);
	l_e = d_p->l_e;
	if (pthread_mutex_unlock(&d_p->m_l_e) != 0)
		return (-1);
	return (l_e);
}
