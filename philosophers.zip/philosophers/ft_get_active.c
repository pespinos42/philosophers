/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_active.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:50:38 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:51:57 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_get_active(t_all *data, int *active)
{
	if (pthread_mutex_lock(&data->m_active) != 0)
		return ;
	*active = data->active;
	if (pthread_mutex_unlock(&data->m_active) != 0)
		return ;
}
