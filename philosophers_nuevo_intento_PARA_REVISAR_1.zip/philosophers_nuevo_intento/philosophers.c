/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philosophers.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/25 13:00:11 by pespinos          #+#    #+#             */
/*   Updated: 2023/06/25 13:00:11 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

//----------------------------DATA_FILOSOFOS.C----------------------------------
void	ft_i_m_d_p(t_data_philosopher *d_p, int n_p)
{
	int	n;

	n = 0;
	while (n < n_p)
	{
		if (pthread_mutex_init(&d_p[n].m_i_p, NULL) != 0)
			return ;
		if (pthread_mutex_init(&d_p[n].m_l_e, NULL) != 0)
			return ;
		if (pthread_mutex_init(&d_p[n].m_n_e, NULL) != 0)
			return ;
		if (pthread_mutex_init(&d_p[n].m_f_l, NULL) != 0)
			return ;
		if (pthread_mutex_init(&d_p[n].m_f_r, NULL) != 0)
			return ;
		if (pthread_mutex_init(&d_p[n].m_s_t, NULL) != 0)
			return ;
		if (pthread_mutex_init(&d_p[n].m_s_th, NULL) != 0)
			return ;
		if (pthread_mutex_init(&d_p[n].m_e_y, NULL) != 0)
			return ;
		n++;
	}
}

void	ft_d_m_d_p(t_data_philosopher *d_p, int n_p)
{
	int	n;

	n = 0;
	while (n < n_p)
	{
		if (pthread_mutex_destroy(&d_p[n].m_i_p) != 0)
			return ;
		if (pthread_mutex_destroy(&d_p[n].m_l_e) != 0)
			return ;
		if (pthread_mutex_destroy(&d_p[n].m_n_e) != 0)
			return ;
		if (pthread_mutex_destroy(&d_p[n].m_f_l) != 0)
			return ;
		if (pthread_mutex_destroy(&d_p[n].m_f_r) != 0)
			return ;
		if (pthread_mutex_destroy(&d_p[n].m_s_t) != 0)
			return ;
		if (pthread_mutex_destroy(&d_p[n].m_s_th) != 0)
			return ;
		if (pthread_mutex_destroy(&d_p[n].m_e_y) != 0)
			return ;
		n++;
	}
}

int	ft_get_i_p(t_data_philosopher *d_p)
{
	int	i_p;

	i_p = -1;
	if (pthread_mutex_lock(&d_p->m_i_p) != 0)
		return (-1);
	i_p = d_p->i_p;
	if (pthread_mutex_unlock(&d_p->m_i_p) != 0)
		return (-1);
	return (i_p);
}

void	ft_set_i_p(t_data_philosopher *d_p, int value)
{
	if (pthread_mutex_lock(&d_p->m_i_p) != 0)
		return ;
	d_p->i_p = value;
	if (pthread_mutex_unlock(&d_p->m_i_p) != 0)
		return ;
}

long int	ft_get_l_e(t_data_philosopher *d_p)
{
	long int	l_e;

	l_e = -1;
	if (pthread_mutex_lock(&d_p->m_l_e) != 0)
		return (-1);
	l_e = d_p->l_e;
	if (pthread_mutex_unlock(&d_p->m_l_e) != 0)
		return (-1);
	return (l_e);
}

void	ft_set_l_e(t_data_philosopher *d_p, long int value)
{
	if (pthread_mutex_lock(&d_p->m_l_e) != 0)
		return ;
	d_p->l_e = value;
	if (pthread_mutex_unlock(&d_p->m_l_e) != 0)
		return ;
}

int	ft_get_f_l(t_data_philosopher *d_p)
{
	int	f_l;

	f_l = -1;
	if (pthread_mutex_lock(&d_p->m_f_l) != 0)
		return (-1);
	f_l = d_p->f_l;
	if (pthread_mutex_unlock(&d_p->m_f_l) != 0)
		return (-1);
	return (f_l);
}

void	ft_set_f_l(t_data_philosopher *d_p, int value)
{
	if (pthread_mutex_lock(&d_p->m_f_l) != 0)
		return ;
	d_p->f_l = value;
	if (pthread_mutex_unlock(&d_p->m_f_l) != 0)
		return ;
}

int	ft_get_f_r(t_data_philosopher *d_p)
{
	int	f_r;

	f_r = -1;
	if (pthread_mutex_lock(&d_p->m_f_r) != 0)
		return (-1);
	f_r = d_p->f_r;
	if (pthread_mutex_unlock(&d_p->m_f_r) != 0)
		return (-1);
	return (f_r);
}

void	ft_set_f_r(t_data_philosopher *d_p, int value)
{
	if (pthread_mutex_lock(&d_p->m_f_r) != 0)
		return ;
	d_p->f_r = value;
	if (pthread_mutex_unlock(&d_p->m_f_r) != 0)
		return ;
}

int	ft_get_n_e(t_data_philosopher *d_p)
{
	int	n_e;

	n_e = -1;
	if (pthread_mutex_lock(&d_p->m_n_e) != 0)
		return (-1);
	n_e = d_p->n_e;
	if (pthread_mutex_unlock(&d_p->m_n_e) != 0)
		return (-1);
	return (n_e);
}

void	ft_set_n_e(t_data_philosopher *d_p, int value)
{
	if (pthread_mutex_lock(&d_p->m_n_e) != 0)
		return ;
	d_p->n_e = value;
	if (pthread_mutex_unlock(&d_p->m_n_e) != 0)
		return ;
}

long int	ft_get_s_t(t_data_philosopher *d_p)
{
	long int	s_t;

	s_t = -1;
	if (pthread_mutex_lock(&d_p->m_s_t) != 0)
		return (-1);
	s_t = d_p->s_t;
	if (pthread_mutex_unlock(&d_p->m_s_t) != 0)
		return (-1);
	return (s_t);
}

void	ft_set_s_t(t_data_philosopher *d_p, long int value)
{
	if (pthread_mutex_lock(&d_p->m_s_t) != 0)
		return ;
	d_p->s_t = value;
	if (pthread_mutex_unlock(&d_p->m_s_t) != 0)
		return ;
}

long int	ft_get_s_th(t_data_philosopher *d_p)
{
	long int	s_th;

	s_th = -1;
	if (pthread_mutex_lock(&d_p->m_s_th) != 0)
		return (-1);
	s_th = d_p->s_th;
	if (pthread_mutex_unlock(&d_p->m_s_th) != 0)
		return (-1);
	return (s_th);
}

void	ft_set_s_th(t_data_philosopher *d_p, long int value)
{
	if (pthread_mutex_lock(&d_p->m_s_th) != 0)
		return ;
	d_p->s_th = value;
	if (pthread_mutex_unlock(&d_p->m_s_th) != 0)
		return ;
}

int	ft_get_e_y(t_data_philosopher *d_p)
{
	int	e_y;

	e_y = -1;
	if (pthread_mutex_lock(&d_p->m_e_y) != 0)
		return (-1);
	e_y = d_p->e_y;
	if (pthread_mutex_unlock(&d_p->m_e_y) != 0)
		return (-1);
	return (e_y);
}

void	ft_set_e_y(t_data_philosopher *d_p, int value)
{
	if (pthread_mutex_lock(&d_p->m_e_y) != 0)
		return ;
	d_p->e_y = value;
	if (pthread_mutex_unlock(&d_p->m_e_y) != 0)
		return ;
}

t_data_philosopher	*ft_create_data_philosophers(t_all *data)
{
	t_data_philosopher	*d_p;
	int					n;

	n = 0;
	d_p = malloc (ft_get_n_p(data) * sizeof (*d_p));
	if (!d_p)
		return (NULL);
	ft_i_m_d_p(d_p, ft_get_n_p(data));
	while (n < ft_get_n_p(data))
	{
		ft_set_l_e(&d_p[n], -1);
		ft_set_n_e(&d_p[n], 0);
		ft_set_f_l(&d_p[n], -1);
		ft_set_f_r(&d_p[n], -1);
		ft_set_s_t(&d_p[n], -1);
		ft_set_e_y(&d_p[n], 0);
		n++;
	}
	return (d_p);
}

//------------------------FIN DATA_FILOSOFOS.C----------------------------------

//-------------------------FORKS.C-----------------------
t_fork	*ft_create_forks(int n_forks)
{
	t_fork	*forks;

	forks = malloc (n_forks * sizeof (*forks));
	if (!forks)
		return (NULL);
	return (forks);
}

void	ft_lock_fork(t_fork *forks, int n_fork)
{
	if (pthread_mutex_lock(&forks[n_fork].m_u_f) != 0)
		return ;
}

void	ft_unlock_fork(t_fork *forks, int n_fork)
{
	if (pthread_mutex_unlock(&forks[n_fork].m_u_f) != 0)
		return ;
}

void	ft_init_mutex_forks(t_fork *forks, int n_forks)
{
	int	n;

	n = 0;
	while (n < n_forks)
	{
		if (pthread_mutex_init(&forks[n].m_u_f, NULL) != 0)
			return ;
		n++;
	}
}

void	ft_destroy_mutex_forks(t_fork *forks, int n_forks)
{
	int	n;

	n = 0;
	while (n < n_forks)
	{
		if (pthread_mutex_destroy(&forks[n].m_u_f) != 0)
			return ;
		n++;
	}
}

//---------------------FIN FORKS.C------------------------

//----------------------------------ALL.C---------------------------
int	ft_get_active(t_all *data)
{
	int	active;

	active = -1;
	if (pthread_mutex_lock(&data->mutex_active) != 0)
		return (-1);
	active = data->active;
	if (pthread_mutex_unlock(&data->mutex_active) != 0)
		return (-1);
	return (active);
}

void	ft_set_active(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->mutex_active) != 0)
		return ;
	data->active = value;
	if (pthread_mutex_unlock(&data->mutex_active) != 0)
		return ;
}

int	ft_get_n_p(t_all *data)
{
	int	n_p;

	n_p = -1;
	if (pthread_mutex_lock(&data->m_n_p) != 0)
		return (-1);
	n_p = data->n_p;
	if (pthread_mutex_unlock(&data->m_n_p) != 0)
		return (-1);
	return (n_p);
}

void	ft_set_n_p(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->m_n_p) != 0)
		return ;
	data->n_p = value;
	if (pthread_mutex_unlock(&data->m_n_p) != 0)
		return ;
}

long int	ft_get_t_to_die(t_all *data)
{
	long int	time_to_die;

	time_to_die = -1;
	if (pthread_mutex_lock(&data->m_t_t_d) != 0)
		return (-1);
	time_to_die = data->t_t_d;
	if (pthread_mutex_unlock(&data->m_t_t_d) != 0)
		return (-1);
	return (time_to_die);
}

void	ft_set_time_to_die(t_all *data, long int value)
{
	if (pthread_mutex_lock(&data->m_t_t_d) != 0)
		return ;
	data->t_t_d = value;
	if (pthread_mutex_unlock(&data->m_t_t_d) != 0)
		return ;
}

long int	ft_get_t_to_eat(t_all *data)
{
	long int	time_to_eat;

	time_to_eat = -1;
	if (pthread_mutex_lock(&data->m_t_t_e) != 0)
		return (-1);
	time_to_eat = data->t_t_e;
	if (pthread_mutex_unlock(&data->m_t_t_e) != 0)
		return (-1);
	return (time_to_eat);
}

void	ft_set_time_to_eat(t_all *data, long int value)
{
	if (pthread_mutex_lock(&data->m_t_t_e) != 0)
		return ;
	data->t_t_e = value;
	if (pthread_mutex_unlock(&data->m_t_t_e) != 0)
		return ;
}

long int	ft_get_t_to_sleep(t_all *data)
{
	long int	time_to_sleep;

	time_to_sleep = -1;
	if (pthread_mutex_lock(&data->m_t_t_s) != 0)
		return (-1);
	time_to_sleep = data->t_t_s;
	if (pthread_mutex_unlock(&data->m_t_t_s) != 0)
		return (-1);
	return (time_to_sleep);
}

void	ft_set_time_to_sleep(t_all *data, long int value)
{
	if (pthread_mutex_lock(&data->m_t_t_s) != 0)
		return ;
	data->t_t_s = value;
	if (pthread_mutex_unlock(&data->m_t_t_s) != 0)
		return ;
}

int	ft_get_number_of_times_eat(t_all *data)
{
	int	number_of_times;

	number_of_times = -1;
	if (pthread_mutex_lock(&data->m_n_o_t_e) != 0)
		return (-1);
	number_of_times = data->n_o_t_e;
	if (pthread_mutex_unlock(&data->m_n_o_t_e) != 0)
		return (-1);
	return (number_of_times);
}

void	ft_set_number_of_times_eat(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->m_n_o_t_e) != 0)
		return ;
	data->n_o_t_e = value;
	if (pthread_mutex_unlock(&data->m_n_o_t_e) != 0)
		return ;
}

void	ft_set_all_out(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->m_a_o) != 0)
		return ;
	data->a_o = value;
	if (pthread_mutex_unlock(&data->m_a_o) != 0)
		return ;
}

int	ft_get_all_out(t_all *data)
{
	int	all_out;

	all_out = -1;
	if (pthread_mutex_lock(&data->m_a_o) != 0)
		return (-1);
	all_out = data->a_o;
	if (pthread_mutex_unlock(&data->m_a_o) != 0)
		return (-1);
	return (all_out);
}

int	ft_get_a_a(t_all *data)
{
	int	all_alive;

	all_alive = -1;
	if (pthread_mutex_lock(&data->m_a_a) != 0)
		return (-1);
	all_alive = data->a_a;
	if (pthread_mutex_unlock(&data->m_a_a) != 0)
		return (-1);
	return (all_alive);
}

void	ft_set_all_alive(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->m_a_a) != 0)
		return ;
	data->a_a = value;
	if (pthread_mutex_unlock(&data->m_a_a) != 0)
		return ;
}

int	ft_get_total_exit(t_all *data)
{
	int	total_exit;

	total_exit = -1;
	if (pthread_mutex_lock(&data->m_t_e) != 0)
		return (-1);
	total_exit = data->t_e;
	if (pthread_mutex_unlock(&data->m_t_e) != 0)
		return (-1);
	return (total_exit);
}

void	ft_set_total_exit(t_all *data, int value)
{
	if (pthread_mutex_lock(&data->m_t_e) != 0)
		return ;
	data->t_e = value;
	if (pthread_mutex_unlock(&data->m_t_e) != 0)
		return ;
}

void	ft_init_mutex_data(t_all *data)
{
	if (pthread_mutex_init(&data->m_n_p, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_a_a, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_t_t_d, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_t_t_e, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_t_t_s, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_n_o_t_e, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->mutex_active, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_m, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_a_o, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_t_e, NULL) != 0)
		return ;
}

void	ft_destroy_mutex_data(t_all *data)
{
	if (pthread_mutex_destroy(&data->m_n_p) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_a_a) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_t_t_d) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_t_t_e) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_t_t_s) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_n_o_t_e) != 0)
		return ;
	if (pthread_mutex_destroy(&data->mutex_active) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_m) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_a_o) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_t_e) != 0)
		return ;
}
//------------------------------------------FIN ALL.C----------------------
//-----------------------------------ATOI.C---------------------------------

void	ft_initialize_data_atoi(t_atoi *d)
{
	d->result = 0;
	d->s = 0;
	d->sign = 1;
}

long int	ft_atoi(char *str)
{
	t_atoi	d;

	ft_initialize_data_atoi(&d);
	while ((*str >= 9 && *str <= 13) || *str == 32)
		str++;
	if (*str == '+')
	{
		d.s++;
		str++;
	}
	if (*str == '-' && d.s == 0)
	{
		d.sign = -1;
		str++;
	}
	if (*str == '-' && d.s == 1)
		d.sign = 0;
	while (*str >= '0' && *str <= '9')
	{
		d.result = d.result * 10 + (*str - 48);
		str++;
	}
	return (d.sign * d.result);
}
//---------------------------------------FIN ATOI.C----------------------------
//----------------------------------ARGS.C-------------------------------------

int	ft_strlen(char *str)
{
	int	len;

	len = 0;
	while (str[len])
		len++;
	return (len);
}

long int	*ft_get_args(int argc, char **argv)
{
	long int	*args;
	int			n;

	n = 1;
	args = malloc ((argc - 1) * sizeof (*args));
	if (!args)
		return (NULL);
	while (n < argc)
	{
		args[n - 1] = ft_atoi(argv[n]);
		n++;
	}
	return (args);
}

int	ft_check_only_numbers(int argc, char **argv)
{
	int	arg;
	int	letter;
	int	check;

	arg = 1;
	letter = 0;
	check = 1;
	while (arg < argc && check == 1)
	{
		while (letter < ft_strlen(argv[arg]) && check == 1)
		{
			if (argv[arg][letter] < 48 || argv[arg][letter] > 57)
				check = 0;
			letter++;
		}
		letter = 0;
		arg++;
	}
	return (check);
}

int	ft_check_limits(long int *args, int n_args)
{
	int	n;
	int	check;

	n = 0;
	check = 1;
	while (n < n_args && check == 1)
	{
		if (args[n] > 2147483647)
			check = 0;
		n++;
	}
	return (check);
}

int	ft_check_args(int argc, char **argv)
{
	long int	*args;

	if (ft_check_only_numbers(argc, argv) != 1)
		return (-1);
	args = ft_get_args(argc, argv);
	if (ft_check_limits(args, argc - 1) != 1)
		return (free (args), -1);
	if (args[0] <= 0 || args[0] > 200)
		return (free (args), -1);
	if (argc == 6 && args[4] <= 0)
		return (free (args), -1);
	free (args);
	return (1);
}
//-------------------------------------FIN ARGS.C------------------------------

//------------------------------------
void	ft_p_m(t_all *data, long int time, int p, char *message)
{
	if (pthread_mutex_lock(&data->m_m) != 0)
		return ;
	ft_print_number(time);
	write(1, " ", 1);
	ft_print_number(p);
	write(1, message, ft_strlen(message));
	write(1, "\n", 1);
	if (pthread_mutex_unlock(&data->m_m) != 0)
		return ;
}

void	ft_wait(t_all *data, long int time_to_wait)
{
	long int	s_t;

	s_t = ft_get_t() + time_to_wait;
	while (s_t > ft_get_t() && ft_get_a_a(data) == 1)
		usleep(100);
}

void	ft_data_philosopher(t_temp *temp)
{
	temp->time_to_die = -1;
	temp->time_to_eat = -1;
	temp->l_e = -1;
	temp->s_t = -1;
	temp->n_e = -1;
	temp->active = -1;
}

void	ft_assign_forks(t_all *data, t_temp *temp) //AGREGAR A .H
{
	ft_set_f_r(&data->d_p[temp->active], ft_get_i_p(&data->d_p[temp->active]));
	if (ft_get_i_p(&data->d_p[temp->active]) == ft_get_n_p(data) - 1)
		ft_set_f_l(&data->d_p[temp->active], 0);
	else
		ft_set_f_l(&data->d_p[temp->active], ft_get_i_p(&data->d_p[temp->active]) + 1);
}

void	ft_get_forks(t_all *data, t_temp *temp) //AGREGAR A .H
{
	ft_lock_fork(data->forks, ft_get_f_r(&data->d_p[temp->active]));
	ft_p_m(data, ft_get_t(), temp->active + 1, " has taken a fork");
	ft_lock_fork(data->forks, ft_get_f_l(&data->d_p[temp->active]));
	ft_p_m(data, ft_get_t(), temp->active + 1, " has taken a fork");
}

void	ft_eating(t_all *data, t_temp *temp) //AGREGAR A .H
{
	if (ft_get_a_a(data) == 1)
	{
		ft_p_m(data, ft_get_t(), ft_get_i_p(&data->d_p[temp->active]) + 1, " is eating");
		ft_wait(data, ft_get_t_to_eat(data));
		ft_set_l_e(&data->d_p[temp->active], ft_get_t());
	}
}

void	ft_release_forks(t_all *data, t_temp *temp) //AGREGAR A .H
{
	ft_unlock_fork(data->forks, ft_get_f_l(&data->d_p[temp->active]));
	ft_unlock_fork(data->forks, ft_get_f_r(&data->d_p[temp->active]));
	temp->n_e = temp->n_e + 1;
	ft_set_n_e(&data->d_p[temp->active], ft_get_n_e(&data->d_p[temp->active]) + 1);
}

void	ft_check_exit_yet(t_all *data, t_temp *temp) //AGREGAR A .H
{
	if (ft_get_number_of_times_eat(data) != -1 && ft_get_n_e(&data->d_p[temp->active]) >= ft_get_number_of_times_eat(data))
		ft_set_e_y(&data->d_p[temp->active], 1);
}

void	ft_sleeping_thinking(t_all *data, t_temp *temp)
{
	if (ft_get_e_y(&data->d_p[temp->active]) == 0 && ft_get_a_a(data) == 1)
	{
		ft_p_m(data, ft_get_t(), ft_get_i_p(&data->d_p[temp->active]) + 1, " is sleeping");
		ft_wait(data, ft_get_t_to_sleep(data));
		temp->time_to_die = ft_get_t_to_die(data);
		temp->l_e = ft_get_l_e(&data->d_p[temp->active]);
		temp->time_to_eat = ft_get_t_to_eat(data);
		temp->s_t = (temp->time_to_die - ((ft_get_t() - temp->l_e) + temp->time_to_eat)) / 2;
		ft_set_s_t(&data->d_p[temp->active], temp->s_t);
		if (ft_get_a_a(data) == 1)
		{
			ft_p_m(data, ft_get_t(), ft_get_i_p(&data->d_p[temp->active]) + 1, " is thinking");
			if (temp->s_t > 100 && ft_get_a_a(data) == 1)
			{
				if (temp->s_t > 500)
				{
					temp->s_t = 500;
					ft_set_s_t(&data->d_p[temp->active], temp->s_t);
				}
				ft_wait(data, ft_get_s_t(&data->d_p[temp->active]));
			}
		}
	}
}

void	ft_if_ok(t_all *data, t_temp *temp) //AGREGAR A .H
{
	ft_assign_forks(data, temp);
	while (ft_get_a_a(data) == 1 && ft_get_e_y(&data->d_p[temp->active]) == 0)
	{
		ft_get_forks(data, temp);
		ft_eating(data, temp);
		ft_release_forks(data, temp);
		ft_check_exit_yet(data, temp);
		ft_sleeping_thinking(data, temp);
	}
}

void	*ft_philosopher(void *arg)
{
	t_all		*data;
	t_temp		temp;

	ft_data_philosopher(&temp);
	data = (t_all *) arg;
	temp.active = ft_get_active(data);
	ft_set_i_p(&data->d_p[temp.active], temp.active);
	ft_set_s_th(&data->d_p[temp.active], ft_get_t());
	if (ft_get_n_p(data) > 1 && ft_get_t_to_die(data) > 0)
	{
		ft_if_ok(data, &temp);
	}
	else if (ft_get_n_p(data) == 1 || ft_get_t_to_die(data) == 0)
	{
		while (ft_get_a_a(data) == 1)
		{
			ft_wait(data, 1);
		}
	}
	ft_set_total_exit(data, ft_get_total_exit(data) + 1);
	return (NULL);
}

void	ft_initialize_data_all_alive(t_data_all_alive *d_a_a)
{
	d_a_a->n = 0;
	d_a_a->time = 0;
	d_a_a->time_start = -1;
	d_a_a->s_th = -1;
	d_a_a->l_e = -1;
	d_a_a->t_t_d = -1;
	d_a_a->t_e = -1;
	d_a_a->s_th = -1;
}

void	ft_start_thread_ok(t_all *data, t_data_all_alive *data_all_alive) //AGREGAR A .H
{
	if (data_all_alive->s_th != -1)
	{
		data_all_alive->l_e = ft_get_l_e(&data->d_p[data_all_alive->n]);
		if (data_all_alive->l_e == -1)
		{
			data_all_alive->time_start = ft_get_s_th(&data->d_p[data_all_alive->n]);
		}
		else
		{
			data_all_alive->time_start = ft_get_l_e(&data->d_p[data_all_alive->n]);
		}
		data_all_alive->time = ft_get_t();
		data_all_alive->t_t_d = ft_get_t_to_die(data);
		if ((data_all_alive->time - data_all_alive->time_start) >= data_all_alive->t_t_d)
		{
			if (ft_get_e_y(&data->d_p[data_all_alive->n]) == 0)
			{
				ft_p_m(data, ft_get_t(), data_all_alive->n + 1, " is died");
				ft_set_all_alive(data, 0);
			}
		}
		data_all_alive->n = data_all_alive->n + 1;
	}
}

void	*ft_all_alive(void *arg)
{
	t_all				*data;
	t_data_all_alive	data_all_alive;

	data = (t_all *) arg;
	ft_initialize_data_all_alive(&data_all_alive);
	while (ft_get_s_th(&data->d_p[ft_get_n_p(data) - 1]) <= 0)
		ft_wait(data, 100);
	while (ft_get_a_a(data) == 1 && ft_get_total_exit(data) < ft_get_n_p(data))
	{
		while (data_all_alive.n < ft_get_n_p(data) && ft_get_a_a(data) == 1)
		{
			data_all_alive.s_th = ft_get_s_th(&data->d_p[data_all_alive.n]);
			ft_start_thread_ok(data, &data_all_alive);
		}
		data_all_alive.n = 0;
	}
	return (NULL);
}

pthread_t	*ft_create_threads(t_all *data)
{
	pthread_t	*threads;

	threads = malloc (ft_get_n_p(data) * sizeof (*threads));
	if (!threads)
		return (NULL);
	return (threads);
}

void	ft_initialize_threads(t_all *data)
{
	int	n;

	n = 0;
	if (pthread_create(&data->t_a_a, NULL, ft_all_alive, data) != 0)
		return ;
	usleep(1000);
	while (n < ft_get_n_p(data))
	{
		ft_set_active(data, n);
		if (pthread_create(&data->threads[n], NULL, ft_philosopher, data) != 0)
			return ;
		usleep(100);
		n++;
	}
}

void	ft_s_ths(t_all *data)
{
	int	n;

	n = 0;
	if (pthread_join(data->t_a_a, NULL) != 0)
		return ;
	while (n < ft_get_n_p(data))
	{
		if (pthread_join(data->threads[n], NULL) != 0)
			return ;
		n++;
	}
}

void	ft_fill_data(t_all *data, long int *args, int argc)
{
	ft_init_mutex_data(data);
	ft_set_n_p(data, args[0]);
	ft_set_all_alive(data, 1);
	ft_set_time_to_die(data, args[1]);
	ft_set_time_to_eat(data, args[2]);
	ft_set_time_to_sleep(data, args[3]);
	if (argc == 6)
		ft_set_number_of_times_eat(data, args[4]);
	else
		ft_set_number_of_times_eat(data, -1);
	data->forks = ft_create_forks(args[0]);
	ft_init_mutex_forks(data->forks, args[0]);
	data->d_p = ft_create_data_philosophers(data);
	data->threads = ft_create_threads(data);
	ft_set_total_exit(data, 0);
}

void	ft_print_number(long int n)
{
	char	number;

	number = 0;
	if (n == INT_MIN)
		write(1, "-2147483648", 11);
	else if (n < 0)
	{
		write(1, "-", 1);
		ft_print_number(-n);
	}
	else
	{
		if (n > 9)
			ft_print_number(n / 10);
		number = (n % 10) + 48;
		write(1, &number, 1);
	}
}

long int	ft_get_t(void)
{
	struct timeval	tv;

	gettimeofday(&tv, NULL);
	return ((tv.tv_sec * 1000) + (tv.tv_usec / 1000));
}

void	ft_clean_all(t_all *data, long int *args)
{
	ft_destroy_mutex_forks(data->forks, ft_get_n_p(data));
	ft_d_m_d_p(data->d_p, ft_get_n_p(data));
	ft_destroy_mutex_data(data);
	free(args);
	free(data->forks);
	free(data->d_p);
	free(data->threads);
}

int	main(int argc, char **argv)
{
	long int	*args;
	t_all		data;

	if (argc == 5 || argc == 6)
	{
		if (ft_check_args(argc, argv) == 1)
		{
			args = ft_get_args(argc, argv);
			ft_fill_data(&data, args, argc);
			ft_initialize_threads(&data);
			ft_s_ths(&data);
			ft_clean_all(&data, args);
		}
		else
			printf("WRONG PARAMETERS\n");
	}
	else
	{
		printf("WRONG PARAMETERS\n");
	}
}
