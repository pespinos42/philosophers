/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fill_data.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:50:33 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:51:52 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_fill_data(t_philosopher *phil, long int *data, int n_arg)
{
	int	p;

	p = 0;
	while (p < data[0])
	{
		phil[p].index_philosopher = p + 1;
		phil[p].time_to_die = data[1];
		phil[p].time_to_eat = data[2];
		phil[p].time_to_sleep = data[3];
		if (n_arg == 5)
			phil[p].number_of_times = data[4];
		else
			phil[p].number_of_times = -1;
		if (pthread_mutex_init(&phil[p].m_s_th, NULL) != 0)
			return ;
		if (pthread_mutex_init(&phil[p].m_l_eat, NULL) != 0)
			return ;
		p++;
	}
}
