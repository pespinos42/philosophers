/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_died.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:51:13 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:52:20 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_print_died(t_all *data, t_d_a_alive *d)
{
	ft_set_all_alive(data);
	if (pthread_mutex_lock(&data->m_message) != 0)
		return ;
	ft_p_message(data, d->time, d->n, " died");
	if (pthread_mutex_unlock(&data->m_message) != 0)
		return ;
}
