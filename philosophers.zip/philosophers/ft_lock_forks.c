#include "philosophers.h"

void	ft_lock_forks(t_all *data, int f_right, int f_left)
{
	if (pthread_mutex_lock(&data->m_read_forks) != 0)
		return ;
	data->forks[f_right].using = 1;
	data->forks[f_left].using = 1;
	if (pthread_mutex_unlock(&data->m_read_forks) != 0)
		return ;
	if (pthread_mutex_lock(&data->forks[f_right].fork_mutex) != 0)
		return ;
	if (pthread_mutex_lock(&data->forks[f_left].fork_mutex) != 0)
		return ;
}

void	ft_unlock_forks(t_all *data, int f_right, int f_left)
{
	if (pthread_mutex_unlock(&data->forks[f_left].fork_mutex) != 0)
		return ;
	if (pthread_mutex_unlock(&data->forks[f_right].fork_mutex) != 0)
		return ;
	if (pthread_mutex_lock(&data->m_read_forks) != 0)
		return ;
	data->forks[f_left].using = 0;
	data->forks[f_right].using = 0;
	if (pthread_mutex_unlock(&data->m_read_forks) != 0)
		return ;
}