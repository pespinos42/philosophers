/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_stop_time.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:50:45 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:52:02 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_get_stop_time(t_all *data, int active, long int *stop_time)
{
	long int	time_to_die;
	long int	last_eating;
	long int	time_to_eat;
	long int	time;

	time_to_die = data->phi[active].time_to_die;
	last_eating = data->phi[active].last_eating;
	time_to_eat = data->phi[active].time_to_eat;
	time = ft_get_time();
	*stop_time = (time_to_die - ((time - last_eating) + time_to_eat)) / 2;
	if (*stop_time > 500)
		*stop_time = 500;
}
