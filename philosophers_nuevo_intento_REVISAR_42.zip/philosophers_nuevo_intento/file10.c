#include "philosophers.h"

long int	ft_atoi(char *str)
{
	t_atoi	d;

	ft_initialize_data_atoi(&d);
	while ((*str >= 9 && *str <= 13) || *str == 32)
		str++;
	if (*str == '+')
	{
		d.s++;
		str++;
	}
	if (*str == '-' && d.s == 0)
	{
		d.sign = -1;
		str++;
	}
	if (*str == '-' && d.s == 1)
		d.sign = 0;
	while (*str >= '0' && *str <= '9')
	{
		d.result = d.result * 10 + (*str - 48);
		str++;
	}
	return (d.sign * d.result);
}
//---------------------------------------FIN ATOI.C----------------------------
//----------------------------------ARGS.C-------------------------------------

int	ft_strlen(char *str)
{
	int	len;

	len = 0;
	while (str[len])
		len++;
	return (len);
}

long int	*ft_get_args(int argc, char **argv)
{
	long int	*args;
	int			n;

	n = 1;
	args = malloc ((argc - 1) * sizeof (*args));
	if (!args)
		return (NULL);
	while (n < argc)
	{
		args[n - 1] = ft_atoi(argv[n]);
		n++;
	}
	return (args);
}

int	ft_check_only_numbers(int argc, char **argv)
{
	int	arg;
	int	letter;
	int	check;

	arg = 1;
	letter = 0;
	check = 1;
	while (arg < argc && check == 1)
	{
		while (letter < ft_strlen(argv[arg]) && check == 1)
		{
			if (argv[arg][letter] < 48 || argv[arg][letter] > 57)
				check = 0;
			letter++;
		}
		letter = 0;
		arg++;
	}
	return (check);
}

int	ft_check_limits(long int *args, int n_args)
{
	int	n;
	int	check;

	n = 0;
	check = 1;
	while (n < n_args && check == 1)
	{
		if (args[n] > 2147483647)
			check = 0;
		n++;
	}
	return (check);
}
