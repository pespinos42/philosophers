#include "philosophers.h"

void	ft_p_message(t_all *data, long int time, int phil, char *m)
{
	ft_print_number(time);
	write(1, " ", 1);
	ft_print_number(data->phi[phil].index_philosopher);
	write(1, " ", 1);
	write(1, m, ft_strlen(m));
	write(1, "\n", 1);
}