/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philosophers.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/25 13:00:11 by pespinos          #+#    #+#             */
/*   Updated: 2023/06/25 13:00:11 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

int	main(int argc, char **argv)
{
	long int	*args;
	t_all		data;

	if (argc == 5 || argc == 6)
	{
		if (ft_check_args(argc, argv) == 1)
		{
			args = ft_get_args(argc, argv);
			ft_fill_data(&data, args, argc);
			ft_initialize_threads(&data);
			ft_s_ths(&data);
			ft_clean_all(&data, args);
		}
		else
			printf("WRONG PARAMETERS\n");
	}
	else
	{
		printf("WRONG PARAMETERS\n");
	}
}
