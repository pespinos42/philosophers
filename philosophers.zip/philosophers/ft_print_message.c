/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_message.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:51:15 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:52:24 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_print_message(t_all *data, int active, char *msg)
{
	if (pthread_mutex_lock(&data->m_message) != 0)
		return ;
	ft_p_message(data, ft_get_time(), active, msg);
	if (pthread_mutex_unlock(&data->m_message) != 0)
		return ;
}
