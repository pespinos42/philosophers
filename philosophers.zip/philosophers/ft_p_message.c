/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_p_message.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:51:02 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:52:16 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_p_message(t_all *data, long int time, int phil, char *m)
{
	ft_print_number(time);
	write(1, " ", 1);
	ft_print_number(data->phi[phil].index_philosopher);
	write(1, " ", 1);
	write(1, m, ft_strlen(m));
	write(1, "\n", 1);
}
