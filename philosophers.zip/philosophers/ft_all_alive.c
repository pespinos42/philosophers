/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_all_alive.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:50:18 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:51:39 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	*ft_all_alive(void *arg)
{
	t_all		*data;
	t_d_a_alive	d;

	data = (t_all *) arg;
	ft_initialize_data_all_alive(&d);
	d.n = 0;
	d.time = 0;
	ft_get_total_exit(data, &d.total_exit);
	while (data->all_alive == 1 && d.total_exit < data->total_philosophers)
	{
		while (d.n < data->total_philosophers && data->all_alive == 1)
		{
			ft_g_s_thread(data, &d);
			if (d.start_thread != -1)
				ft_thread_started(data, &d);
			d.n++;
		}
		d.n = 0;
		usleep(1000);
		ft_get_total_exit(data, &d.total_exit);
	}
	return (NULL);
}
