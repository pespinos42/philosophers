/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_thread_started.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:51:24 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:52:33 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_thread_started(t_all *data, t_d_a_alive *d)
{
	ft_g_l_eating(data, d);
	ft_g_time_start(data, d);
	d->time = ft_get_time();
	ft_g_t_t_die(data, d);
	if ((d->time - d->time_start) >= d->time_to_die)
	{
		if (data->phi[d->n].number_exit == 0)
			ft_print_died(data, d);
	}
}
