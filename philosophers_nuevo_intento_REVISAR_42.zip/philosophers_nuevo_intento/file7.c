#include "philosophers.h"

long int	ft_get_t_to_eat(t_all *data)
{
	long int	time_to_eat;

	time_to_eat = -1;
	if (pthread_mutex_lock(&data->m_t_t_e) != 0)
		return (-1);
	time_to_eat = data->t_t_e;
	if (pthread_mutex_unlock(&data->m_t_t_e) != 0)
		return (-1);
	return (time_to_eat);
}

void	ft_set_time_to_eat(t_all *data, long int value)
{
	if (pthread_mutex_lock(&data->m_t_t_e) != 0)
		return ;
	data->t_t_e = value;
	if (pthread_mutex_unlock(&data->m_t_t_e) != 0)
		return ;
}

long int	ft_get_t_to_sleep(t_all *data)
{
	long int	time_to_sleep;

	time_to_sleep = -1;
	if (pthread_mutex_lock(&data->m_t_t_s) != 0)
		return (-1);
	time_to_sleep = data->t_t_s;
	if (pthread_mutex_unlock(&data->m_t_t_s) != 0)
		return (-1);
	return (time_to_sleep);
}

void	ft_set_time_to_sleep(t_all *data, long int value)
{
	if (pthread_mutex_lock(&data->m_t_t_s) != 0)
		return ;
	data->t_t_s = value;
	if (pthread_mutex_unlock(&data->m_t_t_s) != 0)
		return ;
}

int	ft_get_n_o_t_e(t_all *data)
{
	int	number_of_times;

	number_of_times = -1;
	if (pthread_mutex_lock(&data->m_n_o_t_e) != 0)
		return (-1);
	number_of_times = data->n_o_t_e;
	if (pthread_mutex_unlock(&data->m_n_o_t_e) != 0)
		return (-1);
	return (number_of_times);
}
