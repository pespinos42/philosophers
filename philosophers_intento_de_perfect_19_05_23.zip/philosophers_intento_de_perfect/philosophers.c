/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philosophers.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/13 20:35:45 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/21 19:56:55 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

int	ft_strlen(char *str)
{
	int	len;

	len = 0;
	while (str[len])
		len++;
	return (len);
}

void	ft_initialize_data_atoi(t_atoi *d)
{
	d->result = 0;
	d->s = 0;
	d->sign = 1;
}

long int	ft_atoi(char *str)
{
	t_atoi	d;

	ft_initialize_data_atoi(&d);
	while ((*str >= 9 && *str <= 13) || *str == 32)
		str++;
	if (*str == '+')
	{
		d.s++;
		str++;
	}
	if (*str == '-' && d.s == 0)
	{
		d.sign = -1;
		str++;
	}
	if (*str == '-' && d.s == 1)
		d.sign = 0;
	while (*str >= '0' && *str <= '9')
	{
		d.result = d.result * 10 + (*str - 48);
		str++;
	}
	return (d.sign * d.result);
}

long int	*ft_get_args(int argc, char **argv)
{
	long int	*args;
	int			n;

	n = 1;
	args = malloc ((argc - 1) * sizeof (*args));
	if (!args)
		return (NULL);
	while (n < argc)
	{
		args[n - 1] = ft_atoi(argv[n]);
		n++;
	}
	return (args);
}

void	ft_print_number(long int n)
{
	char	number;

	number = 0;
	if (n == INT_MIN)
		write(1, "-2147483648", 11);
	else if (n < 0)
	{
		write(1, "-", 1);
		ft_print_number(-n);
	}
	else
	{
		if (n > 9)
			ft_print_number(n / 10);
		number = (n % 10) + 48;
		write(1, &number, 1);
	}
}

long int	ft_get_time(void)
{
	struct timeval	tv;

	gettimeofday(&tv, NULL);
	return ((tv.tv_sec * 1000) + (tv.tv_usec / 1000));
}

void	ft_destroy_local_mutex(t_all *data)
{
	int	n;

	n = 0;
	while (n < data->total_philosophers)
	{
		if (pthread_mutex_destroy(&data->phi[n].m_l_eat) != 0)
			return ;
		if (pthread_mutex_destroy(&data->phi[n].m_s_th) != 0)
			return ;
		n++;
	}
}

void	ft_get_active(t_all *data, int *active)
{
	if (pthread_mutex_lock(&data->m_active) != 0)
		return ;
	*active = data->active;
	if (pthread_mutex_unlock(&data->m_active) != 0)
		return ;
}

void	ft_set_start_trhead(t_all *data, int active)
{
	if (pthread_mutex_lock(&data->phi[active].m_s_th) != 0)
		return ;
	data->phi[active].start_thread = ft_get_time();
	if (pthread_mutex_unlock(&data->phi[active].m_s_th) != 0)
		return ;
}

void	ft_get_all_alive(t_all *data, int *all_alive)
{
	if (pthread_mutex_lock(&data->m_a_alive) != 0)
		return ;
	*all_alive = data->all_alive;
	if (pthread_mutex_unlock(&data->m_a_alive) != 0)
		return ;
}

void	ft_print_message(t_all *data, int active, char *msg)
{
	if (pthread_mutex_lock(&data->m_message) != 0)
		return ;
	ft_p_message(data, ft_get_time(), active, msg);
	if (pthread_mutex_unlock(&data->m_message) != 0)
		return ;
}

void	ft_lock_forks(t_all *data, int f_right, int f_left)
{
	if (pthread_mutex_lock(&data->m_read_forks) != 0)
		return ;
	data->forks[f_right].using = 1;
	data->forks[f_left].using = 1;
	if (pthread_mutex_unlock(&data->m_read_forks) != 0)
		return ;
	if (pthread_mutex_lock(&data->forks[f_right].fork_mutex) != 0)
		return ;
	if (pthread_mutex_lock(&data->forks[f_left].fork_mutex) != 0)
		return ;
}

void	ft_print_eating(t_all *data, int active)
{
	int	stop_time;

	if (pthread_mutex_lock(&data->m_message) != 0)
		return ;
	ft_p_message(data, ft_get_time(), active, " has taken a fork");
	ft_p_message(data, ft_get_time(), active, " has taken a fork");
	ft_p_message(data, ft_get_time(), active, " is eating");
	if (pthread_mutex_unlock(&data->m_message) != 0)
		return ;
	stop_time = ft_get_time() + data->phi[active].time_to_eat;
	while (ft_get_time() < stop_time && data->all_alive == 1)
		usleep(1000);
}

void	ft_set_last_eating(t_all *data, int n)
{
	if (pthread_mutex_lock(&data->phi[n].m_l_eat) != 0)
		return ;
	data->phi[n].last_eating = ft_get_time();
	if (pthread_mutex_unlock(&data->phi[n].m_l_eat) != 0)
		return ;
}

void	ft_unlock_forks(t_all *data, int f_right, int f_left)
{
	if (pthread_mutex_unlock(&data->forks[f_left].fork_mutex) != 0)
		return ;
	if (pthread_mutex_unlock(&data->forks[f_right].fork_mutex) != 0)
		return ;
	if (pthread_mutex_lock(&data->m_read_forks) != 0)
		return ;
	data->forks[f_left].using = 0;
	data->forks[f_right].using = 0;
	if (pthread_mutex_unlock(&data->m_read_forks) != 0)
		return ;
}

void	ft_get_using_forks(t_all *data, int fork, int *u_fork)
{
	if (pthread_mutex_lock(&data->m_read_forks) != 0)
		return ;
	*u_fork = data->forks[fork].using;
	if (pthread_mutex_unlock(&data->m_read_forks) != 0)
		return ;
}

void	ft_get_stop_time(t_all *data, int active, long int *stop_time)
{
	long int	time_to_die;
	long int	last_eating;
	long int	time_to_eat;
	long int	time;

	time_to_die = data->phi[active].time_to_die;
	last_eating = data->phi[active].last_eating;
	time_to_eat = data->phi[active].time_to_eat;
	time = ft_get_time();
	*stop_time = (time_to_die - ((time - last_eating) + time_to_eat)) / 2;
	if (*stop_time > 500)
		*stop_time = 500;
}

void	ft_increment_total_exit(t_all *data)
{
	if (pthread_mutex_lock(&data->m_total_exit) != 0)
		return ;
	data->total_exit = data->total_exit + 1;
	if (pthread_mutex_unlock(&data->m_total_exit) != 0)
		return ;
}

void	ft_get_total_exit(t_all *data, int *total_exit)
{
	if (pthread_mutex_lock(&data->m_total_exit) != 0)
		return ;
	*total_exit = data->total_exit;
	if (pthread_mutex_unlock(&data->m_total_exit) != 0)
		return ;
}

void	ft_initialize_data_phi(t_data_philosopher *d)
{
	d->active = -1;
	d->fork_right = -1;
	d->fork_left = -1;
	d->time = -1;
	d->s_time = -1;
	d->n_times = -1;
	d->using_fork_left = -1;
	d->using_fork_right = -1;
	d->a_alive = -1;
	d->total_n_times = -1;
}

void	*philosopher(void *arg)
{
	t_all				*data; //
	t_data_philosopher	d; //

	data = (t_all *) arg; //
	ft_initialize_data_phi(&d); //
	ft_get_active(data, &d.active); //
	d.n_times = 0; //
	d.fork_right = d.active; //
	d.total_n_times = data->phi[d.active].number_of_times;//
	if (d.active == data->total_philosophers - 1) //
		d.fork_left = 0; //
	else //
		d.fork_left = d.fork_right + 1; //
	ft_set_start_trhead(data, d.active); //
	if (data->phi[d.active].time_to_die > 0 && data->total_philosophers > 1) //
	{//
		ft_get_all_alive(data, &d.a_alive);//
		while (d.a_alive == 1 && data->phi[d.active].number_exit == 0)//
		{
			// ft_get_using_forks(data, d.fork_right, &d.using_fork_right);//
			// ft_get_using_forks(data, d.fork_left, &d.using_fork_left);//
			// while (d.using_fork_right == 1 || d.using_fork_left == 1)//
			// {//
			// 	usleep(100);//
			// 	ft_get_using_forks(data, d.fork_right, &d.using_fork_right);//
			// 	ft_get_using_forks(data, d.fork_left, &d.using_fork_left);//
			// }//
			ft_get_all_alive(data, &d.a_alive);//
			if (d.a_alive == 1)//
			{//
				ft_lock_forks(data, d.fork_right, d.fork_left);//
				ft_print_eating(data, d.active);//
				ft_set_last_eating(data, d.active);//
				ft_unlock_forks(data, d.fork_right, d.fork_left);//
				d.n_times++;//
			}//
			if (d.total_n_times != -1 && d.n_times >= d.total_n_times)//
				data->phi[d.active].number_exit = 1;//
			if (data->phi[d.active].number_exit == 0)//
			{//
				ft_get_all_alive(data, &d.a_alive);//
				if (d.a_alive == 1)//
				{//
					ft_print_message(data, d.active, " is sleeping");//
					d.time = ft_get_time();//
					d.s_time = d.time + data->phi[d.active].time_to_sleep;//
					ft_get_all_alive(data, &d.a_alive);//
					while (ft_get_time() < d.s_time && d.a_alive == 1)//
						usleep(1000);//
				}//
				ft_get_all_alive(data, &d.a_alive);//
				if (d.a_alive == 1)//
				{//
					ft_get_stop_time(data, d.active, &d.s_time);//
					if (d.s_time > 0)//
					{//
						ft_get_all_alive(data, &d.a_alive);//
						if (d.a_alive == 1)//
							ft_print_message(data, d.active, " is thinking");//
						if (d.s_time > 100)//
						{//
							d.s_time += d.time;//
							while (ft_get_time() < d.s_time && d.a_alive == 1)
								usleep(1000);
						}
					}
				}
				d.s_time = 0;
			}
		}
	}
	ft_increment_total_exit(data);
	return (NULL);
}

//Rellenamos el array de filosofos con los datos introducidos
void	ft_fill_data(t_philosopher *phil, long int *data, int n_arg)
{
	int	p;

	p = 0;
	while (p < data[0])
	{
		phil[p].index_philosopher = p + 1;
		phil[p].time_to_die = data[1];
		phil[p].time_to_eat = data[2];
		phil[p].time_to_sleep = data[3];
		if (n_arg == 5)
			phil[p].number_of_times = data[4];
		else
			phil[p].number_of_times = -1;
		if (pthread_mutex_init(&phil[p].m_s_th, NULL) != 0)
			return ;
		if (pthread_mutex_init(&phil[p].m_l_eat, NULL) != 0)
			return ;
		p++;
	}
}

//Creamos el array de filosofos segun el numero introducido en args[0]
t_philosopher	*ft_create_philosophers(int n_philosophers)
{
	t_philosopher	*philosophers;
	int				n;

	n = 0;
	philosophers = malloc (n_philosophers * sizeof(*philosophers));
	if (!philosophers)
		return (NULL);
	while (n < n_philosophers)
	{
		philosophers[n].index_philosopher = -1;
		philosophers[n].time_to_die = -1;
		philosophers[n].time_to_eat = -1;
		philosophers[n].time_to_sleep = -1;
		philosophers[n].number_of_times = -1;
		philosophers[n].last_eating = -1;
		philosophers[n].start_thread = -1;
		philosophers[n].number_exit = 0;
		n++;
	}
	return (philosophers);
}

pthread_t	*ft_create_threads(int n_philosophers)
{
	pthread_t	*threads;

	threads = malloc (n_philosophers * sizeof (*threads));
	if (!threads)
		return (NULL);
	return (threads);
}

void	ft_initialize_threads(t_all *data)
{
	int	n;//

	n = 0;//
	while (n < data->total_philosophers)//
	{//
		if (pthread_mutex_lock(&data->m_active) != 0)//
			return ;//
		data->active = n;//
		if (pthread_mutex_unlock(&data->m_active) != 0)//
			return ;//
		if (pthread_create(&data->threads[n], NULL, philosopher, data) != 0)//
			return ;//
		usleep(1000);//
		n++;//
	}
	n = 0;
	if (pthread_join(data->t_alive, NULL) != 0)
		return ;
	while (n < data->total_philosophers)
	{
		if (pthread_join(data->threads[n], NULL) != 0)
			return ;
		n++;
	}
}

void	ft_destroy_forks(int n_philosophers, t_fork *forks)
{
	int	n;

	n = 0;
	while (n < n_philosophers)
	{
		if (pthread_mutex_destroy(&forks[n].fork_mutex) != 0)
			return ;
		n++;
	}
}

t_fork	*ft_create_forks(int n_philosophers)
{
	t_fork	*forks;
	int		n;

	n = 0;
	forks = malloc (n_philosophers * sizeof (*forks));
	if (!forks)
		return (NULL);
	while (n < n_philosophers)
	{
		forks[n].using = 0;
		if (pthread_mutex_init(&forks[n].fork_mutex, NULL) != 0)
			return (NULL);
		n++;
	}
	return (forks);
}

void	ft_p_message(t_all *data, long int time, int phil, char *m)
{
	ft_print_number(time);
	write(1, " ", 1);
	ft_print_number(data->phi[phil].index_philosopher);
	write(1, " ", 1);
	write(1, m, ft_strlen(m));
	write(1, "\n", 1);
}

void	ft_initialize_data_all_alive(t_data_all_alive *d)
{
	d->n = 0;
	d->time = -1;
	d->time_start = -1;
	d->start_thread = -1;
	d->l_eating = -1;
	d->time_to_die = -1;
	d->total_exit = -1;
}

void	*ft_all_alive(void *arg)
{
	t_all				*data; //
	t_data_all_alive	d; //

	data = (t_all *) arg; //
	ft_initialize_data_all_alive(&d); //
	d.n = 0; //
	d.time = 0; //
	ft_get_total_exit(data, &d.total_exit); //
	while (data->all_alive == 1 && d.total_exit < data->total_philosophers) //
	{ //
		while (d.n < data->total_philosophers && data->all_alive == 1) //
		{ //
			if (pthread_mutex_lock(&data->phi[d.n].m_s_th) != 0) //
				return (NULL); //
			d.start_thread = data->phi[d.n].start_thread; //
			if (pthread_mutex_unlock(&data->phi[d.n].m_s_th) != 0) //
				return (NULL); //
			if (d.start_thread != -1) //
			{ //
				if (pthread_mutex_lock(&data->phi[d.n].m_l_eat) != 0) //
					return (NULL); //
				d.l_eating = data->phi[d.n].last_eating; //
				if (pthread_mutex_unlock(&data->phi[d.n].m_l_eat) != 0) //
					return (NULL); //
				if (d.l_eating == -1) //
					d.time_start = data->phi[d.n].start_thread; //
				else //
				{ //
					if (pthread_mutex_lock(&data->phi[d.n].m_l_eat) != 0) //
						return (NULL); //
					d.time_start = data->phi[d.n].last_eating; //
					if (pthread_mutex_unlock(&data->phi[d.n].m_l_eat) != 0) //
						return (NULL); //
				} //
				d.time = ft_get_time(); //
				if (pthread_mutex_lock(&data->m_erase_all) != 0) //
					return (NULL); // 
				d.time_to_die = data->phi[d.n].time_to_die; //
				if (pthread_mutex_unlock(&data->m_erase_all) != 0) //
					return (NULL); //
				if ((d.time - d.time_start) >= d.time_to_die) //
				{ //
					if (data->phi[d.n].number_exit == 0) //
					{ //
						if (pthread_mutex_lock(&data->m_a_alive) != 0) //
							return (NULL); //
						data->all_alive = 0; //
						if (pthread_mutex_unlock(&data->m_a_alive) != 0) //
							return (NULL); //
						if (pthread_mutex_lock(&data->m_message) != 0) //
							return (NULL); // 
						ft_p_message(data, d.time, d.n, " died"); //
						if (pthread_mutex_unlock(&data->m_message) != 0) //
							return (NULL); //
					} //
				} //
			} //
			d.n++; //
		} //
		d.n = 0; //
		usleep(1000); //
		ft_get_total_exit(data, &d.total_exit); //
	}
	return (NULL);
}

void	ft_destroy_mutexs(t_all *data)
{
	if (pthread_mutex_destroy(&data->m_a_alive) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_active) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_message) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_read_forks) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_total_exit) != 0)
		return ;
	if (pthread_mutex_destroy(&data->m_erase_all) != 0)
		return ;
}

void	ft_fill_t_all(t_all *data, long int *args, int n_arg)
{
	if (pthread_mutex_init(&data->m_a_alive, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_active, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_message, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_read_forks, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_erase_all, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_total_exit, NULL) != 0)
		return ;
	data->total_philosophers = args[0];
	data->phi = ft_create_philosophers(args[0]);
	ft_fill_data(data->phi, args, n_arg);
	data->forks = ft_create_forks(args[0]);
	data->all_alive = 1;
	data->threads = ft_create_threads(args[0]);
	data->total_exit = 0;
	if (pthread_create(&data->t_alive, NULL, ft_all_alive, data) != 0)
		return ;
	ft_initialize_threads(data);
}

int	ft_check_only_numbers(int argc, char **argv)
{
	int	arg;
	int	letter;
	int	check;

	arg = 1;
	letter = 0;
	check = 1;
	while (arg < argc && check == 1)
	{
		while (letter < ft_strlen(argv[arg]) && check == 1)
		{
			if (argv[arg][letter] < 48 || argv[arg][letter] > 57)
				check = 0;
			letter++;
		}
		letter = 0;
		arg++;
	}
	return (check);
}

int	ft_check_limits(long int *args, int n_args)
{
	int	n;
	int	check;

	n = 0;
	check = 1;
	while (n < n_args && check == 1)
	{
		if (args[n] > 2147483647)
			check = 0;
		n++;
	}
	return (check);
}

int	ft_check_args(int argc, char **argv)
{
	long int	*args;

	if (ft_check_only_numbers(argc, argv) != 1)
		return (-1);
	args = ft_get_args(argc, argv);
	if (ft_check_limits(args, argc - 1) != 1)
		return (free (args), -1);
	if (args[0] <= 0)
		return (free (args), -1);
	if (argc == 6 && args[4] <= 0)
		return (free (args), -1);
	free (args);
	return (1);
}

void	ft_free_all(t_all *data)
{
	if (pthread_mutex_lock(&data->m_erase_all) != 0)
		return ;
	free (data->phi);
	free (data->forks);
	free (data->threads);
	if (pthread_mutex_unlock(&data->m_erase_all) != 0)
		return ;
}

int	main(int argc, char **argv)
{
	long int	*args;
	t_all		all_phi;

	if (argc == 5 || argc == 6)
	{
		if (ft_check_args(argc, argv) == 1)
		{
			args = ft_get_args(argc, argv);
			ft_fill_t_all(&all_phi, args, argc - 1);
			ft_destroy_forks(all_phi.total_philosophers, all_phi.forks);
			free(args);
			ft_destroy_local_mutex(&all_phi);
			ft_free_all(&all_phi);
			ft_destroy_mutexs(&all_phi);
		}
		else
			printf("ARGUMENTO INVALIDO\n");
	}
	return (0);
}