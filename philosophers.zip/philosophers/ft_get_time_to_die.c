/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_time_to_die.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:50:49 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:52:04 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_g_t_t_die(t_all *data, t_d_a_alive *d)
{
	if (pthread_mutex_lock(&data->m_erase_all) != 0)
		return ;
	d->time_to_die = data->phi[d->n].time_to_die;
	if (pthread_mutex_unlock(&data->m_erase_all) != 0)
		return ;
}
