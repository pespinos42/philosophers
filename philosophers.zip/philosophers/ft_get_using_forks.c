/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_using_forks.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:50:53 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:52:07 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_get_using_forks(t_all *data, int fork, int *u_fork)
{
	if (pthread_mutex_lock(&data->m_read_forks) != 0)
		return ;
	*u_fork = data->forks[fork].using;
	if (pthread_mutex_unlock(&data->m_read_forks) != 0)
		return ;
}
