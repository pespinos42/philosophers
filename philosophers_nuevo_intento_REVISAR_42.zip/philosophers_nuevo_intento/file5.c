#include "philosophers.h"

void	ft_lock_fork(t_fork *forks, int n_fork)
{
	if (pthread_mutex_lock(&forks[n_fork].m_u_f) != 0)
		return ;
}

void	ft_unlock_fork(t_fork *forks, int n_fork)
{
	if (pthread_mutex_unlock(&forks[n_fork].m_u_f) != 0)
		return ;
}

void	ft_init_mutex_forks(t_fork *forks, int n_forks)
{
	int	n;

	n = 0;
	while (n < n_forks)
	{
		if (pthread_mutex_init(&forks[n].m_u_f, NULL) != 0)
			return ;
		n++;
	}
}

void	ft_destroy_mutex_forks(t_fork *forks, int n_forks)
{
	int	n;

	n = 0;
	while (n < n_forks)
	{
		if (pthread_mutex_destroy(&forks[n].m_u_f) != 0)
			return ;
		n++;
	}
}

//---------------------FIN FORKS.C------------------------

//----------------------------------ALL.C---------------------------
int	ft_get_active(t_all *data)
{
	int	active;

	active = -1;
	if (pthread_mutex_lock(&data->mutex_active) != 0)
		return (-1);
	active = data->active;
	if (pthread_mutex_unlock(&data->mutex_active) != 0)
		return (-1);
	return (active);
}
