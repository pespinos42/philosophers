#include "philosophers.h"

int ft_get_total_philosophers(t_all *data)
{
    int total_philosophers;

    total_philosophers = -1;
    if (pthread_mutex_lock(&data->mutex_total_philosophers) != 0)
        return (-1);
    total_philosophers = data->total_philosophers;
    if (pthread_mutex_unlock(&data->mutex_total_philosophers) != 0)
        return (-1);
    return (total_philosophers);
}

void    ft_set_total_philosophers(t_all *data, int value)
{
    if (pthread_Mutex_lock(&data->mutex_total_philosophers) != 0)
        return ;
    data->total_philosophers = value;
    if (pthread_mutex_unlock(&data->mutex_total_philosophers) != 0)
        return ;
}

int ft_get_active(t_all *data)
{
    int active;

    active = -1;
    if (pthread_mutex_lock(&data->mutex_active) != 0)
        return (-1);
    active = data->active;
    if (pthread_mutex_unlock(&data->mutex_active) != 0)
        return (-1);
    return (active);
}

void    ft_set_active(t_all *data, int value)
{
    if (pthread_mutex_lock(&data->mutex_active) != 0)
        return ;
    data->active = value;
    if (pthread_mutex_unlock(&data->mutex_active) != 0)
        return ;
}

int ft_get_all_alive(t_all *data)
{
    int all_alive;

    all_alive = -1;
    if (pthread_mutex_lock(&data->mutex_all_alive) != 0)
        return (-1);
    all_alive = data->all_alive;
    if (pthread_mutex_unlock(&data->mutex_all_alive) != 0)
        return (-1);
    return (all_alive);
}

void    ft_set_all_alive(t_all *data, int value)
{
    if (pthread_mutex_lock(&data->mutex_all_alive) != 0)
        return ;
    data->all_alive = value;
    if (pthread_mutex_unlock(&data->mutex_all_alive) != 0)
        return ;
}

int ft_get_total_exit(t_all *data)
{
    int total_exit;

    total_exit = -1;
    if (pthread_mutex_lock(&data->mutex_total_exit) != 0)
        return (-1);
    total_exit = data->total_exit;
    if (pthread_mutex_unlock(&data->mutex_total_exit) != 0)
        return (-1);
    return (total_exit);
}

void    ft_set_total_exit(t_all *data, int value)
{
    if (pthread_mutex_lock(&data->mutex_total_exit) != 0)
        return ;
    data->total_exit = value;
    if (pthread_mutex_unlock(&data->mutex_total_exit) != 0)
        return ;
}