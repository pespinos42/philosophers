#include "philosophers.h"

int ft_get_index_philosopher(t_philosopher *philo)
{
    int index_philosopher;

    index_philosopher = -1;
    if (pthread_mutex_lock(&philo->mutex_index_philosopher) != 0)
        return (-1);
    index_philosopher = philo->index_philosopher;
    if (pthread_mutex_unlock(&philo->mutex_index_philosopher) != 0)
        return (-1);
    return (index_philosopher);
}

void    ft_set_index_philosopher(t_philosopher *philo, int value)
{
    if (pthread_mutex_lock(&philo->mutex_index_philosopher) != 0)
        return ;
    philo->index_philosopher = value;
    if (pthread_mutex_unlock(&philo->mutex_index_philosopher) != 0)
        return ;
}

long int    ft_get_time_to_die(t_philosopher *philo)
{
    long int    time_to_die;

    time_to_die = -1;
    if (pthread_mutex_lock(&philo->mutex_time_to_die) != 0)
        return (-1);
    time_to_die = philo->time_to_die;
    if (pthread_mutex_unlock(&philo->mutex_time_to_die) != 0)
        return (-1);
    return (time_to_die);
}

void    ft_set_time_to_die(t_philosopher *philo, long int value)
{
    if (pthread_mutex_lock(&philo->mutex_time_to_die) != 0)
        return ;
    philo->time_to_die = value;
    if (pthread_mutex_unlock(&philo->mutex_time_to_die) != 0)
        return ;
}

long int    ft_get_time_to_eat(t_philosopher *philo)
{
    long int    time_to_eat;

    time_to_eat = -1;
    if (pthread_mutex_lock(&philo->mutex_time_to_eat) != 0)
        return (-1);
    time_to_eat = philo->time_to_eat;
    if (pthread_mutex_unlock(&philo->mutex_time_to_eat) != 0)
        return (-1);
    return (time_to_eat);
}

void    ft_set_time_to_eat(t_philosopher *philo, long int value)
{
    if (pthread_mutex_lock(&philo->mutex_time_to_eat) != 0)
        return ;
    philo->time_to_eat = value;
    if (pthread_mutex_unlock(&philo->mutex_time_to_eat) != 0)
        return ;
}

long int    ft_get_time_to_sleep(t_philosopher *philo)
{
    long int    time_to_sleep;

    time_to_sleep = -1;
    if (pthread_mutex_lock(&philo->mutex_time_to_sleep) != 0)
        return (-1);
    time_to_sleep = philo->time_to_sleep;
    if (pthread_mutex_unlock(&philo->mutex_time_to_sleep) != 0)
        return (-1);
    return (time_to_sleep);
}

void    ft_set_time_to_sleep(t_philosopher *philo, long int value)
{
    if (pthread_mutex_lock(&philo->mutex_time_to_sleep) != 0)
        return ;
    philo->time_to_sleep = value;
    if (pthread_mutex_unlock(&philo->mutex_time_to_sleep) != 0)
        return ;
}

int ft_get_number_of_times(t_philosopher *philo)
{
    int number_of_times;

    number_of_times = -1;
    if (pthread_mutex_lock(&philo->mutex_number_of_times) != 0)
        return (-1);
    number_of_times = philo->number_of_times;
    if (pthread_mutex_unlock(&philo->mutex_number_of_times) != 0)
        return (-1);
    return (number_of_times);
}

void    ft_set_number_of_times(t_philosopher *philo, int value)
{
    if (pthread_mutex_lock(&philo->mutex_number_of_times) != 0)
        return ;
    philo->number_of_times = value;
    if (pthread_mutex_unlock(&philo->mutex_number_of_times) != 0)
        return ;
}

long int    ft_get_last_eating(t_philosopher *philo)
{
    long int    last_eating;

    last_eating = -1;
    if (pthread_mutex_lock(&philo->mutex_last_eating) != 0)
        return (-1);
    last_eating = philo->last_eating;
    if (pthread_mutex_unlock(&philo->mutex_last_eating) != 0)
        return (-1);
    return (last_eating);
}

void    ft_set_last_eating(t_philosopher *philo, long int value)
{
    if (pthread_mutex_lock(&philo->mutex_last_eating) != 0)
        return ;
    philo->last_eating = value;
    if (pthread_mutex_unlock(&philo->mutex_last_eating) != 0)
        return ;
}

int ft_get_number_exit(t_philosopher *philo)
{
    int number_exit;

    number_exit = -1;
    if (pthread_mutex_lock(&philo->mutex_number_exit) != 0)
        return (-1);
    number_exit = philo->number_exit;
    if (pthread_mutex_unlock(&philo->mutex_number_exit) != 0)
        return (-1);
    return (number_exit);
}

void    ft_set_number_exit(t_philosopher *philo, int value)
{
    if (pthread_mutex_lock(&philo->mutex_number_exit) != 0)
        return ;
    philo->number_exit = value;
    if (pthread_mutex_unlock(&philo->mutex_number_exit) != 0)
        return ;
}

long int    ft_get_start_thread(t_philosopher *philo)
{
    long int    start_thread;

    start_thread = -1;
    if (pthread_mutex_lock(&philo->mutex_start_thread) != 0)
        return (-1);
    start_thread = philo->start_thread;
    if (pthread_mutex_unlock(&philo->mutex_start_thread) != 0)
        return (-1);
    return (start_thread);
}

void    ft_set_start_thread(t_philosopher *philo, long int value)
{
    if (pthread_mutex_lock(&philo->mutex_start_thread) != 0)
        return ;
    philo->start_thread = value;
    if (pthread_mutex_unlock(&philo->mutex_start_thread) != 0)
        return ;
}

void    ft_init_mutexs_philosophers(t_all *data)
{
    int total_philosophers;
    int n;

    total_philosophers = ft_get_total_philosophers(data);
    n = 0;
    while (n < total_philosophers)
    {
        if (pthread_mutex_init(&data->phi[n].mutex_index_philosopher, NULL) != 0)
            return ;
        if (pthread_mutex_init(&data->phi[n].mutex_time_to_die, NULL) != 0)
            return ;
        if (pthread_mutex_init(&data->phi[n].mutex_time_to_eat, NULL) != 0)
            return ;
        if (pthread_mutex_init(&data->phi[n].mutex_time_to_sleep, NULL) != 0)
            return ;
        if (pthread_mutex_init(&data->phi[n].mutex_number_of_times, NULL) != 0)
            return ;
        if (pthread_mutex_init(&data->phi[n].mutex_last_eating, NULL) != 0)
            return ;
        if (pthread_mutex_init(&data->phi[n].mutex_number_exit, NULL) != 0)
            return ;
        if (pthread_mutex_init(&data->phi[n].mutex_start_thread, NULL) != 0)
            return ;
        n++;        
    }
}

void    ft_destroy_mutex_philosophers(t_all *data)
{
    int total_philosophers;
    int n;

    total_philosophers = ft_get_total_philosophers(data);
    n = 0;
    while (n < total_philosophers)
    {
        if (pthread_mutex_destroy(&data->phi[n].mutex_index_philosopher) != 0)
            return ;
        if (pthread_mutex_destroy(&data->phi[n].mutex_time_to_die) != 0)
            return ;
        if (pthread_mutex_destroy(&data->phi[n].mutex_time_to_eat) != 0)
            return ;
        if (pthread_mutex_destroy(&data->phi[n].mutex_time_to_sleep) != 0)
            return ;
        if (pthread_mutex_destroy(&data->phi[n].mutex_number_of_times) != 0)
            return ;
        if (pthread_mutex_destroy(&data->phi[n].mutex_last_eating) != 0)
            return ;
        if (pthread_mutex_destroy(&data->phi[n].mutex_number_exit) != 0)
            return ;
        if (pthread_mutex_destroy(&data->phi[n].mutex_start_thread) != 0)
            return ;
        n++;        
    }
}

void    ft_initialize_data_philosophers(t_all *data, long int *args, int n_args)
{
    int total_philosophers;
    int n;

    total_philosophers = -1;
    n = 0;
    total_philosophers = ft_get_total_philosophers(data);
    while (n < total_philosophers)
    {
        ft_set_index_philosopher(&data->phi[n], n + 1);
        ft_set_time_to_die(&data->phi[n], args[1]);
        ft_set_time_to_eat(&data->phi[n], args[2]);
        ft_set_time_to_sleep(&data->phi[n], args[3]);
        if (n_args == 5)
            ft_set_number_of_times(&data->phi[n], args[4]);
        ft_set_last_eating(&data->phi[n], -1);
        ft_set_number_exit(&data->phi[n], -1);
        ft_set_start_thread(&data->phi[n], -1);
        n++;
    }
}

t_philosopher   *ft_create_philosophers(int n_philosophers)
{
    t_philosopher   *philosophers;

    philosophers = malloc (n_philosophers * sizeof (*philosophers));
    if (!philosophers)
        return (NULL);
    return (philosophers);
}

void    ft_initialize_data_phi(t_data_philosopher *d)
{
    d->active = -1;
    d->fork_right = -1;
    d->fork_left = -1;
    d->time = -1;
    d->s_time = -1;
    d->n_times = 0;
    d->using_fork_right = -1;
    d->using_fork_left = -1;
    d->a_alive = -1;
    d->total_n_times = -1;
}

long int	ft_get_stop_time(t_all *data, int active)
{
    long int    stop_time;
	long int	time_to_die;
	long int	last_eating;
	long int	time_to_eat;
	long int	time;

	time_to_die = ft_get_time_to_die(&data->phi[active]);
	last_eating = ft_get_time_to_eat(&data->phi[active]);
	time_to_eat = ft_get_time_to_eat(&data->phi[active]);
	time = ft_get_time();
	stop_time = (time_to_die - ((time - last_eating) + time_to_eat)) / 2;
	if (stop_time > 500)
		stop_time = 500;
    return (stop_time);
}

void	ft_increment_total_exit(t_all *data)
{
	if (pthread_mutex_lock(&data->mutex_total_exit) != 0)
		return ;
	data->total_exit = data->total_exit + 1;
	if (pthread_mutex_unlock(&data->mutex_total_exit) != 0)
		return ;
}

void    *ft_philosopher(void *arg)
{
    t_all               *data;
    t_data_philosopher  d;

    data = (t_all *) arg;
    ft_initialize_data_phi(&d);
    d.active = ft_get_active(data);
    d.total_n_times = ft_get_number_of_times(&data->phi[d.active]);
    d.fork_right = d.active;
    if (d.active == ft_get_total_philosophers(data) - 1)
        d.fork_left = 0;
    else
        d.fork_left = d.active + 1;
    ft_set_start_thread(&data->phi[d.active], ft_get_time());
    if (ft_get_time_to_die(&data->phi[d.active]) > 0 && ft_get_total_philosophers(data) > 1)
    {
        d.a_alive = ft_get_all_alive(data);
        while (d.a_alive == 1 && ft_get_number_exit(&data->phi[d.active]) == 0)
        {
            d.a_alive = ft_get_all_alive(data);
            if (d.a_alive == 1)
            {
                ft_lock_fork(data, d.fork_right);
                ft_lock_fork(data, d.fork_left);
                ft_p_message(data, ft_get_time(), d.active, " is eating");
                ft_set_last_eating(&data->phi[d.active], ft_get_time());
                ft_unlock_fork(data, d.fork_left);
                ft_unlock_fork(data, d.fork_right);
                d.n_times++;
            }
            if (d.total_n_times != -1 && d.n_times >= d.total_n_times)
                ft_set_number_exit(&data->phi[d.active], 1);
            if (ft_get_number_exit(&data->phi[d.active]) == 0)
            {
                d.a_alive = ft_get_all_alive(data);
                if (d.a_alive == 1)
                {
                    ft_p_message(data, ft_get_time(), d.active, " is sleeping");
                    d.time = ft_get_time();
                    d.s_time = d.time + ft_get_time_to_sleep(&data->phi[d.active]);
                    d.a_alive = ft_get_all_alive(data);
                    while (ft_get_time() < d.s_time && d.a_alive == 1)
                    {
                        usleep(1000);
                        d.a_alive = ft_get_all_alive(data);
                    }
                }
                d.a_alive = ft_get_all_alive(data);
                if (d.a_alive == 1)
                {
                    d.s_time = ft_get_stop_time(data, d.active);
                    if (d.s_time > 0)
                    {
                        d.a_alive = ft_get_all_alive(data);
                        if (d.a_alive == 1)
                            ft_p_message(data, ft_get_time(), d.active, " is thinking");
                        if (d.s_time > 100)
                        {
                            d.s_time += ft_get_time();
                            while (ft_get_time() < d.s_time && d.a_alive == 1)
                            {
                                d.a_alive = ft_get_all_alive(data);
                                usleep(1000);
                            }
                        }
                    }
                }
                d.s_time = 0;
            }
        }
    }
    ft_increment_total_exit(data);
    return (NULL);
}