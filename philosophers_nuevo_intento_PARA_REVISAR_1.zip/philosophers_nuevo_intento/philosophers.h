/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philosophers.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/25 13:00:15 by pespinos          #+#    #+#             */
/*   Updated: 2023/06/25 13:00:15 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILOSOPHERS_H
# define PHILOSOPHERS_H
# include <unistd.h>
# include <limits.h>
# include <stdlib.h>
# include <stdio.h>
# include <pthread.h>
# include <sys/time.h>

typedef struct s_temp
{
	long int	time_to_die;
	long int	time_to_eat;
	long int	l_e;
	long int	s_t;
	int			n_e;
	int			active;
}	t_temp;

/*
	pthread_mutex_t	mutex_using_fork;
	PASA A SER
	pthread_mutex_t	m_u_f;
*/
typedef struct s_fork
{
	pthread_mutex_t	m_u_f;
}	t_fork;

/*
	int				index_philosopher;
	PASA A SER
	int				i_p;

	pthread_mutex_t	mutex_index_philosopher;
	PASA A SER
	pthread_mutex_t m_i_p;

	long int		last_eating;
	PASA A SER
	long int		l_e;

	pthread_mutex_t	mutex_last_eating;
	PASA A SER
	pthread_mutex_t	m_l_e;

	int				number_eated;
	PASA A SER
	int				n_e;

	pthread_mutex_t	mutex_number_eated;
	PASA A SER
	pthread_mutex_t	m_n_e;

	int				fork_left;
	PASA A SER
	int				f_l;

	pthread_mutex_t	mutex_fork_left;
	PASA A SER
	pthread_mutex_t	m_f_l;

	int				fork_right;
	PASA A SER
	int				f_r;

	pthread_mutex_t	mutex_fork_right;
	PASA A SER
	pthread_mutex_t	m_f_r;

	long int		stop_time;
	PASA A SER
	long int		s_t;

	pthread_mutex_t	mutex_stop_time;
	PASA A SER
	pthread_mutex_t	m_s_t;

	long int		start_thread;
	PASA A SER
	long int		s_th;

	pthread_mutex_t	mutex_start_thread;
	PASA A SER
	pthread_mutex_t	m_s_t;

	int				exit_yet;
	PASA A SER
	int				e_y;

	pthread_mutex_t	mutex_exit_yet;
	PASA A SER
	pthread_mutex_t	m_e_y;
*/
typedef struct s_data_philosopher
{
	int				i_p;
	pthread_mutex_t	m_i_p;
	long int		l_e;
	pthread_mutex_t	m_l_e;
	int				n_e;
	pthread_mutex_t	m_n_e;
	int				f_l;
	pthread_mutex_t	m_f_l;
	int				f_r;
	pthread_mutex_t	m_f_r;
	long int		s_t;
	pthread_mutex_t	m_s_t;
	long int		s_th;
	pthread_mutex_t	m_s_th;
	int				e_y;
	pthread_mutex_t	m_e_y;
}	t_data_philosopher;

/*
	int			n;
	
	long int	time;
	PASA A SER
	long int	t;

	long int	time_start;
	PASA A SER
	long int	t_s;

	long int	start_thread;
	PASA A SER
	long int	s_th;

	long int	last_eating;
	PASA A SER
	long int	l_e;

	long int	time_to_die;
	PASA A SER
	long int	t_t_d;

	int			total_exit;
	PASA A SER
	int			t_e;
*/
typedef struct s_data_all_alive
{
	int			n;
	long int	time;
	long int	time_start;
	long int	s_th;
	long int	l_e;
	long int	t_t_d;
	int			t_e;
}	t_data_all_alive;

/*
	int					number_philosophers;
	PASA A SER
	int					n_p;

	pthread_mutex_t		mutex_number_philosophers;
	PASA A SER
	pthread_mutex_t		m_n_p;

	int					all_alive;
	PASA A SER
	int					a_a;

	pthread_mutex_t		mutex_all_alive;
	PASA A SER
	pthread_mutex_t		m_a_a;

	long int			time_to_die;
	PASA A SER
	long int			t_t_d;

	pthread_mutex_t		mutex_time_to_die;
	PASA A SER
	pthread_mutex_t		m_t_t_d;

	long int			time_to_eat;
	PASA A SER
	long int			t_t_e;

	pthread_mutex_t		mutex_time_to_eat;
	PASA A SER
	pthread_mutex_t		m_t_t_e;

	long int			time_to_sleep;
	PASA A SER
	long int			t_t_s;

	pthread_mutex_t		mutex_time_to_sleep;
	PASA A SER
	ptrhead_mutex_t		m_t_t_s;

	int					number_of_times_eat;
	PASA A SER
	int					n_o_t_e;

	pthread_mutex_t		mutex_number_of_times_eat;
	PASA A SER
	pthread_mutex_t		m_n_o_t_e;

	int					active;
	PASA A SER
	int					a;

	pthread_mutex_t		mutex_active;
	PASA A SER
	pthread_mutex_t		m_a;

	t_fork				*forks;

	t_data_philosopher	*data_philosophers;
	PASA A SER
	t_data_philosopher	d_p;

	pthread_mutex_t		mutex_philosophers_eating;
	PASA A SER
	pthread_mutex_t		m_p_e;

	int					total_exit;
	PASA A SER
	int					t_e;

	pthread_mutex_t		mutex_total_exit;
	PASA A SER
	pthread_mutex_t		m_t_e;

	int					all_out;
	PASA A SER
	int					a_o;

	pthread_mutex_t		mutex_all_out;
	PASA A SER
	pthread_mutex_t		m_a_o;

	pthread_t			*threads;

	pthread_t			thread_all_alive;
	PASA A SER
	pthread_t			t_a_a;

	pthread_mutex_t		mutex_message;
	PASA A SER
	pthread_mutex_t		m_m;
*/
typedef struct s_all
{
	int					n_p;
	pthread_mutex_t		m_n_p;
	int					a_a;
	pthread_mutex_t		m_a_a;
	long int			t_t_d;
	pthread_mutex_t		m_t_t_d;
	long int			t_t_e;
	pthread_mutex_t		m_t_t_e;
	long int			t_t_s;
	pthread_mutex_t		m_t_t_s;
	int					n_o_t_e;
	pthread_mutex_t		m_n_o_t_e;
	int					active;
	pthread_mutex_t		mutex_active;
	t_fork				*forks;
	t_data_philosopher	*d_p;
	int					t_e;
	pthread_mutex_t		m_t_e;
	int					a_o;
	pthread_mutex_t		m_a_o;
	pthread_t			*threads;
	pthread_t			t_a_a;
	pthread_mutex_t		m_m;
}	t_all;

typedef struct s_atoi
{
	long int	result;
	int			s;
	int			sign;
}	t_atoi;

//DATA_FILOSOFOS.C
//void				ft_init_mutex_data_philosopher(t_data_philosopher *data_philosopher, int n_philosopher);
void				ft_i_m_d_p(t_data_philosopher *d_p, int n_p);
//void				ft_destroy_mutex_data_philosopher(t_data_philosopher *data_philosopher, int n_philosophers);
void				ft_d_m_d_p(t_data_philosopher *d_p, int n_p);
int					ft_get_i_p(t_data_philosopher *d_p);
void				ft_set_i_p(t_data_philosopher *d_p, int value);
long int			ft_get_l_e(t_data_philosopher *d_p);
void				ft_set_l_e(t_data_philosopher *d_p, long int value);
int					ft_get_f_l(t_data_philosopher *d_p);
void				ft_set_f_l(t_data_philosopher *d_p, int value);
int					ft_get_f_r(t_data_philosopher *d_p);
void				ft_set_f_r(t_data_philosopher *d_p, int value);
int					ft_get_n_e(t_data_philosopher *d_p);
void				ft_set_n_e(t_data_philosopher *d_p, int value);
long int			ft_get_s_t(t_data_philosopher *d_p);
void				ft_set_s_t(t_data_philosopher *d_p, long int value);
long int			ft_get_s_th(t_data_philosopher *d_p);
void				ft_set_s_th(t_data_philosopher *d_p, long int value);
int					ft_get_e_y(t_data_philosopher *d_p);
void				ft_set_e_y(t_data_philosopher *d_p, int value);
t_data_philosopher	*ft_create_data_philosophers(t_all *data);

//FORKS
t_fork				*ft_create_forks(int n_forks);
void				ft_lock_fork(t_fork *forks, int n_fork);
void				ft_unlock_fork(t_fork *forks, int n_fork);
void				ft_init_mutex_forks(t_fork *forks, int n_forks);
void				ft_destroy_mutex_forks(t_fork *forks, int n_forks);

//T_ALL
int					ft_get_active(t_all *data);
void				ft_set_active(t_all *data, int value);
int					ft_get_n_p(t_all *data);
void				ft_set_n_p(t_all *data, int value);
long int			ft_get_t_to_die(t_all *data);
void				ft_set_time_to_die(t_all *data, long int value);
long int			ft_get_t_to_eat(t_all *data);
void				ft_set_time_to_eat(t_all *data, long int value);
long int			ft_get_t_to_sleep(t_all *data);
void				ft_set_time_to_sleep(t_all *data, long int value);
int					ft_get_number_of_times_eat(t_all *data);
void				ft_set_number_of_times_eat(t_all *data, int value);
void				ft_set_all_out(t_all *data, int value);
int					ft_get_all_out(t_all *data);
int					ft_get_a_a(t_all *data);
void				ft_set_all_alive(t_all *data, int value);
int					ft_get_total_exit(t_all *data);
void				ft_set_total_exit(t_all *data, int value);
void				ft_init_mutex_data(t_all *data);
void				ft_destroy_mutex_data(t_all *data);

//ATOI
void				ft_initialize_data_atoi(t_atoi *d);
long int			ft_atoi(char *str);

//ARGS
int					ft_strlen(char *str);
long int			*ft_get_args(int argc, char **argv);
int					ft_check_only_numbers(int argc, char **argv);
int					ft_check_limits(long int *args, int n_args);
int					ft_check_args(int argc, char **argv);

//MAIN
void				ft_p_m(t_all *data, long int time, int p, char *message);
void				ft_wait(t_all *data, long int time_to_wait);
void				ft_data_philosopher(t_temp *temp);
void				*ft_philosopher(void *arg);
void				ft_initialize_data_all_alive(t_data_all_alive *d_a_a);
void				*ft_all_alive(void *arg);
pthread_t			*ft_create_threads(t_all *data);
void				ft_initialize_threads(t_all *data);
void				ft_s_ths(t_all *data);
void				ft_fill_data(t_all *data, long int *args, int argc);
void				ft_print_number(long int n);
long int			ft_get_t(void);
void				ft_clean_all(t_all *data, long int *args);
int					main(int argc, char **argv);

#endif
