#include "philosophers.h"

void	ft_get_active(t_all *data, int *active)
{
	if (pthread_mutex_lock(&data->m_active) != 0)
		return ;
	*active = data->active;
	if (pthread_mutex_unlock(&data->m_active) != 0)
		return ;
}