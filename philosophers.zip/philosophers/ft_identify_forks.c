#include "philosophers.h"

void	ft_identify_forks(t_all *data, t_data_philosopher *d)
{
	d->fork_right = d->active;
	if (d->active == data->total_philosophers - 1)
		d->fork_left = 0;
	else
		d->fork_left = d->fork_right + 1;
}