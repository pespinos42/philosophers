#ifndef PHILOSOPHERS_H
# define PHILOSOPHERS_H
# include <unistd.h>
# include <limits.h>
# include <stdlib.h>
# include <stdio.h>
# include <pthread.h>
# include <sys/time.h>

typedef struct s_fork
{
	//int				using_fork;
	pthread_mutex_t	mutex_using_fork;
}	t_fork;

typedef struct s_data_philosopher
{
	int				index_philosopher;
	pthread_mutex_t	mutex_index_philosopher;
	long int		last_eating;
	pthread_mutex_t	mutex_last_eating;
	int				number_eated;
	pthread_mutex_t	mutex_number_eated;
	int             fork_left;
	pthread_mutex_t mutex_fork_left;
	int             fork_right;
	pthread_mutex_t mutex_fork_right;
	long int		stop_time;
	pthread_mutex_t	mutex_stop_time;
	long int		start_thread;
	pthread_mutex_t	mutex_start_thread;
	int				exit_yet;
	pthread_mutex_t	mutex_exit_yet;
}	t_data_philosopher;

typedef struct s_data_all_alive
{
	int			n;
	long int	time;
	long int	time_start;
	long int	start_thread;
	long int	l_eating;
	long int	time_to_die;
	int			total_exit;
}	t_data_all_alive;

typedef struct s_all
{
	int             number_philosophers;
	pthread_mutex_t mutex_number_philosophers;
	int				all_alive;
	pthread_mutex_t	mutex_all_alive;
	long int        time_to_die;
	pthread_mutex_t mutex_time_to_die;
	long int        time_to_eat;
	pthread_mutex_t mutex_time_to_eat;
	long int        time_to_sleep;
	pthread_mutex_t mutex_time_to_sleep;
	int             number_of_times_eat;
	pthread_mutex_t mutex_number_of_times_eat;
	int             active;
	pthread_mutex_t mutex_active;
	t_fork			*forks;
	//t_philosopher	*philosophers;
	int				*philosophers_eating;
	pthread_mutex_t	mutex_philosophers_eating;
	int				total_exit;
	pthread_mutex_t	mutex_total_exit;
	int				all_out;
	pthread_mutex_t	mutex_all_out;
	pthread_t		*threads;
	pthread_t		thread_all_alive;
	pthread_mutex_t	mutex_message;
}   t_all;

typedef struct s_atoi
{
	long int	result;
	int			s;
	int			sign;
}	t_atoi;


//DATA_FILOSOFOS.C
void		ft_init_mutex_data_philosopher(t_data_philosopher *data_philosopher);
void		ft_destroy_mutex_data_philosopher(t_data_philosopher *data_philosopher);
int			ft_get_index_philosopher(t_data_philosopher *data_philosopher);
void		ft_set_index_philosopher(t_data_philosopher *data_philosopher, int value);
long int	ft_get_last_eating(t_data_philosopher *data_philosopher);
void		ft_set_last_eating(t_data_philosopher *data_philosopher, long int value);
int			ft_get_fork_left(t_data_philosopher *data_philosopher);
void		ft_set_fork_left(t_data_philosopher *data_philosopher, int value);
int			ft_get_fork_right(t_data_philosopher *data_philosopher);
void		ft_set_fork_right(t_data_philosopher *data_philosopher, int value);
int			ft_get_number_eated(t_data_philosopher *data_philosopher);
void		ft_set_number_eated(t_data_philosopher *data_philosopher, int value);
long int	ft_get_stop_time(t_data_philosopher *data_philosopher);
void		ft_set_stop_time(t_data_philosopher *data_philosopher, long int value);


//FORKS.C
t_fork		*ft_create_forks(int n_forks);
void		ft_lock_fork(t_fork *forks, int n_fork);
void		ft_unlock_fork(t_fork *forks, int n_fork);
void		ft_init_mutex_forks(t_fork *forks, int n_forks);
void		ft_destroy_mutex_forks(t_fork *forks, int n_forks);


//ALL.C
int			ft_get_active(t_all *data);
void		ft_set_active(t_all *data, int value);
int			ft_get_number_philosophers(t_all *data);
void		ft_set_number_philosophers(t_all *data, int value);
long int	ft_get_time_to_die(t_all *data);
void		ft_set_time_to_die(t_all *data, long int value);
long int	ft_get_time_to_eat(t_all *data);
void		ft_set_time_to_eat(t_all *data, long int value);
long int	ft_get_time_to_sleep(t_all *data);
void		ft_set_time_to_sleep(t_all *data, long int value);
int			ft_get_number_of_times_eat(t_all *data);
void		ft_set_number_of_times_eat(t_all *data, int value);
void		ft_set_philosophers_eating(t_all *data, int position, int value);
int			ft_get_philosophers_eating(t_all *data, int position);
void		ft_set_all_out(t_all *data, int value);
int			ft_get_all_out(t_all *data);
int			ft_get_all_alive(t_all *data);
void		ft_set_all_alive(t_all *data, int value);
void		ft_init_mutex_data(t_all *data);
void		ft_destroy_mutex_data(t_all *data);


//ATOI.C
void		ft_initialize_data_atoi(t_atoi *d);
long int	ft_atoi(char *str);


//ARGS.c
int			ft_strlen(char *str);
long int	*ft_get_args(int argc, char **argv);
int			ft_check_only_numbers(int argc, char **argv);
int			ft_check_limits(long int *args, int n_args);
int			ft_check_args(int argc, char **argv);


//PARA BORRAR
void		ft_print_args(long int *args, int argc);
void		ft_print_data(t_all *data);
void		ft_print_philosophers_eating(int *philosophers_eating, int n_philosophers);


//MAIN.C
void		ft_print_message(t_all *data, long int time, int philosopher, char *message);
void		*ft_philosopher(void *arg);
void		*ft_all_alive(void *arg);
pthread_t	*ft_create_threads(t_all *data);
void		ft_initialize_threads(t_all *data);
void		ft_start_threads(t_all *data);
int			*ft_create_philosophers_eating(int n_philosophers);
void		ft_fill_data(t_all *data, long int *args, int argc);
void		ft_print_number(long int n);
long int	ft_get_time(void);


#endif
