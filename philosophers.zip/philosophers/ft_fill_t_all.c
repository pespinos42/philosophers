#include "philosophers.h"

void	ft_fill_t_all(t_all *data, long int *args, int n_arg)
{
	if (pthread_mutex_init(&data->m_a_alive, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_active, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_message, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_read_forks, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_erase_all, NULL) != 0)
		return ;
	if (pthread_mutex_init(&data->m_total_exit, NULL) != 0)
		return ;
	data->total_philosophers = args[0];
	data->phi = ft_create_philosophers(args[0]);
	ft_fill_data(data->phi, args, n_arg);
	data->forks = ft_create_forks(args[0]);
	data->all_alive = 1;
	data->threads = ft_create_threads(args[0]);
	data->total_exit = 0;
	if (pthread_create(&data->t_alive, NULL, ft_all_alive, data) != 0)
		return ;
	ft_initialize_threads(data);
}