#include "philosophers.h"

void	ft_set_last_eating(t_all *data, int n)
{
	if (pthread_mutex_lock(&data->phi[n].m_l_eat) != 0)
		return ;
	data->phi[n].last_eating = ft_get_time();
	if (pthread_mutex_unlock(&data->phi[n].m_l_eat) != 0)
		return ;
}