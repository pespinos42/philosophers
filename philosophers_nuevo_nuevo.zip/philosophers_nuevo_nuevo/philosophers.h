/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philosophers.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/13 20:35:43 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:47:52 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILOSOPHERS_H
# define PHILOSOPHERS_H
# include <unistd.h>
# include <limits.h>
# include <stdlib.h>
# include <stdio.h>
# include <pthread.h>
# include <sys/time.h>

typedef struct s_philosopher
{
	int				index_philosopher;
    pthread_mutex_t mutex_index_philosopher;
	long int		time_to_die;
    pthread_mutex_t mutex_time_to_die;
	long int		time_to_eat;
    pthread_mutex_t mutex_time_to_eat;
	long int		time_to_sleep;
    pthread_mutex_t mutex_time_to_sleep;
	int				number_of_times;
    pthread_mutex_t mutex_number_of_times;
	long int		last_eating;
	pthread_mutex_t	mutex_last_eating;
	int				number_exit;
    pthread_mutex_t mutex_number_exit
	long int		start_thread;
	pthread_mutex_t	mutex_start_thread;
}	t_philosopher;

typedef struct s_all
{
	int				total_philosophers;
	t_philosopher	*phi;
	pthread_t		*threads;
	pthread_t		t_alive;
	t_fork			*forks;
	int				active;
	pthread_mutex_t	m_a_alive;
	int				all_alive;
	pthread_mutex_t	m_message;
	pthread_mutex_t	m_active;
	pthread_mutex_t	m_read_forks;
	pthread_mutex_t	m_erase_all;
	int				total_exit;
	pthread_mutex_t	m_total_exit;
}	t_all;