/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_set_last_eating.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/22 16:51:19 by pespinos          #+#    #+#             */
/*   Updated: 2023/04/22 16:52:28 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philosophers.h"

void	ft_set_last_eating(t_all *data, int n)
{
	if (pthread_mutex_lock(&data->phi[n].m_l_eat) != 0)
		return ;
	data->phi[n].last_eating = ft_get_time();
	if (pthread_mutex_unlock(&data->phi[n].m_l_eat) != 0)
		return ;
}
