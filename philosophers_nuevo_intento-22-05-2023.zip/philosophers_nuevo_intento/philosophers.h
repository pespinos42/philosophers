#ifndef PHILOSOPHERS_H
# define PHILOSOPHERS_H
# include <unistd.h>
# include <limits.h>
# include <stdlib.h>
# include <stdio.h>
# include <pthread.h>
# include <sys/time.h>

typedef struct s_fork
{
	int				using_fork;
	pthread_mutex_t	mutex_using_fork;
}	t_fork;

typedef struct s_philosopher
{
	int				index_philosopher;
	pthread_mutex_t	mutex_index_philosopher;
	int             fork_left;
	pthread_mutex_t mutex_fork_left;
	int             fork_right;
	pthread_mutex_t mutex_fork_right;
}   t_philosopher;

typedef struct s_all
{
	int             number_philosophers;
	pthread_mutex_t mutex_number_philosophers;   
	long int        time_to_die;
	pthread_mutex_t mutex_time_to_die;
	long int        time_to_eat;
	pthread_mutex_t mutex_time_to_eat;
	long int        time_to_sleep;
	pthread_mutex_t mutex_time_to_sleep;
	int             number_of_times_eat;
	pthread_mutex_t mutex_number_of_times_eat;
	int             active;
	pthread_mutex_t mutex_active;
	t_fork			*forks;
	t_philosopher	*philosophers;
	pthread_t		*threads;
	pthread_t		thread_all_alive;
	pthread_mutex_t	mutex_message;
}   t_all;

typedef struct s_atoi
{
	long int	result;
	int			s;
	int			sign;
}	t_atoi;

//FILOSOFOS.C
t_fork			*ft_create_forks(int n_forks);
int				ft_get_fork_left(t_philosopher *phil);
void			ft_set_fork_left(t_philosopher *phil, int value);
int				ft_get_fork_right(t_philosopher *phil, int value);
void			ft_set_fork_right(t_philosopher *phil, int value);
int				ft_get_index_philosopher(t_philosopher *phil);
void			ft_set_index_philosopher(t_philosopher *phil, int value);
t_philosopher 	*ft_create_philosophers(t_all *data);
void			ft_init_mutex_philosophers(t_all *data);
void			ft_destroy_mutex_philosophers(t_all *data);

//ALL.C
int				ft_get_active(t_all *data);
void			ft_set_active(t_all *data, int value);
int				ft_get_number_philosophers(t_all *data);
void			ft_set_number_philosophers(t_all *data, int value);
long int		ft_get_time_to_die(t_all *data);
void			ft_set_time_to_die(t_all *data, long int value);
long int		ft_get_time_to_eat(t_all *data);
void			ft_set_time_to_eat(t_all *data, long int value);
long int		ft_get_time_to_sleep(t_all *data);
void			ft_set_time_to_sleep(t_all *data, long int value);
int				ft_get_number_of_times_eat(t_all *data);
void			ft_set_number_of_times_eat(t_all *data, int value);
void			ft_init_mutex_data(t_all *data);
void			ft_destroy_mutex_data(t_all *data);

//ATOI.C
void			ft_initialize_data_atoi(t_atoi *d);
long int		ft_atoi(char *str);

//ARGS.C
int				ft_strlen(char *str);
long int		*ft_get_args(int argc, char **argv);
int				ft_check_only_numbers(int argc, char **argv);
int				ft_check_limits(long int *args, int n_args);
int				ft_check_args(int argc, char **argv);

//RESTO
void			*ft_philosopher(void *arg);
void			*ft_all_alive(void *arg);
pthread_t		*ft_create_threads(t_all *data);
void			ft_initialize_threads(t_all *data);
void			ft_start_threads(t_all *data);
void			ft_fill_data(t_all *data, long int *args, int argc);

#endif
